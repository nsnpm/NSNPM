from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import requests
import json
import os
from datetime import datetime
import math
import re
from opencopilot import OpenCopilot

app = Flask(__name__, static_folder='.')
CORS(app)

# API Keys (replace with your actual keys)
UNSPLASH_ACCESS_KEY = "YOUR_UNSPLASH_ACCESS_KEY"
OPENWEATHER_API_KEY = "YOUR_OPENWEATHER_API_KEY"
NEWSAPI_KEY = "YOUR_NEWSAPI_KEY"

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/<path:path>')
def static_files(path):
    return send_from_directory('.', path)

# Calculator Tool
@app.route('/api/calculate', methods=['POST'])
def calculate():
    try:
        data = request.get_json()
        expression = data.get('expression', '')

        # Security: only allow safe mathematical operations
        allowed_chars = re.match(r'^[0-9+\-*/().\s^sqrt()log()ln()sin()cos()tan()pi]+$', expression)
        if not allowed_chars:
            return jsonify({'error': 'Invalid expression'}), 400

        # Replace functions with math module equivalents
        expression = expression.replace('^', '**')
        expression = expression.replace('pi', str(math.pi))

        # Evaluate the expression safely
        result = eval(expression, {"__builtins__": None}, {
            'sqrt': math.sqrt,
            'log': math.log10,
            'ln': math.log,
            'sin': lambda x: math.sin(math.radians(x)),
            'cos': lambda x: math.cos(math.radians(x)),
            'tan': lambda x: math.tan(math.radians(x)),
            'pi': math.pi,
            'e': math.e
        })

        return jsonify({'result': result})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

# Weather Tool
@app.route('/api/weather', methods=['GET'])
def get_weather():
    city = request.args.get('city')
    lat = request.args.get('lat')
    lon = request.args.get('lon')

    try:
        if city:
            url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={OPENWEATHER_API_KEY}&units=metric"
        elif lat and lon:
            url = f"http://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={OPENWEATHER_API_KEY}&units=metric"
        else:
            return jsonify({'error': 'City name or coordinates required'}), 400

        response = requests.get(url, timeout=10)  # Add timeout to prevent hanging

        if response.status_code == 200:
            return jsonify(response.json())
        elif response.status_code == 401:
            return jsonify({'error': 'Invalid API key'}), 401
        elif response.status_code == 404:
            return jsonify({'error': 'City or location not found'}), 404
        elif response.status_code == 429:
            return jsonify({'error': 'Rate limit exceeded'}), 429
        else:
            return jsonify({'error': f'Weather service error: {response.status_code}'}), response.status_code
    except requests.exceptions.Timeout:
        return jsonify({'error': 'Request timed out'}), 408
    except requests.exceptions.ConnectionError:
        return jsonify({'error': 'Connection error'}), 503
    except Exception as e:
        return jsonify({'error': f'Internal server error: {str(e)}'}), 500

# News Tool
@app.route('/api/news', methods=['GET'])
def get_news():
    category = request.args.get('category', 'general')
    try:
        url = f"https://newsapi.org/v2/top-headlines?category={category}&apiKey={NEWSAPI_KEY}&pageSize=10&country=us"
        response = requests.get(url)
        if response.status_code == 200:
            return jsonify(response.json())
        else:
            return jsonify({'error': 'News data not available'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Translation Tool
@app.route('/api/translate', methods=['POST'])
def translate():
    try:
        data = request.get_json()
        text = data.get('text', '')
        source_lang = data.get('source_lang', 'auto')
        target_lang = data.get('target_lang', 'en')

        url = f"https://api.mymemory.translated.net/get?q={requests.utils.quote(text)}&langpair={source_lang}|{target_lang}"
        response = requests.get(url)

        if response.status_code == 200:
            result = response.json()
            return jsonify({'translated_text': result['responseData']['translatedText']})
        else:
            return jsonify({'error': 'Translation failed'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Image Generation Tool
@app.route('/api/generate-image', methods=['POST'])
def generate_image():
    try:
        data = request.get_json()
        prompt = data.get('prompt', '')
        style = data.get('style', 'realistic')

        # Using Unsplash API for image search (as a placeholder for image generation)
        url = f"https://api.unsplash.com/search/photos?query={requests.utils.quote(prompt)}&per_page=1"
        headers = {'Authorization': f'Client-ID {UNSPLASH_ACCESS_KEY}'}

        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            if data['results']:
                image_url = data['results'][0]['urls']['regular']
                return jsonify({'image_url': image_url})
            else:
                return jsonify({'error': 'No images found for this prompt'}), 404
        else:
            return jsonify({'error': 'Image generation failed'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Code Execution Tool
@app.route('/api/execute-code', methods=['POST'])
def execute_code():
    try:
        data = request.get_json()
        code = data.get('code', '')
        language = data.get('language', 'python')

        # For security, we'll use a simple eval for Python (in production, use proper sandboxing)
        if language.lower() == 'python':
            try:
                # Capture stdout
                import io
                import sys
                from contextlib import redirect_stdout

                f = io.StringIO()
                with redirect_stdout(f):
                    exec(code, {'__builtins__': __builtins__})
                output = f.getvalue()
                return jsonify({'output': output or 'Code executed successfully'})
            except Exception as e:
                return jsonify({'output': f'Error: {str(e)}'})
        else:
            return jsonify({'error': f'Language {language} not supported'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Browse Content Tool
@app.route('/api/browse', methods=['GET'])
def browse_content():
    query = request.args.get('query', '')
    try:
        # Using a free search API (Google Custom Search alternative)
        url = f"https://api.duckduckgo.com/?q={requests.utils.quote(query)}&format=json&no_html=1&skip_disambig=1"
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            results = []

            if data.get('Answer'):
                results.append({
                    'title': 'Instant Answer',
                    'url': data.get('AnswerURL', '#'),
                    'snippet': data['Answer'],
                    'type': 'answer'
                })

            if data.get('Abstract'):
                results.append({
                    'title': data.get('Heading', 'Abstract'),
                    'url': data.get('AbstractURL', '#'),
                    'snippet': data['Abstract'],
                    'type': 'abstract'
                })

            if data.get('RelatedTopics'):
                for topic in data['RelatedTopics'][:5]:
                    if topic.get('Text') and topic.get('FirstURL'):
                        results.append({
                            'title': topic['Text'].split(' - ')[0],
                            'url': topic['FirstURL'],
                            'snippet': topic['Text'],
                            'type': 'topic'
                        })

            return jsonify({'results': results[:5]})
        else:
            # Fallback: return mock results for demo purposes
            mock_results = [
                {
                    'title': f'Search results for "{query}"',
                    'url': f'https://www.google.com/search?q={requests.utils.quote(query)}',
                    'snippet': f'Find information about {query} from various sources.',
                    'type': 'search'
                },
                {
                    'title': f'Wikipedia - {query}',
                    'url': f'https://en.wikipedia.org/wiki/{requests.utils.quote(query)}',
                    'snippet': f'Learn more about {query} on Wikipedia.',
                    'type': 'wikipedia'
                }
            ]
            return jsonify({'results': mock_results})
    except Exception as e:
        # Return mock results on error
        mock_results = [
            {
                'title': f'Search results for "{query}"',
                'url': f'https://www.google.com/search?q={requests.utils.quote(query)}',
                'snippet': f'Find information about {query} from various sources.',
                'type': 'search'
            }
        ]
        return jsonify({'results': mock_results})

# Hello API endpoint
@app.route('/api/hello', methods=['GET'])
def hello():
    name = request.args.get('name', 'World')
    return jsonify({'message': f'Hello, {name}!'})

# Items API endpoint
@app.route('/api/items', methods=['POST'])
def create_item():
    try:
        data = request.get_json()
        # For demo purposes, just return the item with an ID
        item = {
            'id': 1,
            'name': data.get('name', 'Unknown Item'),
            'description': data.get('description', ''),
            'created_at': datetime.now().isoformat()
        }
        return jsonify(item), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 400

# Video Tools API Endpoints
@app.route('/api/video-tools/video-to-audio', methods=['POST'])
def video_to_audio():
    try:
        data = request.get_json()
        video_url = data.get('video_url', '')
        # Mock implementation - in real app, integrate with video processing service
        return jsonify({
            'success': True,
            'message': 'Video to Audio conversion started',
            'audio_url': f'mock_audio_{datetime.now().timestamp()}.mp3',
            'estimated_time': '30 seconds'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/video-tools/video-to-text', methods=['POST'])
def video_to_text():
    try:
        data = request.get_json()
        video_url = data.get('video_url', '')
        # Mock implementation - in real app, integrate with speech-to-text service
        return jsonify({
            'success': True,
            'message': 'Video transcription started',
            'transcript': 'Mock transcript: This is a sample video transcript...',
            'estimated_time': '2 minutes'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/video-tools/video-to-image', methods=['POST'])
def video_to_image():
    try:
        data = request.get_json()
        video_url = data.get('video_url', '')
        timestamp = data.get('timestamp', 0)
        # Mock implementation - in real app, integrate with video processing service
        return jsonify({
            'success': True,
            'message': 'Video frame extraction started',
            'image_url': f'mock_frame_{timestamp}_{datetime.now().timestamp()}.jpg',
            'timestamp': timestamp
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/video-tools/video-to-gif', methods=['POST'])
def video_to_gif():
    try:
        data = request.get_json()
        video_url = data.get('video_url', '')
        start_time = data.get('start_time', 0)
        duration = data.get('duration', 5)
        # Mock implementation - in real app, integrate with video processing service
        return jsonify({
            'success': True,
            'message': 'GIF creation started',
            'gif_url': f'mock_gif_{start_time}_{duration}_{datetime.now().timestamp()}.gif',
            'duration': duration
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/video-tools/video-to-subtitles', methods=['POST'])
def video_to_subtitles():
    try:
        data = request.get_json()
        video_url = data.get('video_url', '')
        language = data.get('language', 'en')
        # Mock implementation - in real app, integrate with subtitle generation service
        return jsonify({
            'success': True,
            'message': 'Subtitle generation started',
            'subtitles_url': f'mock_subtitles_{language}_{datetime.now().timestamp()}.srt',
            'language': language
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/video-tools/video-to-3d', methods=['POST'])
def video_to_3d():
    try:
        data = request.get_json()
        video_url = data.get('video_url', '')
        # Mock implementation - in real app, integrate with 3D conversion service
        return jsonify({
            'success': True,
            'message': '3D conversion started',
            'model_url': f'mock_3d_model_{datetime.now().timestamp()}.obj',
            'estimated_time': '10 minutes'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/video-tools/video-to-script', methods=['POST'])
def video_to_script():
    try:
        data = request.get_json()
        video_url = data.get('video_url', '')
        # Mock implementation - in real app, integrate with AI script generation service
        return jsonify({
            'success': True,
            'message': 'Script generation started',
            'script': 'Mock script: Scene 1 - Introduction...',
            'summary': 'Mock summary: This video covers...',
            'estimated_time': '3 minutes'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/video-tools/video-to-video', methods=['POST'])
def video_to_video():
    try:
        data = request.get_json()
        video_url = data.get('video_url', '')
        style = data.get('style', 'enhance')
        quality = data.get('quality', 'HD')
        # Mock implementation - in real app, integrate with video processing service
        return jsonify({
            'success': True,
            'message': f'Video {style} processing started',
            'output_url': f'mock_processed_video_{style}_{quality}_{datetime.now().timestamp()}.mp4',
            'quality': quality,
            'estimated_time': '5 minutes'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/video-tools/video-to-audio-remix', methods=['POST'])
def video_to_audio_remix():
    try:
        data = request.get_json()
        video_url = data.get('video_url', '')
        style = data.get('style', 'electronic')
        # Mock implementation - in real app, integrate with audio processing service
        return jsonify({
            'success': True,
            'message': 'Audio remix started',
            'remix_url': f'mock_remix_{style}_{datetime.now().timestamp()}.mp3',
            'style': style,
            'estimated_time': '4 minutes'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/video-tools/video-to-code', methods=['POST'])
def video_to_code():
    try:
        data = request.get_json()
        video_url = data.get('video_url', '')
        language = data.get('language', 'python')
        # Mock implementation - in real app, integrate with code generation AI service
        return jsonify({
            'success': True,
            'message': 'Code generation started',
            'code': f'# Mock {language} code generated from video\nprint("Hello from video-to-code!")',
            'language': language,
            'estimated_time': '2 minutes'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/video-tools/text-to-video', methods=['POST'])
def text_to_video():
    try:
        data = request.get_json()
        text = data.get('text', '')
        style = data.get('style', 'realistic')
        duration = data.get('duration', 30)
        # Mock implementation - in real app, integrate with text-to-video AI service
        return jsonify({
            'success': True,
            'message': 'Text-to-video generation started',
            'video_url': f'mock_text_video_{style}_{duration}s_{datetime.now().timestamp()}.mp4',
            'duration': duration,
            'style': style,
            'estimated_time': '15 minutes'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/video-tools/image-to-video', methods=['POST'])
def image_to_video():
    try:
        data = request.get_json()
        image_url = data.get('image_url', '')
        duration = data.get('duration', 10)
        motion = data.get('motion', 'pan')
        # Mock implementation - in real app, integrate with image-to-video service
        return jsonify({
            'success': True,
            'message': 'Image-to-video conversion started',
            'video_url': f'mock_image_video_{motion}_{duration}s_{datetime.now().timestamp()}.mp4',
            'duration': duration,
            'motion_type': motion,
            'estimated_time': '8 minutes'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/video-tools/audio-to-video', methods=['POST'])
def audio_to_video():
    try:
        data = request.get_json()
        audio_url = data.get('audio_url', '')
        visual_style = data.get('visual_style', 'waveform')
        # Mock implementation - in real app, integrate with audio-to-video service
        return jsonify({
            'success': True,
            'message': 'Audio-to-video conversion started',
            'video_url': f'mock_audio_video_{visual_style}_{datetime.now().timestamp()}.mp4',
            'visual_style': visual_style,
            'estimated_time': '6 minutes'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

# Microsoft Graph API Mock Endpoints
@app.route('/api/graph/auth', methods=['GET'])
def graph_auth():
    # Mock authentication - in real implementation, this would redirect to Microsoft OAuth
    return jsonify({
        'authenticated': False,
        'auth_url': 'https://login.microsoftonline.com/oauth2/v2.0/authorize?client_id=mock&response_type=code&scope=https://graph.microsoft.com/.default',
        'message': 'Mock authentication - use real Azure app registration for production'
    })

@app.route('/api/graph/excel/<path:file_path>', methods=['GET'])
def graph_excel_read(file_path):
    # Mock Excel data reading
    mock_data = {
        'worksheets': [
            {
                'name': 'Sheet1',
                'usedRange': {
                    'address': 'Sheet1!A1:D10',
                    'values': [
                        ['Name', 'Age', 'City', 'Salary'],
                        ['John Doe', 30, 'New York', 50000],
                        ['Jane Smith', 25, 'Los Angeles', 45000],
                        ['Bob Johnson', 35, 'Chicago', 55000],
                        ['Alice Brown', 28, 'Houston', 48000]
                    ]
                }
            }
        ]
    }
    return jsonify(mock_data)

@app.route('/api/graph/excel/<path:file_path>', methods=['POST'])
def graph_excel_write(file_path):
    try:
        data = request.get_json()
        # Mock Excel writing
        return jsonify({
            'success': True,
            'message': f'Updated {len(data.get("values", []))} cells in {file_path}',
            'updated_range': data.get('range', 'A1')
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/graph/word/<path:file_path>', methods=['GET'])
def graph_word_read(file_path):
    # Mock Word document reading
    mock_content = {
        'content': 'This is a sample Word document content.\n\nIt contains multiple paragraphs and formatting.\n\nMicrosoft Graph API allows reading and writing Word documents programmatically.',
        'properties': {
            'title': 'Sample Document',
            'author': 'NavaBharat AI',
            'created': datetime.now().isoformat(),
            'modified': datetime.now().isoformat()
        }
    }
    return jsonify(mock_content)

@app.route('/api/graph/word/<path:file_path>', methods=['POST'])
def graph_word_write(file_path):
    try:
        data = request.get_json()
        # Mock Word document writing
        return jsonify({
            'success': True,
            'message': f'Updated content in {file_path}',
            'content_length': len(data.get('content', ''))
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/graph/onedrive/files', methods=['GET'])
def graph_onedrive_list():
    # Mock OneDrive file listing
    mock_files = [
        {
            'name': 'Document1.docx',
            'id': 'file1',
            'size': 24576,
            'lastModifiedDateTime': datetime.now().isoformat(),
            'webUrl': 'https://onedrive.live.com/file1'
        },
        {
            'name': 'Spreadsheet.xlsx',
            'id': 'file2',
            'size': 51200,
            'lastModifiedDateTime': datetime.now().isoformat(),
            'webUrl': 'https://onedrive.live.com/file2'
        },
        {
            'name': 'Presentation.pptx',
            'id': 'file3',
            'size': 102400,
            'lastModifiedDateTime': datetime.now().isoformat(),
            'webUrl': 'https://onedrive.live.com/file3'
        }
    ]
    return jsonify({'value': mock_files})

@app.route('/api/graph/onedrive/upload', methods=['POST'])
def graph_onedrive_upload():
    try:
        # Mock file upload
        file = request.files.get('file')
        if file:
            return jsonify({
                'success': True,
                'file_name': file.filename,
                'file_size': len(file.read()),
                'uploaded_at': datetime.now().isoformat()
            })
        else:
            return jsonify({'error': 'No file provided'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/graph/outlook/messages', methods=['GET'])
def graph_outlook_messages():
    # Mock Outlook messages
    mock_messages = [
        {
            'id': 'msg1',
            'subject': 'Welcome to NavaBharat AI',
            'from': {'emailAddress': {'address': 'noreply@navabharat.ai'}},
            'receivedDateTime': datetime.now().isoformat(),
            'bodyPreview': 'Thank you for using NavaBharat AI. Here are some tips to get started...'
        },
        {
            'id': 'msg2',
            'subject': 'Your recent activity report',
            'from': {'emailAddress': {'address': 'reports@navabharat.ai'}},
            'receivedDateTime': datetime.now().isoformat(),
            'bodyPreview': 'Here is your weekly activity report for the chatbot usage...'
        }
    ]
    return jsonify({'value': mock_messages})

@app.route('/api/graph/outlook/send', methods=['POST'])
def graph_outlook_send():
    try:
        data = request.get_json()
        # Mock email sending
        return jsonify({
            'success': True,
            'message_id': 'sent_' + str(int(datetime.now().timestamp())),
            'to': data.get('to'),
            'subject': data.get('subject'),
            'sent_at': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

# Copilot Integration
PROMPT = """
You are a Python development copilot.
You help the user write, debug and explain Python code.
User: {question}
Copilot:
"""

copilot = OpenCopilot(
    copilot_name="Python Dev Copilot",
    openai_api_key="YOUR_OPENAI_API_KEY",
    llm="gpt-3.5-turbo-16k",
    prompt=PROMPT,
)

# Optionally add knowledge base
copilot.add_data_urls(["https://docs.python.org/3/contents.html"])

@app.route('/api/copilot', methods=['POST'])
def copilot_assist():
    try:
        data = request.get_json()
        question = data.get('question', '')
        if not question:
            return jsonify({'error': 'Question is required'}), 400

        # For demo purposes, return a mock response
        # In production, you would call the copilot here
        response = f"Mock copilot response for: {question}"
        return jsonify({'response': response})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)

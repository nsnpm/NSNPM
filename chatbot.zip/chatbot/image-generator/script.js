// AI Image Generator JavaScript
class ImageGenerator {
    constructor() {
        this.generatedImageUrl = null;
        this.generationStartTime = null;

        this.initializeElements();
        this.bindEvents();
        this.addThemeToggle();
    }

    initializeElements() {
        this.imagePrompt = document.getElementById('imagePrompt');
        this.imageStyle = document.getElementById('imageStyle');
        this.imageSize = document.getElementById('imageSize');
        this.generateBtn = document.getElementById('generateBtn');
        this.resultSection = document.getElementById('resultSection');
        this.loading = document.getElementById('loading');
        this.imageResult = document.getElementById('imageResult');
        this.generatedImage = document.getElementById('generatedImage');
        this.downloadBtn = document.getElementById('downloadBtn');
        this.regenerateBtn = document.getElementById('regenerateBtn');
        this.shareBtn = document.getElementById('shareBtn');
        this.displayPrompt = document.getElementById('displayPrompt');
        this.generationTime = document.getElementById('generationTime');
    }

    bindEvents() {
        this.generateBtn.addEventListener('click', () => this.generateImage());
        this.downloadBtn.addEventListener('click', () => this.downloadImage());
        this.regenerateBtn.addEventListener('click', () => this.regenerateImage());
        this.shareBtn.addEventListener('click', () => this.shareImage());

        // Example buttons
        document.querySelectorAll('.example-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.imagePrompt.value = btn.dataset.prompt;
                this.generateImage();
            });
        });

        // Enter key support
        this.imagePrompt.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.generateImage();
            }
        });
    }

    addThemeToggle() {
        const themeToggle = document.createElement('button');
        themeToggle.className = 'theme-btn';
        themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        themeToggle.title = 'Toggle theme';
        themeToggle.addEventListener('click', () => this.toggleTheme());

        const themeContainer = document.createElement('div');
        themeContainer.className = 'theme-toggle';
        themeContainer.appendChild(themeToggle);
        document.body.appendChild(themeContainer);

        // Load saved theme
        const savedTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', savedTheme);
        this.updateThemeIcon(savedTheme);
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        this.updateThemeIcon(newTheme);
    }

    updateThemeIcon(theme) {
        const themeBtn = document.querySelector('.theme-btn i');
        if (theme === 'dark') {
            themeBtn.className = 'fas fa-sun';
        } else {
            themeBtn.className = 'fas fa-moon';
        }
    }

    async generateImage() {
        const prompt = this.imagePrompt.value.trim();
        const style = this.imageStyle.value;
        const size = this.imageSize.value;

        if (!prompt) {
            this.showNotification('Please enter a description for the image.', 'warning');
            return;
        }

        if (prompt.length < 3) {
            this.showNotification('Please enter a more detailed description (at least 3 characters).', 'warning');
            return;
        }

        // Show result section and loading
        this.resultSection.style.display = 'block';
        this.loading.style.display = 'block';
        this.imageResult.style.display = 'none';

        // Disable generate button
        this.generateBtn.disabled = true;
        this.generateBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';

        // Store generation start time
        this.generationStartTime = Date.now();

        try {
            // Call the image generation API
            const response = await this.callImageGenerationAPI(prompt, style, size);

            if (response.success) {
                this.displayGeneratedImage(response.imageUrl, prompt);
                this.showNotification('Image generated successfully!', 'success');
            } else {
                throw new Error(response.error || 'Image generation failed');
            }

        } catch (error) {
            console.error('Image generation error:', error);
            this.showNotification(`Failed to generate image: ${error.message}`, 'error');
            this.resultSection.style.display = 'none';
        } finally {
            // Re-enable generate button
            this.generateBtn.disabled = false;
            this.generateBtn.innerHTML = '<i class="fas fa-magic"></i> Generate Image';
        }
    }

    async callImageGenerationAPI(prompt, style, size) {
        // Simulate API call - replace with actual API endpoint
        return new Promise((resolve) => {
            setTimeout(() => {
                // Mock successful response
                resolve({
                    success: true,
                    imageUrl: `https://picsum.photos/${size.replace('x', '/')}/?random=${Date.now()}`
                });
            }, 3000);
        });

        // Uncomment and modify for actual API integration:
        /*
        const response = await fetch('/api/generate-image', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                prompt: prompt,
                style: style,
                size: size
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'API request failed');
        }

        return await response.json();
        */
    }

    displayGeneratedImage(imageUrl, prompt) {
        this.generatedImageUrl = imageUrl;
        this.generatedImage.src = imageUrl;
        this.generatedImage.dataset.imageUrl = imageUrl;

        // Update display info
        this.displayPrompt.textContent = prompt;

        const generationTime = Date.now() - this.generationStartTime;
        this.generationTime.textContent = `Generated in ${Math.round(generationTime / 1000)} seconds`;

        // Hide loading and show result
        this.loading.style.display = 'none';
        this.imageResult.style.display = 'block';

        // Scroll to result
        this.resultSection.scrollIntoView({ behavior: 'smooth' });
    }

    downloadImage() {
        if (!this.generatedImageUrl) return;

        const link = document.createElement('a');
        link.href = this.generatedImageUrl;
        link.download = `ai-generated-image-${Date.now()}.jpg`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        this.showNotification('Image downloaded successfully!', 'success');
    }

    regenerateImage() {
        this.generateImage();
    }

    shareImage() {
        if (!this.generatedImageUrl) return;

        if (navigator.share) {
            navigator.share({
                title: 'AI Generated Image',
                text: 'Check out this image I generated with AI!',
                url: this.generatedImageUrl
            });
        } else {
            // Fallback: copy URL to clipboard
            navigator.clipboard.writeText(this.generatedImageUrl).then(() => {
                this.showNotification('Image URL copied to clipboard!', 'success');
            });
        }
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 4000);
    }
}

// Initialize the image generator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const imageGenerator = new ImageGenerator();
});

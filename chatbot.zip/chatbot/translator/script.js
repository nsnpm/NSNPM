// AI Translator JavaScript
class Translator {
    constructor() {
        this.currentTranslation = null;
        this.translationHistory = [];

        this.initializeElements();
        this.bindEvents();
        this.addThemeToggle();
        this.loadSavedSettings();
    }

    initializeElements() {
        this.sourceLanguage = document.getElementById('sourceLanguage');
        this.targetLanguage = document.getElementById('targetLanguage');
        this.sourceText = document.getElementById('sourceText');
        this.outputText = document.getElementById('outputText');
        this.translateBtn = document.getElementById('translateBtn');
        this.swapLanguages = document.getElementById('swapLanguages');
        this.loadingIndicator = document.getElementById('loadingIndicator');
        this.translationTime = document.getElementById('translationTime');
        this.charCount = document.getElementById('charCount');
        this.clearSource = document.getElementById('clearSource');
        this.speakSource = document.getElementById('speakSource');
        this.speakTarget = document.getElementById('speakTarget');
        this.copySource = document.getElementById('copySource');
        this.copyTarget = document.getElementById('copyTarget');
    }

    bindEvents() {
        this.translateBtn.addEventListener('click', () => this.translate());
        this.swapLanguages.addEventListener('click', () => this.swapLanguagesFn());
        this.clearSource.addEventListener('click', () => this.clearSourceText());
        this.speakSource.addEventListener('click', () => this.speakText('source'));
        this.speakTarget.addEventListener('click', () => this.speakText('target'));
        this.copySource.addEventListener('click', () => this.copyText('source'));
        this.copyTarget.addEventListener('click', () => this.copyText('target'));

        // Auto-translate on text input (debounced)
        let translateTimeout;
        this.sourceText.addEventListener('input', () => {
            this.updateCharCount();
            clearTimeout(translateTimeout);
            translateTimeout = setTimeout(() => {
                if (this.sourceText.value.trim().length > 0) {
                    this.translate();
                } else {
                    this.clearOutput();
                }
            }, 1000);
        });

        // Language change events
        this.sourceLanguage.addEventListener('change', () => this.saveSettings());
        this.targetLanguage.addEventListener('change', () => this.saveSettings());

        // Example buttons
        document.querySelectorAll('.example-btn').forEach(btn => {
            btn.addEventListener('click', () => this.loadExample(btn));
        });

        // Enter key support
        this.sourceText.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && e.ctrlKey) {
                e.preventDefault();
                this.translate();
            }
        });
    }

    addThemeToggle() {
        const themeToggle = document.createElement('button');
        themeToggle.className = 'theme-btn';
        themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        themeToggle.title = 'Toggle theme';
        themeToggle.addEventListener('click', () => this.toggleTheme());

        const themeContainer = document.createElement('div');
        themeContainer.className = 'theme-toggle';
        themeContainer.appendChild(themeToggle);
        document.body.appendChild(themeContainer);

        // Load saved theme
        const savedTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', savedTheme);
        this.updateThemeIcon(savedTheme);
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        this.updateThemeIcon(newTheme);
    }

    updateThemeIcon(theme) {
        const themeBtn = document.querySelector('.theme-btn i');
        if (theme === 'dark') {
            themeBtn.className = 'fas fa-sun';
        } else {
            themeBtn.className = 'fas fa-moon';
        }
    }

    loadSavedSettings() {
        const savedSource = localStorage.getItem('sourceLanguage');
        const savedTarget = localStorage.getItem('targetLanguage');

        if (savedSource) this.sourceLanguage.value = savedSource;
        if (savedTarget) this.targetLanguage.value = savedTarget;

        this.updateCharCount();
    }

    saveSettings() {
        localStorage.setItem('sourceLanguage', this.sourceLanguage.value);
        localStorage.setItem('targetLanguage', this.targetLanguage.value);
    }

    updateCharCount() {
        const count = this.sourceText.value.length;
        this.charCount.textContent = `${count} character${count !== 1 ? 's' : ''}`;
    }

    async translate() {
        const text = this.sourceText.value.trim();
        const sourceLang = this.sourceLanguage.value;
        const targetLang = this.targetLanguage.value;

        if (!text) {
            this.showNotification('Please enter text to translate.', 'warning');
            return;
        }

        if (sourceLang === targetLang && sourceLang !== 'auto') {
            this.showNotification('Source and target languages are the same.', 'warning');
            return;
        }

        // Show loading
        this.loadingIndicator.style.display = 'flex';
        this.outputText.style.display = 'none';
        this.translateBtn.disabled = true;
        this.translateBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Translating...';

        const startTime = Date.now();

        try {
            const result = await this.callTranslationAPI(text, sourceLang, targetLang);

            if (result.success) {
                this.displayTranslation(result.translation, result.detectedLanguage, startTime);
                this.addToHistory(text, result.translation, sourceLang, targetLang);
                this.showNotification('Translation completed!', 'success');
            } else {
                throw new Error(result.error || 'Translation failed');
            }

        } catch (error) {
            console.error('Translation error:', error);
            this.displayError(error.message);
            this.showNotification(`Translation failed: ${error.message}`, 'error');
        } finally {
            this.loadingIndicator.style.display = 'none';
            this.outputText.style.display = 'block';
            this.translateBtn.disabled = false;
            this.translateBtn.innerHTML = '<i class="fas fa-language"></i> Translate';
        }
    }

    async callTranslationAPI(text, sourceLang, targetLang) {
        // Simulate API call - replace with actual translation endpoint
        return new Promise((resolve) => {
            setTimeout(() => {
                // Mock translation responses
                const mockTranslations = {
                    'en-to-hi': {
                        'Hello, how are you?': 'नमस्ते, आप कैसे हैं?',
                        'Thank you very much': 'बहुत धन्यवाद',
                        'Where is the nearest hospital?': 'निकटतम अस्पताल कहाँ है?',
                        'I need help': 'मुझे मदद चाहिए',
                        'How much does this cost?': 'इसकी कीमत कितनी है?',
                        'What time is it?': 'कितने बजे हैं?'
                    },
                    'hi-to-en': {
                        'नमस्ते': 'Hello',
                        'धन्यवाद': 'Thank you',
                        'मदद': 'Help'
                    }
                };

                const key = `${sourceLang}-to-${targetLang}`;
                let translation = mockTranslations[key]?.[text] || `Translated: ${text}`;

                // If no mock translation, create a simple one
                if (translation === `Translated: ${text}`) {
                    if (targetLang === 'hi') {
                        translation = text + ' (अनुवाद)';
                    } else if (targetLang === 'en') {
                        translation = text + ' (translated)';
                    }
                }

                resolve({
                    success: true,
                    translation: translation,
                    detectedLanguage: sourceLang === 'auto' ? 'en' : sourceLang
                });
            }, 1500);
        });

        // Uncomment for actual API integration:
        /*
        const response = await fetch('/api/translate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                text: text,
                sourceLanguage: sourceLang,
                targetLanguage: targetLang
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'Translation failed');
        }

        return await response.json();
        */
    }

    displayTranslation(translation, detectedLanguage, startTime) {
        this.outputText.textContent = translation;
        this.currentTranslation = translation;

        const endTime = Date.now();
        const duration = ((endTime - startTime) / 1000).toFixed(2);

        let timeInfo = `Translated in ${duration}s`;
        if (detectedLanguage && this.sourceLanguage.value === 'auto') {
            timeInfo += ` • Detected: ${this.getLanguageName(detectedLanguage)}`;
        }

        this.translationTime.textContent = timeInfo;
    }

    displayError(error) {
        this.outputText.textContent = `Error: ${error}`;
        this.outputText.className = 'output-text error';
        this.translationTime.textContent = '';
    }

    clearOutput() {
        this.outputText.textContent = '';
        this.outputText.className = 'output-text';
        this.translationTime.textContent = '';
        this.currentTranslation = null;
    }

    swapLanguagesFn() {
        const sourceValue = this.sourceLanguage.value;
        const targetValue = this.targetLanguage.value;
        const sourceText = this.sourceText.value;
        const targetText = this.outputText.textContent;

        // Swap language selections
        this.sourceLanguage.value = targetValue;
        this.targetLanguage.value = sourceValue;

        // Swap text content
        this.sourceText.value = targetText;
        this.outputText.textContent = sourceText;

        // Update char count
        this.updateCharCount();

        // Save settings
        this.saveSettings();

        // If there's text in the new source, translate it
        if (this.sourceText.value.trim()) {
            this.translate();
        }
    }

    clearSourceText() {
        this.sourceText.value = '';
        this.clearOutput();
        this.updateCharCount();
        this.sourceText.focus();
    }

    speakText(type) {
        const text = type === 'source' ? this.sourceText.value : this.currentTranslation;

        if (!text || !text.trim()) {
            this.showNotification('No text to speak.', 'warning');
            return;
        }

        const utterance = new SpeechSynthesisUtterance(text);

        // Set language for speech
        const lang = type === 'source' ? this.sourceLanguage.value : this.targetLanguage.value;
        if (lang !== 'auto') {
            utterance.lang = this.getSpeechLanguageCode(lang);
        }

        // Speak the text
        window.speechSynthesis.speak(utterance);
    }

    getSpeechLanguageCode(lang) {
        const speechCodes = {
            'en': 'en-US',
            'es': 'es-ES',
            'fr': 'fr-FR',
            'de': 'de-DE',
            'it': 'it-IT',
            'pt': 'pt-BR',
            'ru': 'ru-RU',
            'ja': 'ja-JP',
            'ko': 'ko-KR',
            'zh': 'zh-CN',
            'ar': 'ar-SA',
            'hi': 'hi-IN'
        };
        return speechCodes[lang] || 'en-US';
    }

    copyText(type) {
        const text = type === 'source' ? this.sourceText.value : this.currentTranslation;

        if (!text || !text.trim()) {
            this.showNotification('No text to copy.', 'warning');
            return;
        }

        navigator.clipboard.writeText(text).then(() => {
            this.showNotification('Text copied to clipboard!', 'success');
        });
    }

    loadExample(btn) {
        const text = btn.dataset.text;
        const from = btn.dataset.from;
        const to = btn.dataset.to;

        // Set languages
        this.sourceLanguage.value = from;
        this.targetLanguage.value = to;

        // Set text and translate
        this.sourceText.value = text;
        this.updateCharCount();
        this.translate();

        this.saveSettings();
    }

    addToHistory(sourceText, translatedText, sourceLang, targetLang) {
        const entry = {
            sourceText,
            translatedText,
            sourceLang,
            targetLang,
            timestamp: new Date().toISOString()
        };

        this.translationHistory.unshift(entry);

        // Keep only last 10 translations
        if (this.translationHistory.length > 10) {
            this.translationHistory = this.translationHistory.slice(0, 10);
        }

        // Save to localStorage
        localStorage.setItem('translationHistory', JSON.stringify(this.translationHistory));
    }

    getLanguageName(code) {
        const languages = {
            'auto': 'Auto Detect',
            'en': 'English',
            'es': 'Spanish',
            'fr': 'French',
            'de': 'German',
            'it': 'Italian',
            'pt': 'Portuguese',
            'ru': 'Russian',
            'ja': 'Japanese',
            'ko': 'Korean',
            'zh': 'Chinese',
            'ar': 'Arabic',
            'hi': 'Hindi',
            'bn': 'Bengali',
            'te': 'Telugu',
            'mr': 'Marathi',
            'ta': 'Tamil',
            'ur': 'Urdu',
            'gu': 'Gujarati',
            'kn': 'Kannada',
            'or': 'Odia',
            'pa': 'Punjabi',
            'as': 'Assamese',
            'ml': 'Malayalam'
        };
        return languages[code] || code;
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 4000);
    }
}

// Initialize the translator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const translator = new Translator();
});

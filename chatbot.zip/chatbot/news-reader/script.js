// AI News Reader JavaScript
class NewsReader {
    constructor() {
        this.apiKey = 'YOUR_NEWSAPI_KEY'; // Replace with actual NewsAPI key
        this.currentCategory = 'general';
        this.currentQuery = '';
        this.currentPage = 1;
        this.articles = [];
        this.bookmarkedArticles = [];
        this.viewMode = 'grid'; // 'grid' or 'list'

        this.initializeElements();
        this.bindEvents();
        this.addThemeToggle();
        this.loadSavedData();
        this.loadNews();
    }

    initializeElements() {
        this.searchInput = document.getElementById('searchInput');
        this.searchBtn = document.getElementById('searchBtn');
        this.filterBtn = document.getElementById('filterBtn');
        this.newsTitle = document.getElementById('newsTitle');
        this.newsContainer = document.getElementById('newsContainer');
        this.loading = document.getElementById('loading');
        this.errorMessage = document.getElementById('errorMessage');
        this.errorText = document.getElementById('errorText');
        this.retryBtn = document.getElementById('retryBtn');
        this.loadMore = document.getElementById('loadMore');
        this.loadMoreBtn = document.getElementById('loadMoreBtn');
        this.trendingTags = document.getElementById('trendingTags');
        this.insightsContent = document.getElementById('insightsContent');

        // Modal elements
        this.articleModal = document.getElementById('articleModal');
        this.modalTitle = document.getElementById('modalTitle');
        this.modalSource = document.getElementById('modalSource');
        this.modalDate = document.getElementById('modalDate');
        this.modalAuthor = document.getElementById('modalAuthor');
        this.modalImage = document.getElementById('modalImage');
        this.modalContent = document.getElementById('modalContent');
        this.shareBtn = document.getElementById('shareBtn');
        this.bookmarkBtn = document.getElementById('bookmarkBtn');
        this.readMoreLink = document.getElementById('readMoreLink');
        this.closeModal = document.getElementById('closeModal');

        // View options
        this.gridView = document.getElementById('gridView');
        this.listView = document.getElementById('listView');
    }

    bindEvents() {
        this.searchBtn.addEventListener('click', () => this.searchNews());
        this.searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.searchNews();
        });
        this.retryBtn.addEventListener('click', () => this.loadNews());
        this.loadMoreBtn.addEventListener('click', () => this.loadMoreNews());

        // Category filters
        document.querySelectorAll('.category-btn').forEach(btn => {
            btn.addEventListener('click', () => this.changeCategory(btn));
        });

        // View options
        this.gridView.addEventListener('click', () => this.setViewMode('grid'));
        this.listView.addEventListener('click', () => this.setViewMode('list'));

        // Modal events
        this.closeModal.addEventListener('click', () => this.closeArticleModal());
        this.articleModal.addEventListener('click', (e) => {
            if (e.target === this.articleModal) this.closeArticleModal();
        });
        this.shareBtn.addEventListener('click', () => this.shareArticle());
        this.bookmarkBtn.addEventListener('click', () => this.toggleBookmark());

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.articleModal.style.display !== 'none') {
                this.closeArticleModal();
            }
        });
    }

    addThemeToggle() {
        const themeToggle = document.createElement('button');
        themeToggle.className = 'theme-btn';
        themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        themeToggle.title = 'Toggle theme';
        themeToggle.addEventListener('click', () => this.toggleTheme());

        const themeContainer = document.createElement('div');
        themeContainer.className = 'theme-toggle';
        themeContainer.appendChild(themeToggle);
        document.body.appendChild(themeContainer);

        // Load saved theme
        const savedTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', savedTheme);
        this.updateThemeIcon(savedTheme);
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        this.updateThemeIcon(newTheme);
    }

    updateThemeIcon(theme) {
        const themeBtn = document.querySelector('.theme-btn i');
        if (theme === 'dark') {
            themeBtn.className = 'fas fa-sun';
        } else {
            themeBtn.className = 'fas fa-moon';
        }
    }

    loadSavedData() {
        const savedBookmarks = localStorage.getItem('bookmarkedArticles');
        const savedViewMode = localStorage.getItem('viewMode');

        if (savedBookmarks) {
            this.bookmarkedArticles = JSON.parse(savedBookmarks);
        }

        if (savedViewMode) {
            this.viewMode = savedViewMode;
            this.setViewMode(savedViewMode, false);
        }
    }

    async loadNews() {
        this.showLoading();
        this.hideError();

        try {
            const newsData = await this.fetchNews();
            this.articles = newsData.articles || [];
            this.displayNews(this.articles);
            this.updateTrendingTopics();
            this.generateAIInsights(this.articles);
            this.showNotification('News loaded successfully!', 'success');
        } catch (error) {
            console.error('News loading error:', error);
            this.showError(error.message);
        } finally {
            this.hideLoading();
        }
    }

    async searchNews() {
        const query = this.searchInput.value.trim();

        if (!query) {
            this.showNotification('Please enter a search term', 'warning');
            return;
        }

        this.currentQuery = query;
        this.currentCategory = '';
        this.currentPage = 1;
        this.newsTitle.textContent = `Search Results for "${query}"`;

        // Update category buttons
        document.querySelectorAll('.category-btn').forEach(btn => {
            btn.classList.remove('active');
        });

        this.loadNews();
    }

    changeCategory(btn) {
        const category = btn.dataset.category;

        // Update active button
        document.querySelectorAll('.category-btn').forEach(b => {
            b.classList.remove('active');
        });
        btn.classList.add('active');

        this.currentCategory = category;
        this.currentQuery = '';
        this.currentPage = 1;
        this.searchInput.value = '';

        const categoryNames = {
            general: 'Latest News',
            business: 'Business News',
            technology: 'Technology News',
            sports: 'Sports News',
            health: 'Health News',
            science: 'Science News',
            entertainment: 'Entertainment News'
        };

        this.newsTitle.textContent = categoryNames[category] || 'Latest News';
        this.loadNews();
    }

    setViewMode(mode, save = true) {
        this.viewMode = mode;

        // Update buttons
        this.gridView.classList.toggle('active', mode === 'grid');
        this.listView.classList.toggle('active', mode === 'list');

        // Update container
        this.newsContainer.className = `news-container ${mode}-view`;

        if (save) {
            localStorage.setItem('viewMode', mode);
        }
    }

    async fetchNews() {
        let url = `https://newsapi.org/v2/top-headlines?country=us&apiKey=${this.apiKey}`;

        if (this.currentQuery) {
            url = `https://newsapi.org/v2/everything?q=${encodeURIComponent(this.currentQuery)}&apiKey=${this.apiKey}&page=${this.currentPage}`;
        } else if (this.currentCategory && this.currentCategory !== 'general') {
            url = `https://newsapi.org/v2/top-headlines?country=us&category=${this.currentCategory}&apiKey=${this.apiKey}&page=${this.currentPage}`;
        } else {
            url += `&page=${this.currentPage}`;
        }

        // Mock API response for demonstration
        return new Promise((resolve) => {
            setTimeout(() => {
                const mockArticles = this.generateMockArticles();
                resolve({ articles: mockArticles });
            }, 1500);
        });

        // Uncomment for actual API:
        /*
        const response = await fetch(url);

        if (!response.ok) {
            throw new Error(`Failed to fetch news: ${response.status}`);
        }

        return await response.json();
        */
    }

    generateMockArticles() {
        const mockTitles = [
            'Breaking: Major Tech Company Announces Revolutionary AI Development',
            'Global Climate Summit Reaches Historic Agreement on Emissions',
            'Stock Markets Surge as Economic Indicators Show Strong Recovery',
            'New Study Reveals Surprising Benefits of Mediterranean Diet',
            'Space Mission Successfully Lands Rover on Mars Surface',
            'Olympic Champion Sets New World Record in Athletics',
            'Healthcare Innovation Promises Faster Disease Detection',
            'Cryptocurrency Market Sees Volatile Trading Session',
            'Wildlife Conservation Efforts Show Promising Results',
            'Educational Technology Transforms Learning Experience'
        ];

        const mockSources = ['CNN', 'BBC', 'Reuters', 'The New York Times', 'Associated Press', 'Bloomberg'];
        const mockDescriptions = [
            'In a groundbreaking announcement, the company revealed their latest AI breakthrough that could change the industry forever.',
            'World leaders gathered to discuss climate change solutions, resulting in unprecedented commitments.',
            'Economic data released today shows stronger than expected growth across multiple sectors.',
            'Researchers have discovered new health benefits from traditional dietary patterns.',
            'NASA\'s latest mission achieved a perfect landing on the red planet.',
            'An incredible performance shattered previous records and inspired millions.',
            'Medical technology advances promise faster and more accurate diagnostics.',
            'Digital currencies experienced significant price movements throughout the trading day.',
            'Conservation programs are showing measurable success in protecting endangered species.',
            'Modern technology is revolutionizing how students learn and engage with educational content.'
        ];

        const articles = [];
        for (let i = 0; i < 12; i++) {
            articles.push({
                title: mockTitles[i % mockTitles.length],
                description: mockDescriptions[i % mockDescriptions.length],
                url: `https://example.com/article-${i + 1}`,
                urlToImage: `https://picsum.photos/400/200?random=${i + 1}`,
                publishedAt: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString(),
                source: { name: mockSources[i % mockSources.length] },
                author: 'News Staff',
                content: 'Full article content would appear here with complete details about the story...'
            });
        }

        return articles;
    }

    displayNews(articles) {
        if (articles.length === 0) {
            this.newsContainer.innerHTML = '<div class="no-news">No articles found for your search.</div>';
            this.loadMore.style.display = 'none';
            return;
        }

        const articlesHtml = articles.map((article, index) => this.createArticleHTML(article, index)).join('');
        this.newsContainer.innerHTML = articlesHtml;

        // Show load more button if there might be more articles
        this.loadMore.style.display = articles.length >= 20 ? 'block' : 'none';

        // Add click handlers for articles
        document.querySelectorAll('.news-article').forEach((article, index) => {
            article.addEventListener('click', () => this.openArticleModal(articles[index]));
        });
    }

    createArticleHTML(article, index) {
        const date = new Date(article.publishedAt).toLocaleDateString();
        const isBookmarked = this.bookmarkedArticles.some(b => b.url === article.url);

        return `
            <div class="news-article" data-index="${index}">
                <div class="article-image">
                    <img src="${article.urlToImage || 'https://via.placeholder.com/400x200?text=No+Image'}" 
                         alt="${article.title}" 
                         loading="lazy">
                    <div class="article-category">${this.currentCategory || 'General'}</div>
                </div>
                <div class="article-content">
                    <h3 class="article-title">${article.title}</h3>
                    <p class="article-description">${article.description || 'No description available.'}</p>
                    <div class="article-meta">
                        <span class="article-source">${article.source.name}</span>
                        <span class="article-date">${date}</span>
                    </div>
                </div>
            </div>
        `;
    }

    async loadMoreNews() {
        this.currentPage++;
        this.loadMoreBtn.disabled = true;
        this.loadMoreBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';

        try {
            const newsData = await this.fetchNews();
            const newArticles = newsData.articles || [];

            if (newArticles.length === 0) {
                this.loadMore.style.display = 'none';
                this.showNotification('No more articles available', 'info');
                return;
            }

            this.articles = [...this.articles, ...newArticles];
            this.displayNews(this.articles);
            this.showNotification('More articles loaded!', 'success');
        } catch (error) {
            console.error('Load more error:', error);
            this.showNotification('Failed to load more articles', 'error');
        } finally {
            this.loadMoreBtn.disabled = false;
            this.loadMoreBtn.innerHTML = '<i class="fas fa-plus"></i> Load More Articles';
        }
    }

    updateTrendingTopics() {
        const trendingTopics = [
            'Artificial Intelligence', 'Climate Change', 'COVID-19', 'Space Exploration',
            'Cryptocurrency', 'Electric Vehicles', 'Renewable Energy', 'Healthcare',
            'Education Technology', 'Sports', 'Entertainment', 'Business'
        ];

        const topicsHtml = trendingTopics.map(topic => `
            <div class="trending-tag" data-topic="${topic.toLowerCase().replace(/\s+/g, '-')}">
                ${topic}
            </div>
        `).join('');

        this.trendingTags.innerHTML = topicsHtml;

        // Add click handlers
        document.querySelectorAll('.trending-tag').forEach(tag => {
            tag.addEventListener('click', () => {
                this.searchInput.value = tag.textContent.trim();
                this.searchNews();
            });
        });
    }

    generateAIInsights(articles) {
        if (articles.length === 0) return;

        // Analyze articles for insights
        const categories = {};
        const sentiments = { positive: 0, negative: 0, neutral: 0 };
        const sources = {};

        articles.forEach(article => {
            // Count categories (mock analysis)
            const category = this.analyzeArticleCategory(article);
            categories[category] = (categories[category] || 0) + 1;

            // Count sources
            sources[article.source.name] = (sources[article.source.name] || 0) + 1;

            // Mock sentiment analysis
            const sentiment = this.analyzeSentiment(article);
            sentiments[sentiment]++;
        });

        const insights = [];

        // Category insights
        const topCategory = Object.keys(categories).reduce((a, b) => categories[a] > categories[b] ? a : b);
        insights.push({
            icon: 'fas fa-chart-bar',
            text: `Most articles today are about ${topCategory} (${categories[topCategory]} articles).`
        });

        // Source diversity
        const sourceCount = Object.keys(sources).length;
        insights.push({
            icon: 'fas fa-newspaper',
            text: `Articles from ${sourceCount} different news sources ensure diverse perspectives.`
        });

        // Sentiment insights
        const dominantSentiment = Object.keys(sentiments).reduce((a, b) => sentiments[a] > sentiments[b] ? a : b);
        const sentimentText = {
            positive: 'positive and uplifting',
            negative: 'concerning or challenging',
            neutral: 'balanced and informative'
        };
        insights.push({
            icon: 'fas fa-smile',
            text: `Overall sentiment analysis shows ${sentimentText[dominantSentiment]} tone in today's news.`
        });

        // Time-based insights
        const recentArticles = articles.filter(a => {
            const articleDate = new Date(a.publishedAt);
            const now = new Date();
            const hoursDiff = (now - articleDate) / (1000 * 60 * 60);
            return hoursDiff <= 24;
        });

        if (recentArticles.length > 0) {
            insights.push({
                icon: 'fas fa-clock',
                text: `${recentArticles.length} articles published in the last 24 hours indicate active news cycle.`
            });
        }

        this.displayInsights(insights);
    }

    analyzeArticleCategory(article) {
        const title = article.title.toLowerCase();
        const description = (article.description || '').toLowerCase();

        if (title.includes('tech') || title.includes('ai') || title.includes('software')) return 'Technology';
        if (title.includes('business') || title.includes('market') || title.includes('economy')) return 'Business';
        if (title.includes('health') || title.includes('medical') || title.includes('disease')) return 'Health';
        if (title.includes('sport') || title.includes('game') || title.includes('olympic')) return 'Sports';
        if (title.includes('science') || title.includes('research') || title.includes('study')) return 'Science';
        if (title.includes('climate') || title.includes('environment') || title.includes('green')) return 'Environment';

        return 'General';
    }

    analyzeSentiment(article) {
        const text = (article.title + ' ' + (article.description || '')).toLowerCase();

        const positiveWords = ['success', 'breakthrough', 'recovery', 'growth', 'win', 'achievement', 'positive'];
        const negativeWords = ['crisis', 'decline', 'failure', 'concern', 'problem', 'disaster', 'negative'];

        let positiveCount = positiveWords.reduce((count, word) => count + (text.includes(word) ? 1 : 0), 0);
        let negativeCount = negativeWords.reduce((count, word) => count + (text.includes(word) ? 1 : 0), 0);

        if (positiveCount > negativeCount) return 'positive';
        if (negativeCount > positiveCount) return 'negative';
        return 'neutral';
    }

    displayInsights(insights) {
        this.insightsContent.innerHTML = insights.map(insight => `
            <div class="insight-item">
                <i class="${insight.icon}"></i>
                <div class="insight-text">${insight.text}</div>
            </div>
        `).join('');
    }

    openArticleModal(article) {
        this.modalTitle.textContent = article.title;
        this.modalSource.textContent = `Source: ${article.source.name}`;
        this.modalDate.textContent = `Published: ${new Date(article.publishedAt).toLocaleDateString()}`;
        this.modalAuthor.textContent = article.author ? `By: ${article.author}` : '';

        if (article.urlToImage) {
            this.modalImage.innerHTML = `<img src="${article.urlToImage}" alt="${article.title}">`;
        } else {
            this.modalImage.innerHTML = '';
        }

        this.modalContent.textContent = article.content || article.description || 'Full article content not available.';
        this.readMoreLink.href = article.url;

        // Update bookmark button
        const isBookmarked = this.bookmarkedArticles.some(b => b.url === article.url);
        this.bookmarkBtn.innerHTML = `<i class="fas fa-bookmark${isBookmarked ? '' : '-o'}"></i> ${isBookmarked ? 'Bookmarked' : 'Bookmark'}`;

        this.articleModal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }

    closeArticleModal() {
        this.articleModal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }

    shareArticle() {
        const url = this.readMoreLink.href;
        const title = this.modalTitle.textContent;

        if (navigator.share) {
            navigator.share({
                title: title,
                url: url
            });
        } else {
            // Fallback to clipboard
            navigator.clipboard.writeText(`${title} - ${url}`).then(() => {
                this.showNotification('Article link copied to clipboard!', 'success');
            });
        }
    }

    toggleBookmark() {
        const url = this.readMoreLink.href;
        const title = this.modalTitle.textContent;
        const existingIndex = this.bookmarkedArticles.findIndex(b => b.url === url);

        if (existingIndex >= 0) {
            // Remove bookmark
            this.bookmarkedArticles.splice(existingIndex, 1);
            this.bookmarkBtn.innerHTML = '<i class="fas fa-bookmark-o"></i> Bookmark';
            this.showNotification('Article removed from bookmarks', 'info');
        } else {
            // Add bookmark
            this.bookmarkedArticles.push({
                title: title,
                url: url,
                timestamp: new Date().toISOString()
            });
            this.bookmarkBtn.innerHTML = '<i class="fas fa-bookmark"></i> Bookmarked';
            this.showNotification('Article bookmarked!', 'success');
        }

        // Save to localStorage
        localStorage.setItem('bookmarkedArticles', JSON.stringify(this.bookmarkedArticles));
    }

    showLoading() {
        this.newsContainer.style.display = 'none';
        this.errorMessage.style.display = 'none';
        this.loading.style.display = 'block';
    }

    hideLoading() {
        this.loading.style.display = 'none';
        this.newsContainer.style.display = 'grid';
    }

    showError(message) {
        this.newsContainer.style.display = 'none';
        this.errorMessage.style.display = 'block';
        this.errorText.textContent = message;
    }

    hideError() {
        this.errorMessage.style.display = 'none';
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 4000);
    }
}

// Initialize the news reader when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const newsReader = new NewsReader();
});

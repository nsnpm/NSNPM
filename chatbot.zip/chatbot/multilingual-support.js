// Multilingual Support for NavaBharat AI
class MultilingualSupport {
    constructor(multimediaAI) {
        this.multimediaAI = multimediaAI;
        this.currentLanguage = 'en';
        this.supportedLanguages = {
            'en': { name: 'English', flag: '🇺🇸', native: 'English' },
            'hi': { name: 'Hindi', flag: '🇮🇳', native: 'हिन्दी' },
            'te': { name: 'Telugu', flag: '🇮🇳', native: 'తెలుగు' },
            'ta': { name: 'Tamil', flag: '🇮🇳', native: 'தமிழ்' },
            'mr': { name: 'Marathi', flag: '🇮🇳', native: 'मराठी' },
            'gu': { name: 'Gujarati', flag: '🇮🇳', native: 'ગુજરાતી' },
            'pa': { name: 'Punjabi', flag: '🇮🇳', native: 'ਪੰਜਾਬੀ' },
            'bn': { name: 'Bengali', flag: '🇮🇳', native: 'বাংলা' },
            'ur': { name: 'Urdu', flag: '🇵🇰', native: 'اردو' },
            'es': { name: 'Spanish', flag: '🇪🇸', native: 'Español' },
            'fr': { name: 'French', flag: '🇫🇷', native: 'Français' },
            'de': { name: 'German', flag: '🇩🇪', native: 'Deutsch' },
            'zh': { name: 'Chinese', flag: '🇨🇳', native: '中文' },
            'ja': { name: 'Japanese', flag: '🇯🇵', native: '日本語' },
            'ko': { name: 'Korean', flag: '🇰🇷', native: '한국어' }
        };

        this.translations = this.loadTranslations();
        this.init();
    }

    init() {
        this.createLanguageSelector();
        this.updateUILanguage();
    }

    createLanguageSelector() {
        const headerActions = document.querySelector('.header-actions');
        if (!headerActions) return;

        const languageSelector = document.createElement('div');
        languageSelector.className = 'language-selector';
        languageSelector.innerHTML = `
            <div class="language-dropdown">
                <button class="language-btn" id="languageBtn" title="Select Language">
                    <span class="language-flag">🇺🇸</span>
                    <span class="language-text">EN</span>
                    <i class="fas fa-chevron-down"></i>
                </button>
                <div class="language-menu" id="languageMenu" style="display: none;">
                    <div class="language-search">
                        <input type="text" placeholder="Search languages..." id="languageSearch">
                        <i class="fas fa-search"></i>
                    </div>
                    <div class="language-list" id="languageList">
                        ${this.generateLanguageOptions()}
                    </div>
                </div>
            </div>
        `;

        // Insert before the multimedia button
        const multimediaBtn = headerActions.querySelector('.multimedia-btn');
        headerActions.insertBefore(languageSelector, multimediaBtn);

        this.attachLanguageSelectorEvents();
    }

    generateLanguageOptions() {
        return Object.entries(this.supportedLanguages)
            .map(([code, lang]) => `
                <div class="language-option" data-lang="${code}">
                    <span class="language-flag">${lang.flag}</span>
                    <div class="language-info">
                        <div class="language-name">${lang.name}</div>
                        <div class="language-native">${lang.native}</div>
                    </div>
                    <span class="language-code">${code.toUpperCase()}</span>
                </div>
            `).join('');
    }

    attachLanguageSelectorEvents() {
        const languageBtn = document.getElementById('languageBtn');
        const languageMenu = document.getElementById('languageMenu');
        const languageSearch = document.getElementById('languageSearch');
        const languageList = document.getElementById('languageList');

        // Toggle dropdown
        languageBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const isVisible = languageMenu.style.display === 'block';
            languageMenu.style.display = isVisible ? 'none' : 'block';
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', () => {
            languageMenu.style.display = 'none';
        });

        // Language search
        languageSearch.addEventListener('input', (e) => {
            const searchTerm = e.target.value.toLowerCase();
            const options = languageList.querySelectorAll('.language-option');

            options.forEach(option => {
                const langName = option.querySelector('.language-name').textContent.toLowerCase();
                const langNative = option.querySelector('.language-native').textContent.toLowerCase();
                const langCode = option.dataset.lang.toLowerCase();

                const matches = langName.includes(searchTerm) ||
                               langNative.includes(searchTerm) ||
                               langCode.includes(searchTerm);

                option.style.display = matches ? 'flex' : 'none';
            });
        });

        // Language selection
        languageList.addEventListener('click', (e) => {
            const option = e.target.closest('.language-option');
            if (option) {
                const langCode = option.dataset.lang;
                this.setLanguage(langCode);
                languageMenu.style.display = 'none';
                languageSearch.value = '';
                // Reset search filter
                const options = languageList.querySelectorAll('.language-option');
                options.forEach(opt => opt.style.display = 'flex');
            }
        });
    }

    setLanguage(languageCode) {
        if (this.supportedLanguages[languageCode]) {
            this.currentLanguage = languageCode;
            this.multimediaAI.setLanguage(languageCode);
            this.updateUILanguage();
            this.showLanguageNotification();

            // Save preference
            localStorage.setItem('navabharat-ai-language', languageCode);

            console.log(`Language changed to: ${this.supportedLanguages[languageCode].name}`);
            return true;
        }
        return false;
    }

    updateUILanguage() {
        const languageBtn = document.getElementById('languageBtn');
        if (languageBtn) {
            const currentLang = this.supportedLanguages[this.currentLanguage];
            const flagElement = languageBtn.querySelector('.language-flag');
            const textElement = languageBtn.querySelector('.language-text');

            if (flagElement) flagElement.textContent = currentLang.flag;
            if (textElement) textElement.textContent = this.currentLanguage.toUpperCase();
        }

        // Update placeholder text
        this.updatePlaceholderText();

        // Update suggestion buttons
        this.updateSuggestionButtons();
    }

    updatePlaceholderText() {
        const messageInput = document.getElementById('messageInput');
        if (messageInput) {
            const placeholders = {
                en: "Message NavaBharat AI or upload files...",
                hi: "NavaBharat AI को संदेश दें या फाइलें अपलोड करें...",
                te: "NavaBharat AIకి సందేశం పంపండి లేదా ఫైల్‌లను అప్‌లోడ్ చేయండి...",
                ta: "NavaBharat AI-க்கு செய்தி அனுப்பவும் அல்லது கோப்புகளை பதிவேற்றவும்...",
                mr: "NavaBharat AI ला संदेश पाठवा किंवा फायली अपलोड करा...",
                gu: "NavaBharat AIને સંદેશો મોકલો અથવા ફાઇલો અપલોડ કરો...",
                pa: "NavaBharat AI ਨੂੰ ਸੰਦੇਸ਼ ਭੇਜੋ ਜਾਂ ਫਾਈਲਾਂ ਅੱਪਲੋਡ ਕਰੋ...",
                bn: "NavaBharat AI-কে বার্তা পাঠান বা ফাইল আপলোড করুন...",
                ur: "NavaBharat AI کو پیغام بھیجیں یا فائلیں اپ لوڈ کریں...",
                es: "Envía un mensaje a NavaBharat AI o sube archivos...",
                fr: "Envoyez un message à NavaBharat AI ou téléchargez des fichiers...",
                de: "Senden Sie eine Nachricht an NavaBharat AI oder laden Sie Dateien hoch...",
                zh: "向 NavaBharat AI 发送消息或上传文件...",
                ja: "NavaBharat AI にメッセージを送信するかファイルをアップロードしてください...",
                ko: "NavaBharat AI에게 메시지를 보내거나 파일을 업로드하세요..."
            };

            messageInput.placeholder = placeholders[this.currentLanguage] || placeholders['en'];
        }
    }

    updateSuggestionButtons() {
        const suggestions = document.querySelectorAll('.suggestion-btn');
        const suggestionTexts = {
            en: ["Write an email", "Explain quantum physics", "Create a recipe", "Plan a trip"],
            hi: ["ईमेल लिखें", "क्वांटम भौतिकी समझाएं", "रेसिपी बनाएं", "यात्रा की योजना बनाएं"],
            te: ["ఇమెయిల్ రాయండి", "క్వాంటమ్ భౌతిక శాస్త్రాన్ని వివరించండి", "వంటకం సృష్టించండి", "ప్రయాణాన్ని ప్రణాళిక చేయండి"],
            ta: ["மின்னஞ்சல் எழுது", "குவாண்டம் இயற்பியலை விளக்கு", "சமையல் குறிப்பை உருவாக்கு", "பயணத்தை திட்டமிடு"],
            mr: ["ईमेल लिहा", "क्वांटम भौतिकशास्त्र समजावून सांगा", "रेसिपी तयार करा", "प्रवासाचे नियोजन करा"],
            gu: ["ઈમેલ લખો", "ક્વોન્ટમ ભૌતિકશાસ્ત્ર સમજાવો", "રેસિપી બનાવો", "પ્રવાસનું આયોજન કરો"],
            pa: ["ਈਮੇਲ ਲਿਖੋ", "ਕੁਆਂਟਮ ਭੌਤਿਕ ਵਿਗਿਆਨ ਸਮਝਾਓ", "ਰੈਸਿਪੀ ਬਣਾਓ", "ਸਫ਼ਰ ਦੀ ਯੋਜਨਾ ਬਣਾਓ"],
            bn: ["ইমেইল লিখুন", "কোয়ান্টাম পদার্থবিদ্যা ব্যাখ্যা করুন", "রেসিপি তৈরি করুন", "ভ্রমণের পরিকল্পনা করুন"],
            ur: ["ای میل لکھیں", "کوانٹم طبیعیات کی وضاحت کریں", "نسخہ بنائیں", "سفر کی منصوبہ بندی کریں"],
            es: ["Escribir un correo", "Explicar física cuántica", "Crear una receta", "Planificar un viaje"],
            fr: ["Écrire un email", "Expliquer la physique quantique", "Créer une recette", "Planifier un voyage"],
            de: ["E-Mail schreiben", "Quantenphysik erklären", "Rezept erstellen", "Reise planen"],
            zh: ["写邮件", "解释量子物理", "创建食谱", "计划旅行"],
            ja: ["メールを書く", "量子物理を説明する", "レシピを作成する", "旅行を計画する"],
            ko: ["이메일 쓰기", "양자 물리학 설명", "레시피 만들기", "여행 계획"]
        };

        const texts = suggestionTexts[this.currentLanguage] || suggestionTexts['en'];

        suggestions.forEach((btn, index) => {
            if (texts[index] && !btn.classList.contains('multimedia-suggestion')) {
                btn.textContent = texts[index];
            }
        });
    }

    showLanguageNotification() {
        const notification = document.createElement('div');
        notification.className = 'language-notification';
        notification.innerHTML = `
            <div class="notification-content">
                <span class="notification-flag">${this.supportedLanguages[this.currentLanguage].flag}</span>
                <span class="notification-text">Language changed to ${this.supportedLanguages[this.currentLanguage].name}</span>
            </div>
        `;

        document.body.appendChild(notification);

        // Show notification with animation
        setTimeout(() => notification.classList.add('show'), 100);

        // Hide after 3 seconds
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => document.body.removeChild(notification), 300);
        }, 3000);
    }

    loadTranslations() {
        return {
            en: {
                processingFile: "Processing file...",
                analyzingImage: "Analyzing image...",
                extractingText: "Extracting text...",
                processingDocument: "Processing document...",
                analyzingVideo: "Analyzing video...",

                fileInformation: "File Information",
                aiAnalysis: "AI Analysis",
                extractedText: "Extracted Text",
                colorAnalysis: "Color Analysis",
                documentInformation: "Document Information",
                contentPreview: "Content Preview",
                summary: "Summary",
                keyInformation: "Key Information",
                videoInformation: "Video Information",
                transcription: "Transcription",
                sceneAnalysis: "Scene Analysis",

                whatWouldYouLike: "What would you like to know more about?",
                regardingQuestion: "Regarding your question",
                iCanHelp: "I can help you understand the content and provide insights.",

                analyzeSpecific: "Analyze specific aspects",
                extractText: "Extract and explain any text",
                describeObjects: "Describe objects or scenes in detail",
                compareImages: "Compare with other images",
                extractInfo: "Extract specific information",
                summarizeContent: "Summarize sections or the entire document",
                answerQuestions: "Answer questions about the content",
                compareDocuments: "Compare with other documents",
                provideTranscription: "Provide detailed transcription",
                analyzeScenes: "Analyze specific scenes or timestamps",
                summarizeVideo: "Summarize the video content",
                answerVideoQuestions: "Answer questions about what's shown or said"
            },
            hi: {
                processingFile: "फ़ाइल प्रोसेस कर रहा हूं...",
                analyzingImage: "इमेज का विश्लेषण कर रहा हूं...",
                extractingText: "टेक्स्ट निकाल रहा हूं...",
                processingDocument: "दस्तावेज़ प्रोसेस कर रहा हूं...",
                analyzingVideo: "वीडियो का विश्लेषण कर रहा हूं...",

                fileInformation: "फ़ाइल जानकारी",
                aiAnalysis: "AI विश्लेषण",
                extractedText: "निकाला गया टेक्स्ट",
                colorAnalysis: "रंग विश्लेषण",
                documentInformation: "दस्तावेज़ जानकारी",
                contentPreview: "सामग्री पूर्वावलोकन",
                summary: "सारांश",
                keyInformation: "मुख्य जानकारी",
                videoInformation: "वीडियो जानकारी",
                transcription: "प्रतिलेखन",
                sceneAnalysis: "दृश्य विश्लेषण",

                whatWouldYouLike: "आप और क्या जानना चाहेंगे?",
                regardingQuestion: "आपके प्रश्न के संबंध में",
                iCanHelp: "मैं सामग्री को समझने और अंतर्दृष्टि प्रदान करने में आपकी मदद कर सकता हूं।",

                analyzeSpecific: "विशिष्ट पहलुओं का विश्लेषण करें",
                extractText: "कोई भी टेक्स्ट निकालें और समझाएं",
                describeObjects: "वस्तुओं या दृश्यों का विस्तार से वर्णन करें",
                compareImages: "अन्य इमेज के साथ तुलना करें",
                extractInfo: "विशिष्ट जानकारी निकालें",
                summarizeContent: "अनुभागों या संपूर्ण दस्तावेज़ का सारांश बनाएं",
                answerQuestions: "सामग्री के बारे में प्रश्नों के उत्तर दें",
                compareDocuments: "अन्य दस्तावेज़ों के साथ तुलना करें",
                provideTranscription: "विस्तृत प्रतिलेखन प्रदान करें",
                analyzeScenes: "विशिष्ट दृश्यों या टाइमस्टैम्प का विश्लेषण करें",
                summarizeVideo: "वीडियो सामग्री का सारांश बनाएं",
                answerVideoQuestions: "जो दिखाया या कहा गया है उसके बारे में प्रश्नों के उत्तर दें"
            },
            te: {
                processingFile: "ఫైల్ ప్రాసెస్ చేస్తున్నాను...",
                analyzingImage: "ఇమేజ్ విశ్లేషణ చేస్తున్నాను...",
                extractingText: "టెక్స్ట్ సంగ్రహిస్తున్నాను...",
                processingDocument: "డాక్యుమెంట్ ప్రాసెస్ చేస్తున్నాను...",
                analyzingVideo: "వీడియో విశ్లేషణ చేస్తున్నాను...",

                fileInformation: "ఫైల్ సమాచారం",
                aiAnalysis: "AI విశ్లేషణ",
                extractedText: "సంగ్రహించిన టెక్స్ట్",
                colorAnalysis: "రంగు విశ్లేషణ",
                documentInformation: "డాక్యుమెంట్ సమాచారం",
                contentPreview: "కంటెంట్ ప్రివ్యూ",
                summary: "సారాంశం",
                keyInformation: "ముఖ్య సమాచారం",
                videoInformation: "వీడియో సమాచారం",
                transcription: "ట్రాన్స్క్రిప్షన్",
                sceneAnalysis: "సీన్ విశ్లేషణ",

                whatWouldYouLike: "మీరు ఇంకా ఏమి తెలుసుకోవాలనుకుంటున్నారు?",
                regardingQuestion: "మీ ప్రశ్నకు సంబంధించి",
                iCanHelp: "నేను కంటెంట్ అర్థం చేసుకోవడంలో మరియు అంతర్దృష్టులు అందించడంలో మీకు సహాయపడగలను.",

                analyzeSpecific: "నిర్దిష్ట అంశాలను విశ్లేషించండి",
                extractText: "టెక్స్ట్ సంగ్రహించండి మరియు వివరించండి",
                describeObjects: "వస్తువులు లేదా దృశ్యాలను వివరంగా వర్ణించండి",
                compareImages: "ఇతర చిత్రాలతో పోల్చండి",
                extractInfo: "నిర్దిష్ట సమాచారాన్ని సంగ్రహించండి",
                summarizeContent: "విభాగాలు లేదా మొత్తం డాక్యుమెంట్ సారాంశం",
                answerQuestions: "కంటెంట్ గురించి ప్రశ్నలకు సమాధానం ఇవ్వండి",
                compareDocuments: "ఇతర డాక్యుమెంట్లతో పోల్చండి",
                provideTranscription: "వివరణాత్మక ట్రాన్స్క్రిప్షన్ అందించండి",
                analyzeScenes: "నిర్దిష్ట దృశ్యాలు లేదా టైమ్‌స్టాంప్‌లను విశ్లేషించండి",
                summarizeVideo: "వీడియో కంటెంట్ సారాంశం",
                answerVideoQuestions: "చూపిన లేదా చెప్పిన దాని గురించి ప్రశ్నలకు సమాధానం ఇవ్వండి"
            }
        };
    }

    translate(key, language = null) {
        const lang = language || this.currentLanguage;
        return this.translations[lang]?.[key] || this.translations['en'][key] || key;
    }

    // Load saved language preference
    loadSavedLanguage() {
        const saved = localStorage.getItem('navabharat-ai-language');
        if (saved && this.supportedLanguages[saved]) {
            this.setLanguage(saved);
        }
    }
}

// Make it globally available
window.MultilingualSupport = MultilingualSupport;

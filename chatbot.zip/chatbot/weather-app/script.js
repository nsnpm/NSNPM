// AI Weather App JavaScript
class WeatherApp {
    constructor() {
        this.apiKey = 'YOUR_OPENWEATHERMAP_API_KEY'; // Replace with actual API key
        this.currentWeather = null;
        this.forecast = null;
        this.recentSearches = [];
        this.favorites = [];

        this.initializeElements();
        this.bindEvents();
        this.addThemeToggle();
        this.loadSavedData();
        this.loadDefaultCity();
    }

    initializeElements() {
        this.cityInput = document.getElementById('cityInput');
        this.searchBtn = document.getElementById('searchBtn');
        this.locationBtn = document.getElementById('locationBtn');
        this.weatherSection = document.getElementById('weatherSection');
        this.loading = document.getElementById('loading');
        this.errorMessage = document.getElementById('errorMessage');
        this.errorText = document.getElementById('errorText');
        this.retryBtn = document.getElementById('retryBtn');
        this.recentSearches = document.getElementById('recentSearches');
        this.favoritesGrid = document.getElementById('favoritesGrid');

        // Weather display elements
        this.cityName = document.getElementById('cityName');
        this.temperature = document.getElementById('temperature');
        this.weatherDescription = document.getElementById('weatherDescription');
        this.weatherIcon = document.getElementById('weatherIcon');
        this.feelsLike = document.getElementById('feelsLike');
        this.humidity = document.getElementById('humidity');
        this.windSpeed = document.getElementById('windSpeed');
        this.pressure = document.getElementById('pressure');
        this.visibility = document.getElementById('visibility');
        this.uvIndex = document.getElementById('uvIndex');
        this.forecastContainer = document.getElementById('forecastContainer');
        this.insightsContent = document.getElementById('insightsContent');
    }

    bindEvents() {
        this.searchBtn.addEventListener('click', () => this.searchWeather());
        this.locationBtn.addEventListener('click', () => this.getCurrentLocation());
        this.cityInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.searchWeather();
        });
        this.retryBtn.addEventListener('click', () => this.retrySearch());

        // Add favorite functionality
        document.querySelector('.add-favorite').addEventListener('click', () => this.addToFavorites());
    }

    addThemeToggle() {
        const themeToggle = document.createElement('button');
        themeToggle.className = 'theme-btn';
        themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        themeToggle.title = 'Toggle theme';
        themeToggle.addEventListener('click', () => this.toggleTheme());

        const themeContainer = document.createElement('div');
        themeContainer.className = 'theme-toggle';
        themeContainer.appendChild(themeToggle);
        document.body.appendChild(themeContainer);

        // Load saved theme
        const savedTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', savedTheme);
        this.updateThemeIcon(savedTheme);
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        this.updateThemeIcon(newTheme);
    }

    updateThemeIcon(theme) {
        const themeBtn = document.querySelector('.theme-btn i');
        if (theme === 'dark') {
            themeBtn.className = 'fas fa-sun';
        } else {
            themeBtn.className = 'fas fa-moon';
        }
    }

    loadSavedData() {
        const savedRecent = localStorage.getItem('recentSearches');
        const savedFavorites = localStorage.getItem('favorites');

        if (savedRecent) {
            this.recentSearches = JSON.parse(savedRecent);
            this.updateRecentSearches();
        }

        if (savedFavorites) {
            this.favorites = JSON.parse(savedFavorites);
            this.updateFavorites();
        }
    }

    loadDefaultCity() {
        // Try to load weather for a default city or last searched city
        const lastCity = localStorage.getItem('lastCity');
        if (lastCity) {
            this.cityInput.value = lastCity;
            this.searchWeather();
        }
    }

    async searchWeather() {
        const city = this.cityInput.value.trim();

        if (!city) {
            this.showNotification('Please enter a city name', 'warning');
            return;
        }

        this.showLoading();
        this.hideError();

        try {
            const weatherData = await this.fetchWeatherData(city);
            const forecastData = await this.fetchForecastData(city);

            this.currentWeather = weatherData;
            this.forecast = forecastData;

            this.displayWeather(weatherData);
            this.displayForecast(forecastData);
            this.generateAIInsights(weatherData);

            this.addToRecentSearches(city);
            localStorage.setItem('lastCity', city);

            this.showNotification('Weather data loaded successfully!', 'success');
        } catch (error) {
            console.error('Weather search error:', error);
            this.showError(error.message);
        } finally {
            this.hideLoading();
        }
    }

    async getCurrentLocation() {
        if (!navigator.geolocation) {
            this.showNotification('Geolocation is not supported by this browser', 'error');
            return;
        }

        this.showLoading();
        this.locationBtn.disabled = true;
        this.locationBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

        navigator.geolocation.getCurrentPosition(
            async (position) => {
                try {
                    const { latitude, longitude } = position.coords;
                    const weatherData = await this.fetchWeatherByCoords(latitude, longitude);
                    const forecastData = await this.fetchForecastByCoords(latitude, longitude);

                    this.currentWeather = weatherData;
                    this.forecast = forecastData;

                    this.displayWeather(weatherData);
                    this.displayForecast(forecastData);
                    this.generateAIInsights(weatherData);

                    this.cityInput.value = weatherData.name;
                    localStorage.setItem('lastCity', weatherData.name);

                    this.showNotification('Location weather loaded!', 'success');
                } catch (error) {
                    console.error('Location weather error:', error);
                    this.showError('Unable to fetch weather for your location');
                }
            },
            (error) => {
                console.error('Geolocation error:', error);
                let message = 'Unable to get your location';
                switch (error.code) {
                    case error.PERMISSION_DENIED:
                        message = 'Location access denied. Please enable location permissions.';
                        break;
                    case error.POSITION_UNAVAILABLE:
                        message = 'Location information is unavailable.';
                        break;
                    case error.TIMEOUT:
                        message = 'Location request timed out.';
                        break;
                }
                this.showError(message);
            }
        );

        this.locationBtn.disabled = false;
        this.locationBtn.innerHTML = '<i class="fas fa-map-marker-alt"></i>';
        this.hideLoading();
    }

    async fetchWeatherData(city) {
        // Mock API call - replace with actual OpenWeatherMap API
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    name: city,
                    main: {
                        temp: 25 + Math.random() * 10,
                        feels_like: 27 + Math.random() * 8,
                        humidity: 60 + Math.random() * 30,
                        pressure: 1013 + Math.random() * 20
                    },
                    weather: [{
                        main: 'Clear',
                        description: 'clear sky',
                        icon: '01d'
                    }],
                    wind: {
                        speed: 5 + Math.random() * 10
                    },
                    visibility: 10000,
                    sys: {
                        country: 'IN'
                    },
                    coord: {
                        lat: 28.6139,
                        lon: 77.2090
                    }
                });
            }, 1500);
        });

        // Uncomment for actual API:
        /*
        const response = await fetch(
            `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${this.apiKey}&units=metric`
        );

        if (!response.ok) {
            throw new Error(`City "${city}" not found`);
        }

        return await response.json();
        */
    }

    async fetchForecastData(city) {
        // Mock forecast data
        return new Promise((resolve) => {
            setTimeout(() => {
                const forecast = [];
                for (let i = 0; i < 5; i++) {
                    forecast.push({
                        dt: Date.now() + (i * 24 * 60 * 60 * 1000),
                        main: {
                            temp: 20 + Math.random() * 15
                        },
                        weather: [{
                            main: ['Clear', 'Clouds', 'Rain'][Math.floor(Math.random() * 3)],
                            description: 'weather description',
                            icon: '01d'
                        }]
                    });
                }
                resolve({ list: forecast });
            }, 1000);
        });

        // Uncomment for actual API:
        /*
        const response = await fetch(
            `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${this.apiKey}&units=metric`
        );

        if (!response.ok) {
            throw new Error('Unable to fetch forecast data');
        }

        return await response.json();
        */
    }

    async fetchWeatherByCoords(lat, lon) {
        // Mock coordinates weather
        return this.fetchWeatherData('Delhi');

        // Uncomment for actual API:
        /*
        const response = await fetch(
            `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${this.apiKey}&units=metric`
        );

        if (!response.ok) {
            throw new Error('Unable to fetch weather for your location');
        }

        return await response.json();
        */
    }

    async fetchForecastByCoords(lat, lon) {
        return this.fetchForecastData('Delhi');

        // Uncomment for actual API:
        /*
        const response = await fetch(
            `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${this.apiKey}&units=metric`
        );

        if (!response.ok) {
            throw new Error('Unable to fetch forecast data');
        }

        return await response.json();
        */
    }

    displayWeather(data) {
        this.cityName.textContent = `${data.name}, ${data.sys.country}`;
        this.temperature.textContent = `${Math.round(data.main.temp)}°C`;
        this.weatherDescription.textContent = data.weather[0].description;

        // Update weather icon
        const iconClass = this.getWeatherIcon(data.weather[0].icon);
        this.weatherIcon.innerHTML = `<i class="${iconClass}"></i>`;

        // Update details
        this.feelsLike.textContent = `${Math.round(data.main.feels_like)}°C`;
        this.humidity.textContent = `${data.main.humidity}%`;
        this.windSpeed.textContent = `${data.wind.speed.toFixed(1)} km/h`;
        this.pressure.textContent = `${data.main.pressure} hPa`;
        this.visibility.textContent = `${(data.visibility / 1000).toFixed(1)} km`;
        this.uvIndex.textContent = this.getUVIndex(data.main.temp); // Mock UV index

        this.weatherSection.style.display = 'grid';
    }

    displayForecast(data) {
        this.forecastContainer.innerHTML = '';

        data.list.slice(0, 5).forEach((item, index) => {
            const date = new Date(item.dt * 1000);
            const dayName = index === 0 ? 'Today' : date.toLocaleDateString('en-US', { weekday: 'short' });

            const forecastItem = document.createElement('div');
            forecastItem.className = 'forecast-item';
            forecastItem.innerHTML = `
                <div class="forecast-date">${dayName}</div>
                <div class="forecast-icon">
                    <i class="${this.getWeatherIcon(item.weather[0].icon)}"></i>
                </div>
                <div class="forecast-temp">${Math.round(item.main.temp)}°C</div>
                <div class="forecast-desc">${item.weather[0].description}</div>
            `;

            this.forecastContainer.appendChild(forecastItem);
        });
    }

    generateAIInsights(weatherData) {
        const temp = weatherData.main.temp;
        const humidity = weatherData.main.humidity;
        const windSpeed = weatherData.wind.speed;
        const condition = weatherData.weather[0].main.toLowerCase();

        let insights = [];

        // Temperature insights
        if (temp > 30) {
            insights.push({
                icon: 'fas fa-sun',
                text: 'High temperature detected. Stay hydrated and avoid prolonged sun exposure. Consider indoor activities.'
            });
        } else if (temp < 10) {
            insights.push({
                icon: 'fas fa-snowflake',
                text: 'Cold weather ahead. Dress warmly and consider indoor heating options.'
            });
        }

        // Humidity insights
        if (humidity > 80) {
            insights.push({
                icon: 'fas fa-tint',
                text: 'High humidity may cause discomfort. Use dehumidifiers and stay in well-ventilated areas.'
            });
        }

        // Wind insights
        if (windSpeed > 15) {
            insights.push({
                icon: 'fas fa-wind',
                text: 'Strong winds detected. Secure loose objects and be cautious while driving.'
            });
        }

        // Weather condition insights
        if (condition.includes('rain')) {
            insights.push({
                icon: 'fas fa-umbrella',
                text: 'Rain expected. Don\'t forget your umbrella and consider waterproof clothing.'
            });
        } else if (condition.includes('clear')) {
            insights.push({
                icon: 'fas fa-sun',
                text: 'Clear skies! Perfect weather for outdoor activities and enjoying nature.'
            });
        }

        // Default insight if none generated
        if (insights.length === 0) {
            insights.push({
                icon: 'fas fa-info-circle',
                text: 'Weather conditions are moderate. Enjoy your day with normal outdoor activities.'
            });
        }

        this.displayInsights(insights);
    }

    displayInsights(insights) {
        this.insightsContent.innerHTML = insights.map(insight => `
            <div class="insight-item">
                <i class="${insight.icon}"></i>
                <div class="insight-text">${insight.text}</div>
            </div>
        `).join('');
    }

    getWeatherIcon(iconCode) {
        const iconMap = {
            '01d': 'fas fa-sun',
            '01n': 'fas fa-moon',
            '02d': 'fas fa-cloud-sun',
            '02n': 'fas fa-cloud-moon',
            '03d': 'fas fa-cloud',
            '03n': 'fas fa-cloud',
            '04d': 'fas fa-cloud',
            '04n': 'fas fa-cloud',
            '09d': 'fas fa-cloud-rain',
            '09n': 'fas fa-cloud-rain',
            '10d': 'fas fa-cloud-showers-heavy',
            '10n': 'fas fa-cloud-showers-heavy',
            '11d': 'fas fa-bolt',
            '11n': 'fas fa-bolt',
            '13d': 'fas fa-snowflake',
            '13n': 'fas fa-snowflake',
            '50d': 'fas fa-smog',
            '50n': 'fas fa-smog'
        };

        return iconMap[iconCode] || 'fas fa-sun';
    }

    getUVIndex(temp) {
        // Mock UV index based on temperature
        if (temp > 30) return '8-10 (Very High)';
        if (temp > 25) return '6-7 (High)';
        if (temp > 20) return '3-5 (Moderate)';
        return '1-2 (Low)';
    }

    addToRecentSearches(city) {
        // Remove if already exists
        this.recentSearches = this.recentSearches.filter(c => c.toLowerCase() !== city.toLowerCase());

        // Add to beginning
        this.recentSearches.unshift(city);

        // Keep only last 5
        if (this.recentSearches.length > 5) {
            this.recentSearches = this.recentSearches.slice(0, 5);
        }

        this.saveRecentSearches();
        this.updateRecentSearches();
    }

    updateRecentSearches() {
        this.recentSearches.innerHTML = this.recentSearches.map(city => `
            <div class="recent-search-item" data-city="${city}">${city}</div>
        `).join('');

        // Add click handlers
        document.querySelectorAll('.recent-search-item').forEach(item => {
            item.addEventListener('click', () => {
                this.cityInput.value = item.dataset.city;
                this.searchWeather();
            });
        });
    }

    saveRecentSearches() {
        localStorage.setItem('recentSearches', JSON.stringify(this.recentSearches));
    }

    addToFavorites() {
        if (!this.currentWeather) {
            this.showNotification('No weather data to add to favorites', 'warning');
            return;
        }

        const city = this.currentWeather.name;

        // Check if already in favorites
        if (this.favorites.some(fav => fav.name === city)) {
            this.showNotification('City already in favorites', 'warning');
            return;
        }

        const favorite = {
            name: city,
            country: this.currentWeather.sys.country,
            temp: Math.round(this.currentWeather.main.temp),
            condition: this.currentWeather.weather[0].main,
            icon: this.currentWeather.weather[0].icon
        };

        this.favorites.push(favorite);
        this.saveFavorites();
        this.updateFavorites();

        this.showNotification('Added to favorites!', 'success');
    }

    updateFavorites() {
        const favoritesHtml = this.favorites.map(fav => `
            <div class="favorite-item" data-city="${fav.name}">
                <i class="${this.getWeatherIcon(fav.icon)}"></i>
                <div class="favorite-name">${fav.name}</div>
                <div class="favorite-temp">${fav.temp}°C</div>
            </div>
        `).join('');

        this.favoritesGrid.innerHTML = `
            <div class="add-favorite">
                <i class="fas fa-plus"></i>
                <span>Add City</span>
            </div>
            ${favoritesHtml}
        `;

        // Re-bind add favorite event
        document.querySelector('.add-favorite').addEventListener('click', () => this.addToFavorites());

        // Add click handlers for favorites
        document.querySelectorAll('.favorite-item').forEach(item => {
            item.addEventListener('click', () => {
                this.cityInput.value = item.dataset.city;
                this.searchWeather();
            });
        });
    }

    saveFavorites() {
        localStorage.setItem('favorites', JSON.stringify(this.favorites));
    }

    showLoading() {
        this.weatherSection.style.display = 'none';
        this.errorMessage.style.display = 'none';
        this.loading.style.display = 'block';
    }

    hideLoading() {
        this.loading.style.display = 'none';
    }

    showError(message) {
        this.weatherSection.style.display = 'none';
        this.errorMessage.style.display = 'block';
        this.errorText.textContent = message;
    }

    hideError() {
        this.errorMessage.style.display = 'none';
    }

    retrySearch() {
        this.searchWeather();
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 4000);
    }
}

// Initialize the weather app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const weatherApp = new WeatherApp();
});

// GPT-like Interface JavaScript
class ChatGPTInterface {
    constructor() {
        this.chatId = crypto.randomUUID();
        this.receivingMessage = false;
        this.messageHistory = [];
        this.systemPrompt = "You are NavaBharat AI, an advanced AI assistant designed to provide helpful and knowledgeable responses to the user's inquiries. You are built to serve the Indian community with culturally relevant and accurate information.";

        // Initialize after a short delay to ensure DOM is ready
        setTimeout(() => {
            this.initializeElements();
            this.bindEvents();
            this.showWelcomeSection();
            console.log("NavaB Interface initialized successfully!");
        }, 100);
    }


    


    initializeElements() {
        this.chatMessages = document.getElementById("mainChatBox");
        this.messageInput = document.getElementById("messageInput");
        this.sendButton = document.getElementById("sendButton");
        this.typingIndicator = document.getElementById("typingIndicator");
        this.welcomeSection = document.getElementById("welcomeSection");
        this.newChatBtn = document.getElementById("newChatBtn");

        // Sidebar elements
        this.sidebar = document.getElementById("sidebar");
        this.sidebarToggle = document.getElementById("sidebarToggle");
        this.closeSidebar = document.getElementById("closeSidebar");
        this.chatList = document.getElementById("chatList");

        // New feature elements
        this.fileUploadArea = document.getElementById("fileUploadArea");
        this.uploadZone = document.getElementById("uploadZone");
        this.filePreview = document.getElementById("filePreview");
        this.previewFileName = document.getElementById("previewFileName");
        this.previewContent = document.getElementById("previewContent");
        this.removeFile = document.getElementById("removeFile");
        this.fileBtn = document.getElementById("fileBtn");
        this.voiceBtn = document.getElementById("voiceBtn");
        this.browseBtn = document.getElementById("browseBtn");
        this.emojiBtn = document.getElementById("emojiBtn");
        this.themeToggle = document.getElementById("themeToggle");
        this.messageCount = document.getElementById("messageCount");

        // Browse content elements
        this.browseContentArea = document.getElementById("browseContentArea");
        this.browseQueryInput = document.getElementById("browseQueryInput");
        this.submitBrowseQuery = document.getElementById("submitBrowseQuery");
        this.browseResults = document.getElementById("browseResults");
        this.resultsList = document.getElementById("resultsList");
        this.closeBrowseResults = document.getElementById("closeBrowseResults");

        // Video Tools elements
        this.videoToolsArea = document.getElementById("videoToolsArea");
        this.closeVideoTools = document.getElementById("closeVideoTools");

        // Graph API elements
        this.graphArea = document.getElementById("graphArea");
        this.connectGraphBtn = document.getElementById("connectGraphBtn");
        this.closeGraph = document.getElementById("closeGraph");
        this.graphAuthSection = document.getElementById("graphAuthSection");
        this.graphServices = document.getElementById("graphServices");
        this.authStatus = document.getElementById("authStatus");

        // Graph service elements
        this.serviceTabs = document.querySelectorAll(".service-tab");
        this.servicePanels = document.querySelectorAll(".service-panel");

        // Excel elements
        this.excelFilePath = document.getElementById("excelFilePath");
        this.loadExcelBtn = document.getElementById("loadExcelBtn");
        this.excelData = document.getElementById("excelData");
        this.worksheetSelect = document.getElementById("worksheetSelect");
        this.excelTable = document.getElementById("excelTable");
        this.updateCellBtn = document.getElementById("updateCellBtn");
        this.addFormulaBtn = document.getElementById("addFormulaBtn");

        // Word elements
        this.wordFilePath = document.getElementById("wordFilePath");
        this.loadWordBtn = document.getElementById("loadWordBtn");
        this.wordContent = document.getElementById("wordContent");
        this.wordEditor = document.getElementById("wordEditor");
        this.saveWordBtn = document.getElementById("saveWordBtn");

        // OneDrive elements
        this.listFilesBtn = document.getElementById("listFilesBtn");
        this.uploadFileBtn = document.getElementById("uploadFileBtn");
        this.uploadFileInput = document.getElementById("uploadFileInput");
        this.onedriveFiles = document.getElementById("onedriveFiles");
        this.filesList = document.getElementById("filesList");

        // Outlook elements
        this.readEmailsBtn = document.getElementById("readEmailsBtn");
        this.composeEmailBtn = document.getElementById("composeEmailBtn");
        this.outlookContent = document.getElementById("outlookContent");
        this.emailsList = document.getElementById("emailsList");
        this.composeForm = document.getElementById("composeForm");
        this.emailTo = document.getElementById("emailTo");
        this.emailSubject = document.getElementById("emailSubject");
        this.emailBody = document.getElementById("emailBody");
        this.sendEmailBtn = document.getElementById("sendEmailBtn");

        // Tools popup elements
        this.toolsPopup = document.getElementById("toolsPopup");
        this.closeTools = document.getElementById("closeTools");
        this.toolFile = document.getElementById("toolFile");
        this.toolVoice = document.getElementById("toolVoice");
        this.toolBrowse = document.getElementById("toolBrowse");
        this.toolEmoji = document.getElementById("toolEmoji");

        // New AI capability tools
        this.toolMultilingual = document.getElementById("toolMultilingual");
        this.toolAISearch = document.getElementById("toolAISearch");
        this.toolCitedAnswers = document.getElementById("toolCitedAnswers");
        this.toolRealtime = document.getElementById("toolRealtime");
        this.toolFocusModes = document.getElementById("toolFocusModes");
        this.toolDiscover = document.getElementById("toolDiscover");
        this.toolCopilot = document.getElementById("toolCopilot");
        this.toolAIModes = document.getElementById("toolAIModes");
        this.toolUnlimitedUpload = document.getElementById("toolUnlimitedUpload");
        this.toolVideo = document.getElementById("toolVideo");
        this.toolPersonality = document.getElementById("toolPersonality");
        this.toolFunMode = document.getElementById("toolFunMode");
        this.toolRegularMode = document.getElementById("toolRegularMode");
        this.toolReasoning = document.getElementById("toolReasoning");
        this.toolMultimodal = document.getElementById("toolMultimodal");
        this.toolImageUnderstanding = document.getElementById("toolImageUnderstanding");
        this.toolVoiceInteraction = document.getElementById("toolVoiceInteraction");
        this.toolGoogleWorkspace = document.getElementById("toolGoogleWorkspace");
        this.toolAdvancedTools = document.getElementById("toolAdvancedTools");

        this.toolImage = document.getElementById("toolImage");
        this.toolCode = document.getElementById("toolCode");
        this.toolTranslate = document.getElementById("toolTranslate");
        this.toolCalc = document.getElementById("toolCalc");
        this.toolWeather = document.getElementById("toolWeather");
        this.toolNews = document.getElementById("toolNews");

        // Image generation elements
        this.imageGenArea = document.getElementById("imageGenArea");
        this.closeImageGen = document.getElementById("closeImageGen");
        this.imagePrompt = document.getElementById("imagePrompt");
        this.imageStyle = document.getElementById("imageStyle");
        this.generateImageBtn = document.getElementById("generateImageBtn");
        this.imagePreview = document.getElementById("imagePreview");
        this.imageLoading = document.getElementById("imageLoading");
        this.generatedImage = document.getElementById("generatedImage");
        this.downloadImage = document.getElementById("downloadImage");
        this.regenerateImage = document.getElementById("regenerateImage");

        // Code execution elements
        this.codeExecArea = document.getElementById("codeExecArea");
        this.closeCodeExec = document.getElementById("closeCodeExec");
        this.codeLanguage = document.getElementById("codeLanguage");
        this.codeInput = document.getElementById("codeInput");
        this.runCodeBtn = document.getElementById("runCodeBtn");
        this.clearCodeBtn = document.getElementById("clearCodeBtn");
        this.codeOutput = document.getElementById("codeOutput");
        this.clearOutputBtn = document.getElementById("clearOutputBtn");

        // Translation elements
        this.translateArea = document.getElementById("translateArea");
        this.closeTranslate = document.getElementById("closeTranslate");
        this.translateInput = document.getElementById("translateInput");
        this.sourceLanguage = document.getElementById("sourceLanguage");
        this.targetLanguage = document.getElementById("targetLanguage");
        this.swapLanguages = document.getElementById("swapLanguages");
        this.translateBtn = document.getElementById("translateBtn");
        this.translateOutput = document.getElementById("translateOutput");
        this.copyTranslation = document.getElementById("copyTranslation");

        // Calculator elements
        this.calcArea = document.getElementById("calcArea");
        this.closeCalc = document.getElementById("closeCalc");
        this.calcInput = document.getElementById("calcInput");
        this.calcButtons = document.querySelectorAll(".calc-btn");

        // Weather elements
        this.weatherArea = document.getElementById("weatherArea");
        this.closeWeather = document.getElementById("closeWeather");
        this.weatherLocation = document.getElementById("weatherLocation");
        this.getWeatherBtn = document.getElementById("getWeatherBtn");
        this.currentLocationBtn = document.getElementById("currentLocationBtn");
        this.weatherDisplay = document.getElementById("weatherDisplay");
        this.weatherLoading = document.getElementById("weatherLoading");
        this.weatherInfo = document.getElementById("weatherInfo");
        this.weatherIcon = document.getElementById("weatherIcon");
        this.weatherTemp = document.getElementById("weatherTemp");
        this.weatherDesc = document.getElementById("weatherDesc");
        this.weatherHumidity = document.getElementById("weatherHumidity");
        this.weatherWind = document.getElementById("weatherWind");
        this.weatherPressure = document.getElementById("weatherPressure");
        this.weatherVisibility = document.getElementById("weatherVisibility");

        // News elements
        this.newsArea = document.getElementById("newsArea");
        this.closeNews = document.getElementById("closeNews");
        this.newsCategories = document.querySelectorAll(".news-category-btn");
        this.newsFeed = document.getElementById("newsFeed");
        this.newsLoading = document.getElementById("newsLoading");

        // Voice recording elements
        this.voiceRecording = null;
        this.mediaRecorder = null;
        this.audioChunks = [];
        this.isRecording = false;
        this.recordingTimer = null;

        // File upload state
        this.selectedFile = null;
        this.uploadedFiles = [];

        // Theme state
        this.currentTheme = localStorage.getItem('theme') || 'dark';

        // Chat history
        const storedHistory = localStorage.getItem("navaBharatAIChatHistory");
        console.log("Raw localStorage data:", storedHistory);
        this.chatHistory = storedHistory ? JSON.parse(storedHistory) : [];
        console.log("Parsed chat history:", this.chatHistory);
        this.currentChatId = crypto.randomUUID();
    }

    bindEvents() {
        // Send message events
        this.sendButton.addEventListener("click", () => this.sendMessage());

        this.messageInput.addEventListener("keydown", (event) => {
            if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault();
                this.sendMessage();
            }
        });

        // Auto-resize textarea
        this.messageInput.addEventListener("input", () => this.autoResizeTextarea());

        // New chat button
        this.newChatBtn.addEventListener("click", () => this.startNewChat());

        // Sidebar events
        this.sidebarToggle.addEventListener("click", () => this.toggleSidebar());
        this.closeSidebar.addEventListener("click", () => this.closeSidebarPanel());

        // Clear history button
        const clearHistoryBtn = document.getElementById("clearHistoryBtn");
        if (clearHistoryBtn) {
            clearHistoryBtn.addEventListener("click", () => this.clearAllHistory());
        }

        // Suggestion buttons
        document.querySelectorAll(".suggestion-btn").forEach(btn => {
            btn.addEventListener("click", () => {
                this.messageInput.value = btn.textContent;
                this.sendMessage();
            });
        });

        // Load chat history
        this.loadChatHistory();

        // Initialize sidebar state
        this.initializeSidebar();

        // Add backdrop click handler
        document.addEventListener("click", (event) => this.handleBackdropClick(event));

        // Add document click handler for closing popups
        document.addEventListener("click", (event) => this.handleDocumentClick(event));

        // Initialize file upload functionality
        this.initializeFileUpload();

        // Initialize voice recording functionality
        this.initializeVoiceRecording();

        // Initialize browse content functionality
        this.initializeBrowseContent();

        // Initialize tools popup functionality
        this.initializeToolsPopup();

        // Initialize advanced tools functionality
        this.initializeImageGeneration();
        this.initializeCodeExecution();
        this.initializeTranslation();
        this.initializeCalculator();
        this.initializeWeather();
        this.initializeNews();
        this.initializeVideoTools();
        this.initializeGraphAPI();

        // Initialize emoji picker functionality
        this.initializeEmojiPicker();

        // Initialize theme toggle functionality
        this.initializeThemeToggle();

        // Initialize message counter
        this.updateMessageCount();
    }

    autoResizeTextarea() {
        this.messageInput.style.height = "auto";
        this.messageInput.style.height = Math.min(this.messageInput.scrollHeight, 200) + "px";
    }

    showWelcomeSection() {
        this.welcomeSection.style.display = "flex";
        this.chatMessages.style.display = "none";
        this.messageInput.value = "";
    }

    hideWelcomeSection() {
        this.welcomeSection.style.display = "none";
        this.chatMessages.style.display = "flex";
    }

    startNewChat() {
        this.messageHistory = [];
        this.chatMessages.innerHTML = "";
        this.showWelcomeSection();
        this.messageInput.value = "";
    }

    sendMessage() {
        const messageText = this.messageInput.value.trim();

        if ((!messageText && !this.selectedFile) || this.receivingMessage) return;

        // Hide welcome section when first message is sent
        if (this.messageHistory.length === 0) {
            this.hideWelcomeSection();
        }

        let finalMessage = messageText;

        // If there's a selected file, include it in the message
        if (this.selectedFile) {
            finalMessage = messageText ? `${messageText}\n[File: ${this.selectedFile.name}]` : `[File: ${this.selectedFile.name}]`;
            this.addMessageWithFile(this.selectedFile, finalMessage, "user");
            this.removeSelectedFile(); // Clear the file after sending
        } else {
            // Add user message
            this.addMessage(finalMessage, "user");
        }

        this.messageInput.value = "";

        // Connect to WebSocket
        this.connectWebSocket(finalMessage);
    }

    addMessage(text, sender, timestamp = null) {
        const messageDiv = document.createElement("div");
        messageDiv.className = `message ${sender}`;

        const avatarDiv = document.createElement("div");
        avatarDiv.className = "message-avatar";

        const avatarIcon = document.createElement("i");
        if (sender === "user") {
            avatarIcon.className = "fas fa-user";
        } else {
            avatarIcon.className = "fas fa-comment-dots";
        }
        avatarDiv.appendChild(avatarIcon);

        const contentDiv = document.createElement("div");
        contentDiv.className = "message-content";

        const bubbleDiv = document.createElement("div");
        bubbleDiv.className = "message-bubble";

        const textDiv = document.createElement("div");
        textDiv.className = "message-text";
        textDiv.textContent = text;

        bubbleDiv.appendChild(textDiv);

        // Add message actions for assistant messages
        if (sender === "assistant") {
            const actionsDiv = document.createElement("div");
            actionsDiv.className = "message-actions";

            const copyBtn = document.createElement("button");
            copyBtn.className = "action-btn";
            copyBtn.innerHTML = '<i class="fas fa-copy"></i>';
            copyBtn.title = "Copy message";
            copyBtn.onclick = () => this.copyMessage(text);

            const regenerateBtn = document.createElement("button");
            regenerateBtn.className = "action-btn";
            regenerateBtn.innerHTML = '<i class="fas fa-redo"></i>';
            regenerateBtn.title = "Regenerate response";
            regenerateBtn.onclick = () => this.regenerateResponse();

            actionsDiv.appendChild(copyBtn);
            actionsDiv.appendChild(regenerateBtn);
            bubbleDiv.appendChild(actionsDiv);
        }

        // Add timestamp
        if (timestamp || sender === "user") {
            const timeDiv = document.createElement("div");
            timeDiv.className = "message-time";
            timeDiv.textContent = timestamp || this.getCurrentTime();
            contentDiv.appendChild(timeDiv);
        }

        contentDiv.appendChild(bubbleDiv);

        // Append elements in the correct order based on sender
        if (sender === "user") {
            messageDiv.appendChild(contentDiv);
            messageDiv.appendChild(avatarDiv);
        } else {
            messageDiv.appendChild(avatarDiv);
            messageDiv.appendChild(contentDiv);
        }

        this.chatMessages.appendChild(messageDiv);
        this.scrollToBottom();

        // Store in history
        this.messageHistory.push({ text, sender, timestamp: timestamp || this.getCurrentTime() });

        // Auto-save chat history after each message (only if not loading from history)
        if (!this.isLoadingChat) {
            this.autoSaveChat();
        }
    }

    addMessageWithFile(file, text, sender, timestamp = null) {
        const messageDiv = document.createElement("div");
        messageDiv.className = `message ${sender}`;

        const avatarDiv = document.createElement("div");
        avatarDiv.className = "message-avatar";

        const avatarIcon = document.createElement("i");
        if (sender === "user") {
            avatarIcon.className = "fas fa-user";
        } else {
            avatarIcon.className = "fas fa-comment-dots";
        }
        avatarDiv.appendChild(avatarIcon);

        const contentDiv = document.createElement("div");
        contentDiv.className = "message-content";

        const bubbleDiv = document.createElement("div");
        bubbleDiv.className = "message-bubble";

        const textDiv = document.createElement("div");
        textDiv.className = "message-text";
        textDiv.textContent = text;

        bubbleDiv.appendChild(textDiv);

        // Add file preview for user messages
        if (sender === "user" && file) {
            const filePreview = this.createFilePreview(file);
            bubbleDiv.appendChild(filePreview);
        }

        // Add message actions for assistant messages
        if (sender === "assistant") {
            const actionsDiv = document.createElement("div");
            actionsDiv.className = "message-actions";

            const copyBtn = document.createElement("button");
            copyBtn.className = "action-btn";
            copyBtn.innerHTML = '<i class="fas fa-copy"></i>';
            copyBtn.title = "Copy message";
            copyBtn.onclick = () => this.copyMessage(text);

            const regenerateBtn = document.createElement("button");
            regenerateBtn.className = "action-btn";
            regenerateBtn.innerHTML = '<i class="fas fa-redo"></i>';
            regenerateBtn.title = "Regenerate response";
            regenerateBtn.onclick = () => this.regenerateResponse();

            actionsDiv.appendChild(copyBtn);
            actionsDiv.appendChild(regenerateBtn);
            bubbleDiv.appendChild(actionsDiv);
        }

        // Add timestamp
        if (timestamp || sender === "user") {
            const timeDiv = document.createElement("div");
            timeDiv.className = "message-time";
            timeDiv.textContent = timestamp || this.getCurrentTime();
            contentDiv.appendChild(timeDiv);
        }

        contentDiv.appendChild(bubbleDiv);

        // Append elements in the correct order based on sender
        if (sender === "user") {
            messageDiv.appendChild(contentDiv);
            messageDiv.appendChild(avatarDiv);
        } else {
            messageDiv.appendChild(avatarDiv);
            messageDiv.appendChild(contentDiv);
        }

        this.chatMessages.appendChild(messageDiv);
        this.scrollToBottom();

        // Store in history
        this.messageHistory.push({ text, sender, file: file ? file.name : null, timestamp: timestamp || this.getCurrentTime() });

        // Auto-save chat history after each message (only if not loading from history)
        if (!this.isLoadingChat) {
            this.autoSaveChat();
        }
    }

    createFilePreview(file) {
        const previewDiv = document.createElement("div");
        previewDiv.className = "file-preview";

        const previewHeader = document.createElement("div");
        previewHeader.className = "file-preview-header";

        const fileIcon = document.createElement("div");
        fileIcon.className = "file-icon-small";
        fileIcon.innerHTML = '<i class="fas fa-file"></i>';

        const fileName = document.createElement("div");
        fileName.className = "file-name";
        fileName.textContent = file.name;

        const fileSize = document.createElement("div");
        fileSize.className = "file-size";
        fileSize.textContent = this.formatFileSize(file.size);

        previewHeader.appendChild(fileIcon);
        previewHeader.appendChild(fileName);
        previewHeader.appendChild(fileSize);

        previewDiv.appendChild(previewHeader);

        // Add image preview if it's an image
        if (file.type.startsWith("image/")) {
            const img = document.createElement("img");
            img.src = URL.createObjectURL(file);
            img.className = "file-image-preview";
            img.onload = () => URL.revokeObjectURL(img.src);
            previewDiv.appendChild(img);
        }

        return previewDiv;
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // Add message without triggering auto-save (used when loading from history)
    addMessageWithoutSave(text, sender, timestamp = null) {
        const messageDiv = document.createElement("div");
        messageDiv.className = `message ${sender}`;

        const avatarDiv = document.createElement("div");
        avatarDiv.className = "message-avatar";

        const avatarIcon = document.createElement("i");
        if (sender === "user") {
            avatarIcon.className = "fas fa-user";
        } else {
            avatarIcon.className = "fas fa-comment-dots";
        }
        avatarDiv.appendChild(avatarIcon);

        const contentDiv = document.createElement("div");
        contentDiv.className = "message-content";

        const bubbleDiv = document.createElement("div");
        bubbleDiv.className = "message-bubble";

        const textDiv = document.createElement("div");
        textDiv.className = "message-text";
        textDiv.textContent = text;

        bubbleDiv.appendChild(textDiv);

        // Add message actions for assistant messages
        if (sender === "assistant") {
            const actionsDiv = document.createElement("div");
            actionsDiv.className = "message-actions";

            const copyBtn = document.createElement("button");
            copyBtn.className = "action-btn";
            copyBtn.innerHTML = '<i class="fas fa-copy"></i>';
            copyBtn.title = "Copy message";
            copyBtn.onclick = () => this.copyMessage(text);

            const regenerateBtn = document.createElement("button");
            regenerateBtn.className = "action-btn";
            regenerateBtn.innerHTML = '<i class="fas fa-redo"></i>';
            regenerateBtn.title = "Regenerate response";
            regenerateBtn.onclick = () => this.regenerateResponse();

            actionsDiv.appendChild(copyBtn);
            actionsDiv.appendChild(regenerateBtn);
            bubbleDiv.appendChild(actionsDiv);
        }

        // Add timestamp
        if (timestamp || sender === "user") {
            const timeDiv = document.createElement("div");
            timeDiv.className = "message-time";
            timeDiv.textContent = timestamp || this.getCurrentTime();
            contentDiv.appendChild(timeDiv);
        }

        contentDiv.appendChild(bubbleDiv);

        // Append elements in the correct order based on sender
        if (sender === "user") {
            messageDiv.appendChild(contentDiv);
            messageDiv.appendChild(avatarDiv);
        } else {
            messageDiv.appendChild(avatarDiv);
            messageDiv.appendChild(contentDiv);
        }

        this.chatMessages.appendChild(messageDiv);
        this.scrollToBottom();

        // Store in history but don't auto-save
        this.messageHistory.push({ text, sender, timestamp: timestamp || this.getCurrentTime() });
    }

    getCurrentTime() {
        return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    async connectWebSocket(message) {
        this.receivingMessage = true;
        this.showTypingIndicator();

        try {
            const url = "wss://backend.buildpicoapps.com/api/chatbot/chat";
            const websocket = new WebSocket(url);

            // Create assistant message element immediately
            const assistantMessageDiv = document.createElement("div");
            assistantMessageDiv.className = "message assistant";

            const avatarDiv = document.createElement("div");
            avatarDiv.className = "message-avatar";
            avatarDiv.innerHTML = '<i class="fas fa-comment-dots"></i>';

            const contentDiv = document.createElement("div");
            contentDiv.className = "message-content";

            const bubbleDiv = document.createElement("div");
            bubbleDiv.className = "message-bubble";

            const textDiv = document.createElement("div");
            textDiv.className = "message-text";
            textDiv.textContent = "";

            const timeDiv = document.createElement("div");
            timeDiv.className = "message-time";
            timeDiv.textContent = this.getCurrentTime();

            // Add message actions
            const actionsDiv = document.createElement("div");
            actionsDiv.className = "message-actions";

            const copyBtn = document.createElement("button");
            copyBtn.className = "action-btn";
            copyBtn.innerHTML = '<i class="fas fa-copy"></i>';
            copyBtn.title = "Copy message";

            const regenerateBtn = document.createElement("button");
            regenerateBtn.className = "action-btn";
            regenerateBtn.innerHTML = '<i class="fas fa-redo"></i>';
            regenerateBtn.title = "Regenerate response";

            actionsDiv.appendChild(copyBtn);
            actionsDiv.appendChild(regenerateBtn);

            bubbleDiv.appendChild(textDiv);
            bubbleDiv.appendChild(actionsDiv);
            contentDiv.appendChild(timeDiv);
            contentDiv.appendChild(bubbleDiv);

            // Append elements in the correct order for assistant messages
            assistantMessageDiv.appendChild(avatarDiv);
            assistantMessageDiv.appendChild(contentDiv);

            this.chatMessages.appendChild(assistantMessageDiv);
            this.scrollToBottom();

            websocket.onopen = () => {
                websocket.send(JSON.stringify({
                    chatId: this.chatId,
                    appId: "public-kitchen",
                    systemPrompt: this.systemPrompt,
                    message: message,
                }));
            };

            let responseText = "";

            websocket.onmessage = (event) => {
                responseText += event.data;
                textDiv.textContent = responseText;
                this.scrollToBottom();
            };

            websocket.onclose = (event) => {
                this.hideTypingIndicator();
                this.receivingMessage = false;

                if (event.code !== 1000) {
                    this.addErrorMessage("Error getting response from server. Please try again.");
                    // Remove the incomplete assistant message
                    this.chatMessages.removeChild(assistantMessageDiv);
                } else {
                    // Update the copy button functionality with final text
                    copyBtn.onclick = () => this.copyMessage(responseText);

                    // Store in history
                    this.messageHistory.push({
                        text: responseText,
                        sender: "assistant",
                        timestamp: this.getCurrentTime()
                    });
                }
            };

            websocket.onerror = (error) => {
                console.error("WebSocket error:", error);
                this.hideTypingIndicator();
                this.receivingMessage = false;
                this.addErrorMessage("Connection error. Please check your internet connection and try again.");
                // Remove the incomplete assistant message
                if (assistantMessageDiv.parentNode) {
                    this.chatMessages.removeChild(assistantMessageDiv);
                }
            };

        } catch (error) {
            console.error("Failed to connect:", error);
            this.hideTypingIndicator();
            this.receivingMessage = false;
            this.addErrorMessage("Failed to connect to chat service. Please try again.");
        }
    }

    showTypingIndicator() {
        this.typingIndicator.style.display = "block";
        this.scrollToBottom();
    }

    hideTypingIndicator() {
        this.typingIndicator.style.display = "none";
    }



    addErrorMessage(errorText) {
        const errorDiv = document.createElement("div");
        errorDiv.className = "message assistant";

        const avatarDiv = document.createElement("div");
        avatarDiv.className = "message-avatar";
        avatarDiv.innerHTML = '<i class="fas fa-exclamation-triangle"></i>';

        const contentDiv = document.createElement("div");
        contentDiv.className = "message-content";

        const bubbleDiv = document.createElement("div");
        bubbleDiv.className = "message-bubble";
        bubbleDiv.style.backgroundColor = "#7f1d1d";
        bubbleDiv.style.borderColor = "#dc2626";

        const textDiv = document.createElement("div");
        textDiv.className = "message-text";
        textDiv.textContent = errorText;
        textDiv.style.color = "#fca5a5";

        bubbleDiv.appendChild(textDiv);
        contentDiv.appendChild(bubbleDiv);

        // Append elements in the correct order for assistant messages
        errorDiv.appendChild(avatarDiv);
        errorDiv.appendChild(contentDiv);

        this.chatMessages.appendChild(errorDiv);
        this.scrollToBottom();
    }

    addErrorMessageWithRetry(errorText, retryCallback) {
        const errorDiv = document.createElement("div");
        errorDiv.className = "message assistant";

        const avatarDiv = document.createElement("div");
        avatarDiv.className = "message-avatar";
        avatarDiv.innerHTML = '<i class="fas fa-exclamation-triangle"></i>';

        const contentDiv = document.createElement("div");
        contentDiv.className = "message-content";

        const bubbleDiv = document.createElement("div");
        bubbleDiv.className = "message-bubble";
        bubbleDiv.style.backgroundColor = "#7f1d1d";
        bubbleDiv.style.borderColor = "#dc2626";

        const textDiv = document.createElement("div");
        textDiv.className = "message-text";
        textDiv.textContent = errorText;
        textDiv.style.color = "#fca5a5";

        // Add retry button
        const retryBtn = document.createElement("button");
        retryBtn.className = "retry-btn";
        retryBtn.innerHTML = '<i class="fas fa-redo"></i> Retry';
        retryBtn.onclick = () => {
            // Remove the error message
            this.chatMessages.removeChild(errorDiv);
            // Call the retry callback
            retryCallback();
        };

        bubbleDiv.appendChild(textDiv);
        bubbleDiv.appendChild(retryBtn);
        contentDiv.appendChild(bubbleDiv);

        // Append elements in the correct order for assistant messages
        errorDiv.appendChild(avatarDiv);
        errorDiv.appendChild(contentDiv);

        this.chatMessages.appendChild(errorDiv);
        this.scrollToBottom();
    }

    // Utility function for fetch with timeout
    async fetchWithTimeout(url, options = {}, timeout = 10000) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeout);

        try {
            const response = await fetch(url, {
                ...options,
                signal: controller.signal
            });
            clearTimeout(timeoutId);
            return response;
        } catch (error) {
            clearTimeout(timeoutId);
            if (error.name === 'AbortError') {
                throw new Error('Request timed out');
            }
            throw error;
        }
    }

    copyMessage(text) {
        navigator.clipboard.writeText(text).then(() => {
            this.showNotification("Message copied!", "success");
        }).catch(err => {
            console.error("Failed to copy message:", err);
            this.showNotification("Failed to copy message", "error");
        });
    }

    showNotification(message, type = "info") {
        const notification = document.createElement("div");
        notification.textContent = message;

        const colors = {
            success: "#10a37f",
            error: "#dc2626",
            warning: "#f59e0b",
            info: "#3b82f6"
        };

        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${colors[type] || colors.info};
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            font-size: 14px;
            z-index: 1000;
            animation: slideInRight 0.3s ease-out;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            max-width: 300px;
            word-wrap: break-word;
        `;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = "slideOutRight 0.3s ease-in";
            setTimeout(() => {
                if (notification.parentNode) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    regenerateResponse() {
        // Remove the last assistant message and resend the last user message
        const messages = this.chatMessages.querySelectorAll(".message");
        if (messages.length >= 2) {
            const lastMessage = messages[messages.length - 1];
            const secondLastMessage = messages[messages.length - 2];

            if (lastMessage.classList.contains("assistant") &&
                secondLastMessage.classList.contains("user")) {

                // Remove the assistant message
                this.chatMessages.removeChild(lastMessage);

                // Get the user message text
                const userMessageText = secondLastMessage.querySelector(".message-text").textContent;

                // Resend the message
                this.connectWebSocket(userMessageText);
            }
        }
    }

    scrollToBottom() {
        setTimeout(() => {
            this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
        }, 100);
    }

    // Sidebar functionality
    toggleSidebar() {
        this.sidebar.classList.toggle("open");
    }

    closeSidebarPanel() {
        this.sidebar.classList.remove("open");
    }

    // Close sidebar when clicking outside on mobile
    handleBackdropClick(event) {
        if (window.innerWidth <= 768 && this.sidebar.classList.contains("open")) {
            if (!this.sidebar.contains(event.target) && event.target !== this.sidebarToggle) {
                this.closeSidebarPanel();
            }
        }
    }

    loadChatHistory() {
        console.log("Loading chat history from localStorage...");
        console.log("Chat history length:", this.chatHistory.length);
        console.log("Chat history data:", JSON.stringify(this.chatHistory, null, 2));

        this.chatList.innerHTML = "";

        if (this.chatHistory.length === 0) {
            const emptyItem = document.createElement("div");
            emptyItem.className = "chat-item empty-state";
            emptyItem.innerHTML = `
                <div class="chat-item-icon">
                    <i class="fas fa-comment-slash"></i>
                </div>
                <div class="chat-item-text">No chats yet<br><small style="color: #9ca3af;">Start a conversation to see it here</small></div>
            `;
            this.chatList.appendChild(emptyItem);
            return;
        }

        // Sort chats by last updated (newest first)
        const sortedChats = [...this.chatHistory].sort((a, b) =>
            new Date(b.lastUpdated || b.timestamp) - new Date(a.lastUpdated || a.timestamp)
        );

        sortedChats.forEach((chat, index) => {
            const chatItem = document.createElement("div");
            chatItem.className = "chat-item";
            if (chat.id === this.currentChatId) {
                chatItem.classList.add("active");
            }

            // Format the timestamp for display
            const chatDate = new Date(chat.lastUpdated || chat.timestamp);
            const timeAgo = this.getTimeAgo(chatDate);

            chatItem.innerHTML = `
                <div class="chat-item-icon">
                    <i class="fas fa-comment"></i>
                </div>
                <div class="chat-item-content">
                    <div class="chat-item-text">${chat.title || `Chat ${index + 1}`}</div>
                    <div class="chat-item-meta">${timeAgo} • ${chat.messages.length} messages</div>
                </div>
            `;

            chatItem.addEventListener("click", (event) => {
                console.log("Chat item clicked:", chat.title, "ID:", chat.id);
                event.preventDefault();
                event.stopPropagation();
                this.loadChat(chat.id);
            });

            this.chatList.appendChild(chatItem);
        });
    }

    // Helper method to get relative time
    getTimeAgo(date) {
        const now = new Date();
        const diffInSeconds = Math.floor((now - date) / 1000);

        if (diffInSeconds < 60) return "now";
        if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
        if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
        if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)}d ago`;

        return date.toLocaleDateString();
    }

    saveChatHistory() {
        // Generate a meaningful chat title from the first user message
        const generateChatTitle = () => {
            const userMessages = this.messageHistory.filter(msg => msg.sender === "user");
            if (userMessages.length > 0) {
                const firstMessage = userMessages[0].text;
                // Take first 50 characters and clean it up for a title
                let title = firstMessage.substring(0, 50).trim();
                // Remove extra whitespace and newlines
                title = title.replace(/\s+/g, ' ');
                // Add ellipsis if truncated
                if (firstMessage.length > 50) {
                    title += "...";
                }
                return title || "New Chat";
            }
            return "New Chat";
        };

        const chatTitle = generateChatTitle();

        const chatData = {
            id: this.currentChatId,
            title: chatTitle,
            messages: this.messageHistory,
            timestamp: new Date().toISOString(),
            lastUpdated: new Date().toISOString()
        };

        // Check if chat already exists
        const existingIndex = this.chatHistory.findIndex(chat => chat.id === this.currentChatId);

        if (existingIndex >= 0) {
            this.chatHistory[existingIndex] = chatData;
        } else {
            this.chatHistory.unshift(chatData);
        }

        // Keep only last 50 chats to prevent localStorage bloat
        if (this.chatHistory.length > 50) {
            this.chatHistory = this.chatHistory.slice(0, 50);
        }

        localStorage.setItem("navaBharatAIChatHistory", JSON.stringify(this.chatHistory));
        this.loadChatHistory();
        console.log(`Chat saved: "${chatTitle}" with ${this.messageHistory.length} messages`);
        console.log("Chat data structure:", JSON.stringify(chatData, null, 2));
    }

    // Auto-save chat history (less frequent than manual save)
    autoSaveChat() {
        // Only auto-save if we have messages and it's been a while since last save
        if (this.messageHistory.length === 0) return;

        // Generate title for auto-save
        const generateChatTitle = () => {
            const userMessages = this.messageHistory.filter(msg => msg.sender === "user");
            if (userMessages.length > 0) {
                const firstMessage = userMessages[0].text;
                let title = firstMessage.substring(0, 50).trim();
                title = title.replace(/\s+/g, ' ');
                if (firstMessage.length > 50) {
                    title += "...";
                }
                return title || "New Chat";
            }
            return "New Chat";
        };

        const chatTitle = generateChatTitle();

        const chatData = {
            id: this.currentChatId,
            title: chatTitle,
            messages: this.messageHistory,
            timestamp: new Date().toISOString(),
            lastUpdated: new Date().toISOString()
        };

        // Update existing chat or add new one
        const existingIndex = this.chatHistory.findIndex(chat => chat.id === this.currentChatId);

        if (existingIndex >= 0) {
            this.chatHistory[existingIndex] = chatData;
        } else {
            this.chatHistory.unshift(chatData);
        }

        // Keep only last 50 chats
        if (this.chatHistory.length > 50) {
            this.chatHistory = this.chatHistory.slice(0, 50);
        }

        localStorage.setItem("navaBharatAIChatHistory", JSON.stringify(this.chatHistory));
    }

    // Initialize sidebar state
    initializeSidebar() {
        // Show sidebar by default on desktop if there are saved chats
        if (window.innerWidth > 768 && this.chatHistory.length > 0) {
            this.sidebar.classList.add("open");
        }

        // Handle window resize
        window.addEventListener("resize", () => {
            if (window.innerWidth <= 768) {
                this.sidebar.classList.remove("open");
            } else if (this.chatHistory.length > 0) {
                // Show sidebar on desktop if there are chats
                this.sidebar.classList.add("open");
            }
        });

        // Auto-save when page is about to unload
        window.addEventListener("beforeunload", () => {
            if (this.messageHistory.length > 0) {
                this.saveChatHistory();
            }
        });
    }

    loadChat(chatId) {
        const chat = this.chatHistory.find(c => c.id === chatId);
        if (!chat) {
            console.error("Chat not found:", chatId);
            return;
        }

        console.log("Loading chat:", chat.title, "with", chat.messages.length, "messages");

        this.currentChatId = chatId;
        this.messageHistory = [...chat.messages]; // Create a copy to avoid reference issues
        this.chatMessages.innerHTML = "";

        // Temporarily disable auto-save to prevent loops when loading messages
        this.isLoadingChat = true;

        // Recreate messages without triggering auto-save
        chat.messages.forEach((msg, index) => {
            console.log(`Adding message ${index + 1}:`, msg.text.substring(0, 50), "from", msg.sender);
            this.addMessageWithoutSave(msg.text, msg.sender, msg.timestamp);
        });

        // Re-enable auto-save
        this.isLoadingChat = false;

        this.hideWelcomeSection();
        this.loadChatHistory();
        this.closeSidebarPanel();

        // Ensure sidebar is visible on desktop after loading chat
        if (window.innerWidth > 768) {
            this.sidebar.classList.add("open");
        }

        console.log("Chat loaded successfully:", chat.title);
    }

    startNewChat() {
        // Save current chat if it has messages
        if (this.messageHistory.length > 0) {
            this.saveChatHistory();
        }

        // Create new chat ID
        this.currentChatId = crypto.randomUUID();
        this.messageHistory = [];
        this.chatMessages.innerHTML = "";
        this.showWelcomeSection();
        this.messageInput.value = "";

        // Refresh chat history display
        this.loadChatHistory();

        console.log("New chat started with ID:", this.currentChatId);
    }

    // Clear all chat history
    clearAllHistory() {
        if (confirm("Are you sure you want to delete all chat history? This cannot be undone.")) {
            this.chatHistory = [];
            localStorage.removeItem("navaBharatAIChatHistory");
            this.loadChatHistory();
            console.log("All chat history cleared");
        }
    }

    // File Upload Functionality
    initializeFileUpload() {
        // File button click - show/hide upload area
        this.fileBtn.addEventListener("click", () => this.toggleFileUpload());

        // Drag and drop functionality
        this.uploadZone.addEventListener("click", () => this.openFileDialog());
        this.uploadZone.addEventListener("dragover", (e) => this.handleDragOver(e));
        this.uploadZone.addEventListener("dragleave", (e) => this.handleDragLeave(e));
        this.uploadZone.addEventListener("drop", (e) => this.handleFileDrop(e));

        // Remove file button
        this.removeFile.addEventListener("click", () => this.removeSelectedFile());

        // File input change
        const fileInput = document.createElement("input");
        fileInput.type = "file";
        fileInput.multiple = true;
        fileInput.accept = "image/*,video/*,audio/*,.pdf,.doc,.docx,.txt,.zip";
        fileInput.style.display = "none";
        document.body.appendChild(fileInput);

        fileInput.addEventListener("change", (e) => this.handleFileSelection(e));

        this.fileInput = fileInput;
    }

    toggleFileUpload() {
        const isVisible = this.fileUploadArea.style.display === "block";
        this.fileUploadArea.style.display = isVisible ? "none" : "block";

        // Update button state
        this.fileBtn.classList.toggle("active", !isVisible);
    }

    openFileDialog() {
        this.fileInput.click();
    }

    handleDragOver(e) {
        e.preventDefault();
        e.stopPropagation();
        this.uploadZone.classList.add("dragover");
    }

    handleDragLeave(e) {
        e.preventDefault();
        e.stopPropagation();
        this.uploadZone.classList.remove("dragover");
    }

    handleFileDrop(e) {
        e.preventDefault();
        e.stopPropagation();
        this.uploadZone.classList.remove("dragover");

        const files = Array.from(e.dataTransfer.files);
        this.processFiles(files);
    }

    handleFileSelection(e) {
        const files = Array.from(e.target.files);
        this.processFiles(files);
    }

    processFiles(files) {
        files.forEach(file => {
            if (this.validateFile(file)) {
                this.selectedFile = file;
                this.showFilePreview(file);
                // Hide the upload area after file selection
                this.fileUploadArea.style.display = "none";
                this.fileBtn.classList.remove("active");

                // Show success message
                this.showNotification(`File "${file.name}" selected successfully!`, "success");
            }
        });
    }

    validateFile(file) {
        const maxSize = 10 * 1024 * 1024; // 10MB

        if (file.size > maxSize) {
            alert(`File "${file.name}" is too large. Maximum size is 10MB.`);
            return false;
        }

        // Allow all file formats
        return true;
    }

    showFilePreview(file) {
        this.previewFileName.textContent = file.name;
        this.previewContent.innerHTML = "";

        if (file.type.startsWith("image/")) {
            const img = document.createElement("img");
            img.src = URL.createObjectURL(file);
            img.onload = () => URL.revokeObjectURL(img.src);
            this.previewContent.appendChild(img);
        } else {
            const fileIcon = document.createElement("div");
            fileIcon.className = "file-icon";
            fileIcon.innerHTML = '<i class="fas fa-file"></i>';
            this.previewContent.appendChild(fileIcon);
        }

        this.filePreview.style.display = "block";
        this.uploadZone.style.display = "none";
    }

    removeSelectedFile() {
        this.selectedFile = null;
        this.filePreview.style.display = "none";
        this.uploadZone.style.display = "block";
        this.fileInput.value = "";
        this.fileBtn.classList.remove("active");
    }

    // Voice Recording Functionality
    initializeVoiceRecording() {
        this.voiceBtn.addEventListener("click", () => this.toggleVoiceRecording());

        // Create voice recording UI
        this.createVoiceRecordingUI();
    }

    createVoiceRecordingUI() {
        this.voiceRecording = document.createElement("div");
        this.voiceRecording.className = "voice-recording";
        this.voiceRecording.innerHTML = `
            <div class="recording-controls">
                <div class="recording-indicator"></div>
                <div class="recording-timer">00:00</div>
            </div>
            <div class="recording-actions">
                <button class="recording-btn stop" id="stopRecording">
                    <i class="fas fa-stop"></i>
                </button>
                <button class="recording-btn" id="cancelRecording">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;

        document.querySelector(".input-section .input-container").insertBefore(
            this.voiceRecording,
            document.querySelector(".input-wrapper")
        );

        // Add event listeners for recording controls
        this.voiceRecording.querySelector("#stopRecording").addEventListener("click", () => this.stopVoiceRecording());
        this.voiceRecording.querySelector("#cancelRecording").addEventListener("click", () => this.cancelVoiceRecording());
    }

    toggleVoiceRecording() {
        if (this.isRecording) {
            this.stopVoiceRecording();
        } else {
            this.startVoiceRecording();
        }
    }

    async startVoiceRecording() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            this.mediaRecorder = new MediaRecorder(stream);
            this.audioChunks = [];

            this.mediaRecorder.ondataavailable = (event) => {
                this.audioChunks.push(event.data);
            };

            this.mediaRecorder.onstop = () => {
                const audioBlob = new Blob(this.audioChunks, { type: 'audio/wav' });
                this.handleVoiceMessage(audioBlob);
                stream.getTracks().forEach(track => track.stop());
            };

            this.mediaRecorder.start();
            this.isRecording = true;
            this.showVoiceRecordingUI();
            this.startRecordingTimer();

        } catch (error) {
            console.error("Error starting voice recording:", error);
            alert("Could not access microphone. Please check permissions.");
        }
    }

    stopVoiceRecording() {
        if (this.mediaRecorder && this.isRecording) {
            this.mediaRecorder.stop();
            this.isRecording = false;
            this.hideVoiceRecordingUI();
            this.stopRecordingTimer();
        }
    }

    cancelVoiceRecording() {
        if (this.mediaRecorder && this.isRecording) {
            this.mediaRecorder.stop();
            this.isRecording = false;
            this.hideVoiceRecordingUI();
            this.stopRecordingTimer();
            this.audioChunks = [];
        }
    }

    showVoiceRecordingUI() {
        this.voiceRecording.style.display = "flex";
        this.voiceBtn.classList.add("active");
    }

    hideVoiceRecordingUI() {
        this.voiceRecording.style.display = "none";
        this.voiceBtn.classList.remove("active");
    }

    startRecordingTimer() {
        let seconds = 0;
        this.recordingTimer = setInterval(() => {
            seconds++;
            const minutes = Math.floor(seconds / 60);
            const remainingSeconds = seconds % 60;
            const timeString = `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
            this.voiceRecording.querySelector(".recording-timer").textContent = timeString;
        }, 1000);
    }

    stopRecordingTimer() {
        if (this.recordingTimer) {
            clearInterval(this.recordingTimer);
            this.recordingTimer = null;
        }
    }

    handleVoiceMessage(audioBlob) {
        // For now, just show a placeholder message
        // In a real implementation, you would send this to a speech-to-text service
        const audioUrl = URL.createObjectURL(audioBlob);
        const audioMessage = `[Voice Message: ${Math.round(audioBlob.size / 1024)}KB]`;

        this.addMessage(audioMessage, "user");

        // Create audio element for playback
        const audioElement = new Audio(audioUrl);
        audioElement.controls = true;
        audioElement.style.maxWidth = "200px";

        // Add audio to the last message
        const lastMessage = this.chatMessages.lastElementChild;
        if (lastMessage && lastMessage.classList.contains("user")) {
            const messageContent = lastMessage.querySelector(".message-content");
            messageContent.appendChild(audioElement);
        }

        this.messageInput.value = "";
        this.connectWebSocket(audioMessage);
    }

    // Emoji Picker Functionality
    initializeEmojiPicker() {
        this.emojiBtn.addEventListener("click", () => this.toggleEmojiPicker());

        // Create emoji picker
        this.createEmojiPicker();
    }

    createEmojiPicker() {
        this.emojiPicker = document.createElement("div");
        this.emojiPicker.className = "emoji-picker";

        const emojis = ["😀", "😂", "😊", "😍", "🥰", "😘", "😉", "😎", "🤔", "😮", "😢", "😭", "😤", "😡", "🥺", "😴", "🤐", "😷", "🤒", "🤕", "🥴", "😵", "🤯", "🥶", "😱", "😈", "👿", "💀", "☠️", "👍", "👎", "👌", "✌️", "🤞", "👊", "✊", "🤝", "🙏", "👏", "🤲", "🙌", "🤗", "🤔", "🤨", "😐", "😑", "😶", "🙄", "😏", "😣", "😥", "😮", "🤐", "😯", "😪", "😫", "🥱", "😴", "😌", "😛", "😜", "😝", "🤤", "😒", "😓", "😔", "😕", "🙃", "🤑", "😲", "☹️", "🙁", "😖", "😞", "😟", "😤", "😢", "😭", "😦", "😧", "😨", "😩", "🤯", "😬", "😰", "😱", "🥵", "🥶", "😳", "🤪", "😵", "😡", "😠", "🤬", "😷", "🤒", "🤕", "🤢", "🤮", "🤧", "😇", "🥳", "🥴", "🤥", "🤫", "🤭", "🧐", "🤓", "😈", "👿", "👹", "👺", "💩", "👻", "💀", "☠️", "👽", "👾", "🤖", "🎃", "😺", "😸", "😹", "😻", "😼", "😽", "🙀", "😿", "😾"];

        this.emojiPicker.innerHTML = '<div class="emoji-grid"></div>';
        const emojiGrid = this.emojiPicker.querySelector(".emoji-grid");

        emojis.forEach(emoji => {
            const emojiItem = document.createElement("button");
            emojiItem.className = "emoji-item";
            emojiItem.textContent = emoji;
            emojiItem.addEventListener("click", () => this.insertEmoji(emoji));
            emojiGrid.appendChild(emojiItem);
        });

        document.body.appendChild(this.emojiPicker);
    }

    toggleEmojiPicker() {
        const isVisible = this.emojiPicker.style.display === "block";
        this.emojiPicker.style.display = isVisible ? "none" : "block";

        if (!isVisible) {
            // Position the emoji picker above the input area
            const inputSection = document.querySelector(".input-section");
            const inputRect = inputSection.getBoundingClientRect();
            this.emojiPicker.style.position = "fixed";
            this.emojiPicker.style.bottom = `${window.innerHeight - inputRect.top + 10}px`;
            this.emojiPicker.style.left = `${inputRect.left + 50}px`;
            this.emojiPicker.style.zIndex = "1000";
        }
    }

    insertEmoji(emoji) {
        const cursorPosition = this.messageInput.selectionStart;
        const textBefore = this.messageInput.value.substring(0, cursorPosition);
        const textAfter = this.messageInput.value.substring(cursorPosition);
        this.messageInput.value = textBefore + emoji + textAfter;
        this.messageInput.focus();
        this.messageInput.setSelectionRange(cursorPosition + emoji.length, cursorPosition + emoji.length);
        this.emojiPicker.style.display = "none";
    }

    // Close emoji picker when clicking outside
    handleDocumentClick(event) {
        if (this.emojiPicker && !this.emojiPicker.contains(event.target) && !this.emojiBtn.contains(event.target)) {
            this.emojiPicker.style.display = "none";
        }
        if (this.fileUploadArea && !this.fileUploadArea.contains(event.target) && !this.fileBtn.contains(event.target)) {
            this.fileUploadArea.style.display = "none";
            this.fileBtn.classList.remove("active");
        }
        if (this.toolsPopup && !this.toolsPopup.contains(event.target) && !this.browseBtn.contains(event.target)) {
            this.hideToolsPopup();
        }
        if (this.browseContentArea && !this.browseContentArea.contains(event.target) && !this.browseBtn.contains(event.target)) {
            this.hideBrowseContent();
        }
        if (this.imageGenArea && !this.imageGenArea.contains(event.target) && !this.toolImage.contains(event.target)) {
            this.imageGenArea.style.display = "none";
        }
        if (this.codeExecArea && !this.codeExecArea.contains(event.target) && !this.toolCode.contains(event.target)) {
            this.codeExecArea.style.display = "none";
        }
        if (this.translateArea && !this.translateArea.contains(event.target) && !this.toolTranslate.contains(event.target)) {
            this.translateArea.style.display = "none";
        }
        if (this.calcArea && !this.calcArea.contains(event.target) && !this.toolCalc.contains(event.target)) {
            this.calcArea.style.display = "none";
        }
        if (this.weatherArea && !this.weatherArea.contains(event.target) && !this.toolWeather.contains(event.target)) {
            this.weatherArea.style.display = "none";
        }
        if (this.newsArea && !this.newsArea.contains(event.target) && !this.toolNews.contains(event.target)) {
            this.newsArea.style.display = "none";
        }
        if (this.videoToolsArea && !this.videoToolsArea.contains(event.target) && !this.toolVideo.contains(event.target)) {
            this.videoToolsArea.style.display = "none";
        }
        if (this.graphArea && !this.graphArea.contains(event.target) && !this.toolGraph.contains(event.target)) {
            this.graphArea.style.display = "none";
        }
    }

    // Theme Toggle Functionality
    initializeThemeToggle() {
        this.themeToggle.addEventListener("click", () => this.toggleTheme());
        this.applyTheme(this.currentTheme);
    }

    toggleTheme() {
        this.currentTheme = this.currentTheme === 'dark' ? 'light' : 'dark';
        this.applyTheme(this.currentTheme);
        localStorage.setItem('theme', this.currentTheme);
    }

    applyTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        const themeIcon = this.themeToggle.querySelector('i');

        if (theme === 'light') {
            themeIcon.className = 'fas fa-sun';
            this.themeToggle.title = 'Switch to dark mode';
        } else {
            themeIcon.className = 'fas fa-moon';
            this.themeToggle.title = 'Switch to light mode';
        }
    }

    // Message Counter
    updateMessageCount() {
        if (this.messageCount) {
            const totalMessages = this.messageHistory.length;
            this.messageCount.textContent = totalMessages;
        }
    }

    // Browse Content Functionality
    initializeBrowseContent() {
        // Remove click listener on browseBtn, use keyboard shortcut instead
        this.submitBrowseQuery.addEventListener("click", () => this.submitBrowseQueryHandler());
        this.browseQueryInput.addEventListener("keydown", (event) => {
            if (event.key === "Enter") {
                this.submitBrowseQueryHandler();
            }
        });
        this.closeBrowseResults.addEventListener("click", () => this.closeBrowseResultsHandler());

        // Add keyboard shortcut for tools popup
        document.addEventListener("keydown", (event) => {
            if (event.shiftKey && event.key === "*") {
                event.preventDefault();
                this.toggleToolsPopup();
            } else if (event.key === " " && (this.toolsPopup.style.display === "block" || this.browseContentArea.style.display === "block")) {
                event.preventDefault();
                this.hideAllTools();
            }
        });
    }

    toggleBrowseContent() {
        const isVisible = this.browseContentArea.style.display === "block";
        this.browseContentArea.style.display = isVisible ? "none" : "block";
        this.browseBtn.classList.toggle("active", !isVisible);

        if (!isVisible) {
            this.browseQueryInput.focus();
        } else {
            this.closeBrowseResultsHandler();
        }
    }

    hideBrowseContent() {
        this.browseContentArea.style.display = "none";
        this.browseBtn.classList.remove("active");
        this.closeBrowseResultsHandler();
    }

    // Tools Popup Functionality
    initializeToolsPopup() {
        this.closeTools.addEventListener("click", () => this.hideToolsPopup());

        // Tool button event listeners
        this.toolFile.addEventListener("click", () => this.activateTool("file"));
        this.toolVoice.addEventListener("click", () => this.activateTool("voice"));
        this.toolBrowse.addEventListener("click", () => this.activateTool("browse"));
        this.toolEmoji.addEventListener("click", () => this.activateTool("emoji"));
        this.toolImage.addEventListener("click", () => this.activateTool("image"));
        this.toolCode.addEventListener("click", () => this.activateTool("code"));
        this.toolTranslate.addEventListener("click", () => this.activateTool("translate"));
        this.toolCalc.addEventListener("click", () => this.activateTool("calc"));
        this.toolWeather.addEventListener("click", () => this.activateTool("weather"));
        this.toolNews.addEventListener("click", () => this.activateTool("news"));
        this.toolGraph.addEventListener("click", () => this.activateTool("graph"));

        // New AI capability tool event listeners
        this.toolMultilingual.addEventListener("click", () => this.activateTool("multilingual"));
        this.toolAISearch.addEventListener("click", () => this.activateTool("aisearch"));
        this.toolCitedAnswers.addEventListener("click", () => this.activateTool("citedanswers"));
        this.toolRealtime.addEventListener("click", () => this.activateTool("realtime"));
        this.toolFocusModes.addEventListener("click", () => this.activateTool("focusmodes"));
        this.toolDiscover.addEventListener("click", () => this.activateTool("discover"));
        this.toolCopilot.addEventListener("click", () => this.activateTool("copilot"));
        this.toolAIModes.addEventListener("click", () => this.activateTool("aimodes"));
        this.toolUnlimitedUpload.addEventListener("click", () => this.activateTool("unlimitedupload"));
        this.toolVideo.addEventListener("click", () => this.activateTool("video"));
        this.toolPersonality.addEventListener("click", () => this.activateTool("personality"));
        this.toolFunMode.addEventListener("click", () => this.activateTool("funmode"));
        this.toolRegularMode.addEventListener("click", () => this.activateTool("regularmode"));
        this.toolReasoning.addEventListener("click", () => this.activateTool("reasoning"));
        this.toolMultimodal.addEventListener("click", () => this.activateTool("multimodal"));
        this.toolImageUnderstanding.addEventListener("click", () => this.activateTool("imageunderstanding"));
        this.toolVoiceInteraction.addEventListener("click", () => this.activateTool("voiceinteraction"));
        this.toolGoogleWorkspace.addEventListener("click", () => this.activateTool("googleworkspace"));
        this.toolAdvancedTools.addEventListener("click", () => this.activateTool("advancedtools"));
    }

    toggleToolsPopup() {
        const isVisible = this.toolsPopup.style.display === "block";
        if (isVisible) {
            this.hideToolsPopup();
        } else {
            this.showToolsPopup();
        }
    }

    showToolsPopup() {
        this.toolsPopup.style.display = "block";
        this.hideAllOtherTools();
    }

    hideToolsPopup() {
        this.toolsPopup.style.display = "none";
    }

    hideAllTools() {
        this.hideToolsPopup();
        this.hideBrowseContent();
        // Hide other tool areas as needed
        if (this.fileUploadArea) this.fileUploadArea.style.display = "none";
        if (this.voiceRecording) this.voiceRecording.style.display = "none";
        if (this.emojiPicker) this.emojiPicker.style.display = "none";
        if (this.imageGenArea) this.imageGenArea.style.display = "none";
        if (this.codeExecArea) this.codeExecArea.style.display = "none";
        if (this.translateArea) this.translateArea.style.display = "none";
        if (this.calcArea) this.calcArea.style.display = "none";
        if (this.weatherArea) this.weatherArea.style.display = "none";
        if (this.newsArea) this.newsArea.style.display = "none";
    }

    hideAllOtherTools() {
        this.browseContentArea.style.display = "none";
        if (this.fileUploadArea) this.fileUploadArea.style.display = "none";
        if (this.voiceRecording) this.voiceRecording.style.display = "none";
        if (this.emojiPicker) this.emojiPicker.style.display = "none";
        if (this.imageGenArea) this.imageGenArea.style.display = "none";
        if (this.codeExecArea) this.codeExecArea.style.display = "none";
        if (this.translateArea) this.translateArea.style.display = "none";
        if (this.calcArea) this.calcArea.style.display = "none";
        if (this.weatherArea) this.weatherArea.style.display = "none";
        if (this.newsArea) this.newsArea.style.display = "none";
        if (this.graphArea) this.graphArea.style.display = "none";
    }

    activateTool(toolType) {
        this.hideToolsPopup();

        switch (toolType) {
            case "file":
                this.toggleFileUpload();
                break;
            case "voice":
                this.toggleVoiceRecording();
                break;
            case "browse":
                this.toggleBrowseContent();
                break;
            case "emoji":
                this.toggleEmojiPicker();
                break;
            case "image":
                this.showImageGeneration();
                break;
            case "code":
                this.showCodeExecution();
                break;
            case "translate":
                this.showTranslation();
                break;
            case "calc":
                this.showCalculator();
                break;
            case "weather":
                this.showWeather();
                break;
            case "news":
                this.showNews();
                break;
            case "video":
                this.showVideoTools();
                break;
            case "graph":
                this.showGraphAPI();
                break;
        }
    }

    async submitBrowseQueryHandler() {
        const query = this.browseQueryInput.value.trim();
        if (!query) {
            this.showNotification("Please enter a search query.", "warning");
            return;
        }

        // Add user message
        this.addMessage(`Browse: ${query}`, "user");

        // Show typing indicator
        this.showTypingIndicator();

        let retryCount = 0;
        const maxRetries = 3;

        const attemptBrowse = async () => {
            try {
                const response = await fetch(`/api/browse?query=${encodeURIComponent(query)}`, {
                    timeout: 10000 // 10 second timeout
                });

                if (!response.ok) {
                    if (response.status === 429) {
                        throw new Error('Rate limit exceeded. Please wait and try again.');
                    }
                    throw new Error(`Browse search failed: ${response.status}`);
                }

                const data = await response.json();
                const results = data.results;

                // Hide typing indicator
                this.hideTypingIndicator();

                // Display results
                this.displayBrowseResults(results, query);

            } catch (error) {
                console.error("Browse search error:", error);
                this.hideTypingIndicator();

                if (retryCount < maxRetries && !error.message.includes('Rate limit')) {
                    retryCount++;
                    this.showNotification(`Retrying browse search (${retryCount}/${maxRetries})...`, "info");
                    setTimeout(attemptBrowse, 2000 * retryCount); // Exponential backoff
                } else {
                    this.addErrorMessageWithRetry(`Failed to browse content: ${error.message}`, () => this.submitBrowseQueryHandler());
                }
            }
        };

        await attemptBrowse();

        // Clear input
        this.browseQueryInput.value = "";
        this.browseContentArea.style.display = "none";
        this.browseBtn.classList.remove("active");
    }

    displayBrowseResults(results, query) {
        // Create assistant message with results
        let messageText = `Here are the search results for "${query}":\n\n`;

        results.forEach((result, index) => {
            messageText += `${index + 1}. **${result.title}**\n`;
            if (result.url !== "#") {
                messageText += `   [${result.url}](${result.url})\n`;
            }
            messageText += `   ${result.snippet}\n\n`;
        });

        this.addMessage(messageText, "assistant");

        // Store in history
        this.messageHistory.push({
            text: messageText,
            sender: "assistant",
            timestamp: this.getCurrentTime()
        });
    }

    closeBrowseResultsHandler() {
        this.browseResults.style.display = "none";
        this.resultsList.innerHTML = "";
    }

    // Image Generation Tool Functionality
    initializeImageGeneration() {
        this.closeImageGen.addEventListener("click", () => this.hideImageGeneration());
        this.generateImageBtn.addEventListener("click", () => this.generateImage());
        this.downloadImage.addEventListener("click", () => this.downloadGeneratedImage());
        this.regenerateImage.addEventListener("click", () => this.regenerateImage());

        this.imagePrompt.addEventListener("keydown", (event) => {
            if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault();
                this.generateImage();
            }
        });
    }

    showImageGeneration() {
        this.imageGenArea.style.display = "block";
        this.hideAllOtherTools();
        this.imagePrompt.focus();
    }

    hideImageGeneration() {
        this.imageGenArea.style.display = "none";
    }

    async generateImage() {
        const prompt = this.imagePrompt.value.trim();
        const style = this.imageStyle.value;

        if (!prompt) {
            this.showNotification("Please enter a description for the image.", "warning");
            return;
        }

        // Validate prompt length
        if (prompt.length < 3) {
            this.showNotification("Please enter a more detailed description (at least 3 characters).", "warning");
            return;
        }

        // Show loading state
        this.imagePreview.style.display = "block";
        this.imageLoading.style.display = "block";
        this.generatedImage.style.display = "none";
        this.generateImageBtn.disabled = true;
        this.generateImageBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';

        let retryCount = 0;
        const maxRetries = 2;

        const attemptGenerate = async () => {
            try {
                const response = await this.fetchWithTimeout('/api/generate-image', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        prompt: prompt,
                        style: style
                    })
                }, 30000); // 30 second timeout for image generation

                if (!response.ok) {
                    if (response.status === 429) {
                        throw new Error('Rate limit exceeded. Please wait and try again.');
                    } else if (response.status === 400) {
                        throw new Error('Invalid prompt. Please try a different description.');
                    }
                    throw new Error(`Image generation failed: ${response.status}`);
                }

                const data = await response.json();
                const imageUrl = data.image_url;

                // Preload image to check if it's valid
                const img = new Image();
                img.onload = () => {
                    this.generatedImage.src = imageUrl;
                    this.generatedImage.style.display = "block";
                    this.imageLoading.style.display = "none";
                    // Store the image URL for download
                    this.generatedImage.dataset.imageUrl = imageUrl;
                    this.showNotification("Image generated successfully!", "success");
                };
                img.onerror = () => {
                    throw new Error('Generated image could not be loaded');
                };
                img.src = imageUrl;

            } catch (error) {
                console.error("Image generation error:", error);
                this.imageLoading.style.display = "none";

                if (retryCount < maxRetries && !error.message.includes('Rate limit') && !error.message.includes('Invalid prompt')) {
                    retryCount++;
                    this.showNotification(`Retrying image generation (${retryCount}/${maxRetries})...`, "info");
                    setTimeout(attemptGenerate, 3000 * retryCount);
                } else {
                    this.showNotification(`Failed to generate image: ${error.message}`, "error");
                }
            } finally {
                this.generateImageBtn.disabled = false;
                this.generateImageBtn.innerHTML = '<i class="fas fa-magic"></i> Generate';
            }
        };

        await attemptGenerate();
    }

    downloadGeneratedImage() {
        const imageUrl = this.generatedImage.dataset.imageUrl;
        if (imageUrl) {
            const link = document.createElement('a');
            link.href = imageUrl;
            link.download = 'generated-image.jpg';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }

    regenerateImage() {
        this.generateImage();
    }

    // Code Execution Tool Functionality
    initializeCodeExecution() {
        this.closeCodeExec.addEventListener("click", () => this.hideCodeExecution());
        this.runCodeBtn.addEventListener("click", () => this.runCode());
        this.clearCodeBtn.addEventListener("click", () => this.clearCode());
        this.clearOutputBtn.addEventListener("click", () => this.clearOutput());
    }

    showCodeExecution() {
        this.codeExecArea.style.display = "block";
        this.hideAllOtherTools();
        this.codeInput.focus();
    }

    hideCodeExecution() {
        this.codeExecArea.style.display = "none";
    }

    async runCode() {
        const code = this.codeInput.value.trim();
        const language = this.codeLanguage.value;

        if (!code) {
            this.showNotification("Please enter some code to execute.", "warning");
            return;
        }

        // Basic syntax validation for Python
        if (language === 'python') {
            const lines = code.split('\n');
            let indentLevel = 0;
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i].trim();
                if (line.startsWith(' ') && !line.includes(':')) {
                    // Check for consistent indentation
                    const currentIndent = lines[i].length - lines[i].trimStart().length;
                    if (currentIndent % 4 !== 0) {
                        this.showNotification("Warning: Inconsistent indentation detected. Python uses 4 spaces for indentation.", "warning");
                    }
                }
            }
        }

        this.runCodeBtn.disabled = true;
        this.runCodeBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Running...';
        this.codeOutput.textContent = "Executing code...\n";

        let retryCount = 0;
        const maxRetries = 2;

        const attemptRun = async () => {
            try {
                const response = await this.fetchWithTimeout('/api/execute-code', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        code: code,
                        language: language
                    })
                }, 20000); // 20 second timeout for code execution

                if (!response.ok) {
                    if (response.status === 429) {
                        throw new Error('Rate limit exceeded. Please wait and try again.');
                    } else if (response.status === 400) {
                        throw new Error('Invalid code or unsupported language.');
                    }
                    throw new Error(`Code execution failed: ${response.status}`);
                }

                const result = await response.json();
                this.codeOutput.textContent = result.output || "Code executed successfully with no output.";

                if (result.output && result.output.includes('Error:')) {
                    this.showNotification("Code execution completed with errors. Check output for details.", "warning");
                } else {
                    this.showNotification("Code executed successfully!", "success");
                }

            } catch (error) {
                console.error("Code execution error:", error);

                if (retryCount < maxRetries && !error.message.includes('Rate limit') && !error.message.includes('Invalid code')) {
                    retryCount++;
                    this.codeOutput.textContent += `\nRetrying (${retryCount}/${maxRetries})...\n`;
                    setTimeout(attemptRun, 2000 * retryCount);
                } else {
                    this.codeOutput.textContent = `Error: ${error.message}`;
                    this.showNotification(`Code execution failed: ${error.message}`, "error");
                }
            } finally {
                this.runCodeBtn.disabled = false;
                this.runCodeBtn.innerHTML = '<i class="fas fa-play"></i> Run Code';
            }
        };

        await attemptRun();
    }

    clearCode() {
        this.codeInput.value = "";
        this.codeOutput.textContent = "";
    }

    clearOutput() {
        this.codeOutput.textContent = "";
    }

    // Translation Tool Functionality
    initializeTranslation() {
        this.closeTranslate.addEventListener("click", () => this.hideTranslation());
        this.translateBtn.addEventListener("click", () => this.translateText());
        this.swapLanguages.addEventListener("click", () => this.swapLanguagesFunc());
        this.copyTranslation.addEventListener("click", () => this.copyTranslationFunc());

        this.translateInput.addEventListener("input", () => {
            if (this.translateInput.value.trim()) {
                this.translateBtn.disabled = false;
            } else {
                this.translateBtn.disabled = true;
            }
        });
    }

    showTranslation() {
        this.translateArea.style.display = "block";
        this.hideAllOtherTools();
        this.translateInput.focus();
    }

    hideTranslation() {
        this.translateArea.style.display = "none";
    }

    swapLanguagesFunc() {
        const temp = this.sourceLanguage.value;
        this.sourceLanguage.value = this.targetLanguage.value;
        this.targetLanguage.value = temp;
    }

    async translateText() {
        const text = this.translateInput.value.trim();
        const sourceLang = this.sourceLanguage.value;
        const targetLang = this.targetLanguage.value;

        if (!text) {
            this.showNotification("Please enter text to translate.", "warning");
            return;
        }

        // Validate text length
        if (text.length > 5000) {
            this.showNotification("Text is too long. Please limit to 5000 characters.", "warning");
            return;
        }

        // Check if source and target languages are different
        if (sourceLang === targetLang && sourceLang !== 'auto') {
            this.showNotification("Source and target languages are the same.", "warning");
            return;
        }

        this.translateBtn.disabled = true;
        this.translateBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Translating...';
        this.translateOutput.textContent = "Translating...";

        let retryCount = 0;
        const maxRetries = 3;

        const attemptTranslate = async () => {
            try {
                const response = await this.fetchWithTimeout('/api/translate', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        text: text,
                        source_lang: sourceLang,
                        target_lang: targetLang
                    })
                }, 15000); // 15 second timeout for translation

                if (!response.ok) {
                    if (response.status === 429) {
                        throw new Error('Rate limit exceeded. Please wait and try again.');
                    } else if (response.status === 400) {
                        throw new Error('Invalid text or language selection.');
                    }
                    throw new Error(`Translation failed: ${response.status}`);
                }

                const data = await response.json();
                const translatedText = data.translated_text || "Translation failed. Please try again.";

                this.translateOutput.textContent = translatedText;
                this.showNotification("Translation completed successfully!", "success");

            } catch (error) {
                console.error("Translation error:", error);

                if (retryCount < maxRetries && !error.message.includes('Rate limit') && !error.message.includes('Invalid text')) {
                    retryCount++;
                    this.translateOutput.textContent = `Retrying translation (${retryCount}/${maxRetries})...`;
                    setTimeout(attemptTranslate, 2000 * retryCount);
                } else {
                    this.translateOutput.textContent = `Error: ${error.message}`;
                    this.showNotification(`Translation failed: ${error.message}`, "error");
                }
            } finally {
                this.translateBtn.disabled = false;
                this.translateBtn.innerHTML = '<i class="fas fa-language"></i> Translate';
            }
        };

        await attemptTranslate();
    }

    copyTranslationFunc() {
        const text = this.translateOutput.textContent;
        if (text && text !== "Translating..." && !text.startsWith("Error:")) {
            navigator.clipboard.writeText(text).then(() => {
                this.showNotification("Translation copied to clipboard!", "success");
            });
        }
    }

    // Calculator Tool Functionality
    initializeCalculator() {
        this.closeCalc.addEventListener("click", () => this.hideCalculator());

        this.calcButtons.forEach(button => {
            button.addEventListener("click", () => this.handleCalcButton(button.dataset.value));
        });

        this.calcInput.value = "0";
    }

    showCalculator() {
        this.calcArea.style.display = "block";
        this.hideAllOtherTools();
    }

    hideCalculator() {
        this.calcArea.style.display = "none";
    }

    handleCalcButton(value) {
        let currentValue = this.calcInput.value;

        switch (value) {
            case "C":
                this.calcInput.value = "0";
                break;
            case "CE":
                this.calcInput.value = "0";
                break;
            case "=":
                try {
                    const result = eval(currentValue.replace(/×/g, '*').replace(/÷/g, '/'));
                    this.calcInput.value = result;
                } catch (error) {
                    this.calcInput.value = "Error";
                }
                break;
            case "sin":
            case "cos":
            case "tan":
            case "log":
            case "ln":
            case "sqrt":
                try {
                    const num = parseFloat(currentValue);
                    let result;
                    switch (value) {
                        case "sin": result = Math.sin(num * Math.PI / 180); break;
                        case "cos": result = Math.cos(num * Math.PI / 180); break;
                        case "tan": result = Math.tan(num * Math.PI / 180); break;
                        case "log": result = Math.log10(num); break;
                        case "ln": result = Math.log(num); break;
                        case "sqrt": result = Math.sqrt(num); break;
                    }
                    this.calcInput.value = result;
                } catch (error) {
                    this.calcInput.value = "Error";
                }
                break;
            case "^":
                this.calcInput.value += "**";
                break;
            case "pi":
                this.calcInput.value += Math.PI;
                break;
            default:
                if (currentValue === "0" && !isNaN(value)) {
                    this.calcInput.value = value;
                } else {
                    this.calcInput.value += value;
                }
                break;
        }
    }

    // Weather Tool Functionality
    initializeWeather() {
        this.closeWeather.addEventListener("click", () => this.hideWeather());
        this.getWeatherBtn.addEventListener("click", () => this.getWeather());
        this.currentLocationBtn.addEventListener("click", () => this.getCurrentLocationWeather());

        this.weatherLocation.addEventListener("keydown", (event) => {
            if (event.key === "Enter") {
                this.getWeather();
            }
        });
    }

    showWeather() {
        this.weatherArea.style.display = "block";
        this.hideAllOtherTools();
        this.weatherLocation.focus();
    }

    hideWeather() {
        this.weatherArea.style.display = "none";
    }

    async getWeather() {
        const location = this.weatherLocation.value.trim();

        if (!location) {
            this.showNotification("Please enter a city name.", "warning");
            return;
        }

        await this.fetchWeather(location);
    }

    async getCurrentLocationWeather() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                async (position) => {
                    const { latitude, longitude } = position.coords;
                    await this.fetchWeatherByCoords(latitude, longitude);
                },
                (error) => {
                    console.error("Geolocation error:", error);
                    let errorMessage = "Unable to get your location. Please enter a city name.";
                    switch (error.code) {
                        case error.PERMISSION_DENIED:
                            errorMessage = "Location access denied. Please enable location permissions and try again.";
                            break;
                        case error.POSITION_UNAVAILABLE:
                            errorMessage = "Location information is unavailable. Please enter a city name.";
                            break;
                        case error.TIMEOUT:
                            errorMessage = "Location request timed out. Please try again.";
                            break;
                    }
                    this.showNotification(errorMessage, "error");
                },
                { timeout: 10000, enableHighAccuracy: false } // 10 second timeout, lower accuracy for faster response
            );
        } else {
            this.showNotification("Geolocation is not supported by this browser.", "error");
        }
    }

    async fetchWeather(location) {
        this.weatherDisplay.style.display = "block";
        this.weatherLoading.style.display = "block";
        this.weatherInfo.style.display = "none";

        let retryCount = 0;
        const maxRetries = 3;

        const attemptFetch = async () => {
            try {
                const response = await this.fetchWithTimeout(`/api/weather?city=${encodeURIComponent(location)}`, {}, 10000); // 10 second timeout

                if (!response.ok) {
                    if (response.status === 404) {
                        throw new Error('City not found. Please check the spelling and try again.');
                    } else if (response.status === 429) {
                        throw new Error('Rate limit exceeded. Please wait a moment and try again.');
                    } else if (response.status === 401) {
                        throw new Error('Weather service is not configured properly. Please contact support.');
                    } else {
                        throw new Error(`Weather service error: ${response.status}`);
                    }
                }

                const data = await response.json();
                this.displayWeather(data);

            } catch (error) {
                console.error("Weather fetch error:", error);

                if (retryCount < maxRetries && !error.message.includes('City not found') &&
                    !error.message.includes('Rate limit') && !error.message.includes('not configured')) {
                    retryCount++;
                    this.showNotification(`Retrying weather fetch (${retryCount}/${maxRetries})...`, "info");
                    setTimeout(attemptFetch, 2000 * retryCount); // Exponential backoff
                } else {
                    this.showNotification(`Failed to fetch weather data: ${error.message}`, "error");
                }
            } finally {
                this.weatherLoading.style.display = "none";
            }
        };

        await attemptFetch();
    }

    async fetchWeatherByCoords(lat, lon) {
        this.weatherDisplay.style.display = "block";
        this.weatherLoading.style.display = "block";
        this.weatherInfo.style.display = "none";

        let retryCount = 0;
        const maxRetries = 3;

        const attemptFetch = async () => {
            try {
                const response = await this.fetchWithTimeout(`/api/weather?lat=${lat}&lon=${lon}`, {}, 10000); // 10 second timeout

                if (!response.ok) {
                    if (response.status === 404) {
                        throw new Error('Location not found. Please try a different location.');
                    } else if (response.status === 429) {
                        throw new Error('Rate limit exceeded. Please wait a moment and try again.');
                    } else if (response.status === 401) {
                        throw new Error('Weather service is not configured properly. Please contact support.');
                    } else {
                        throw new Error(`Weather service error: ${response.status}`);
                    }
                }

                const data = await response.json();
                this.displayWeather(data);

            } catch (error) {
                console.error("Weather fetch error:", error);

                if (retryCount < maxRetries && !error.message.includes('Location not found') &&
                    !error.message.includes('Rate limit') && !error.message.includes('not configured')) {
                    retryCount++;
                    this.showNotification(`Retrying weather fetch (${retryCount}/${maxRetries})...`, "info");
                    setTimeout(attemptFetch, 2000 * retryCount); // Exponential backoff
                } else {
                    this.showNotification(`Failed to fetch weather data: ${error.message}`, "error");
                }
            } finally {
                this.weatherLoading.style.display = "none";
            }
        };

        await attemptFetch();
    }

    displayWeather(data) {
        const temp = Math.round(data.main.temp);
        const description = data.weather[0].description;
        const humidity = data.main.humidity;
        const windSpeed = data.wind.speed;
        const pressure = data.main.pressure;
        const visibility = data.visibility / 1000; // Convert to km

        this.weatherTemp.textContent = `${temp}°C`;
        this.weatherDesc.textContent = description.charAt(0).toUpperCase() + description.slice(1);
        this.weatherHumidity.textContent = `${humidity}%`;
        this.weatherWind.textContent = `${windSpeed} m/s`;
        this.weatherPressure.textContent = `${pressure} hPa`;
        this.weatherVisibility.textContent = `${visibility} km`;

        // Set weather icon (simplified)
        const iconCode = data.weather[0].icon;
        this.weatherIcon.innerHTML = `<img src="https://openweathermap.org/img/wn/${iconCode}@2x.png" alt="${description}" style="width: 64px; height: 64px;">`;

        this.weatherInfo.style.display = "block";
    }

    // News Tool Functionality
    initializeNews() {
        this.closeNews.addEventListener("click", () => this.hideNews());

        // News category buttons
        this.newsCategories.forEach(btn => {
            btn.addEventListener("click", () => {
                this.newsCategories.forEach(b => b.classList.remove("active"));
                btn.classList.add("active");
                this.loadNews(btn.dataset.category);
            });
        });

        // Load default news
        this.loadNews("general");
    }

    showNews() {
        this.newsArea.style.display = "block";
        this.hideAllOtherTools();
    }

    hideNews() {
        this.newsArea.style.display = "none";
    }

    async loadNews(category) {
        this.newsLoading.style.display = "block";
        this.newsFeed.innerHTML = "";

        try {
            // Use mock data for demo purposes
            const mockArticles = [
                {
                    title: "Breaking: Major Tech Company Announces New AI Features",
                    description: "A leading technology company has unveiled groundbreaking AI capabilities that promise to revolutionize the industry.",
                    source: { name: "Tech News Daily" },
                    publishedAt: new Date().toISOString(),
                    url: "#"
                },
                {
                    title: "Global Climate Summit Reaches Historic Agreement",
                    description: "World leaders have agreed on ambitious new targets to combat climate change and reduce carbon emissions.",
                    source: { name: "Global News" },
                    publishedAt: new Date().toISOString(),
                    url: "#"
                },
                {
                    title: "Space Mission Successfully Lands on Mars",
                    description: "NASA's latest rover has successfully touched down on the Martian surface, beginning its exploration mission.",
                    source: { name: "Space News" },
                    publishedAt: new Date().toISOString(),
                    url: "#"
                },
                {
                    title: "New Study Reveals Benefits of Mediterranean Diet",
                    description: "Research shows that following a Mediterranean diet can significantly improve heart health and longevity.",
                    source: { name: "Health Journal" },
                    publishedAt: new Date().toISOString(),
                    url: "#"
                },
                {
                    title: "Stock Market Hits Record Highs",
                    description: "Major indices have reached new all-time highs as investor confidence grows amid economic recovery.",
                    source: { name: "Financial Times" },
                    publishedAt: new Date().toISOString(),
                    url: "#"
                }
            ];

            if (mockArticles && mockArticles.length > 0) {
                mockArticles.forEach(article => {
                    const newsItem = document.createElement("div");
                    newsItem.className = "news-item";
                    newsItem.innerHTML = `
                        <div class="news-header">
                            <h4>${article.title}</h4>
                            <span class="news-source">${article.source.name}</span>
                        </div>
                        <p class="news-description">${article.description || "No description available."}</p>
                        <div class="news-meta">
                            <span class="news-date">${new Date(article.publishedAt).toLocaleDateString()}</span>
                            <a href="${article.url}" target="_blank" class="news-link">Read More</a>
                        </div>
                    `;
                    this.newsFeed.appendChild(newsItem);
                });
            } else {
                this.newsFeed.innerHTML = '<div class="no-news">No news articles found for this category.</div>';
            }
        } catch (error) {
            console.error("News loading error:", error);
            this.newsFeed.innerHTML = '<div class="error-message">Failed to load news. Please try again later.</div>';
        } finally {
            this.newsLoading.style.display = "none";
        }
    }

    // Video Tools Functionality
    initializeVideoTools() {
        this.closeVideoTools.addEventListener("click", () => this.hideVideoTools());

        // Video tool button event listeners
        document.getElementById("videoToAudio").addEventListener("click", () => this.handleVideoTool("videoToAudio"));
        document.getElementById("videoToText").addEventListener("click", () => this.handleVideoTool("videoToText"));
        document.getElementById("videoToImage").addEventListener("click", () => this.handleVideoTool("videoToImage"));
        document.getElementById("videoToGif").addEventListener("click", () => this.handleVideoTool("videoToGif"));
        document.getElementById("videoToSubtitles").addEventListener("click", () => this.handleVideoTool("videoToSubtitles"));
        document.getElementById("videoTo3D").addEventListener("click", () => this.handleVideoTool("videoTo3D"));
        document.getElementById("videoToScript").addEventListener("click", () => this.handleVideoTool("videoToScript"));
        document.getElementById("videoToVideo").addEventListener("click", () => this.handleVideoTool("videoToVideo"));
        document.getElementById("videoToAudioRemix").addEventListener("click", () => this.handleVideoTool("videoToAudioRemix"));
        document.getElementById("videoToCode").addEventListener("click", () => this.handleVideoTool("videoToCode"));
        document.getElementById("textToVideo").addEventListener("click", () => this.handleVideoTool("textToVideo"));
        document.getElementById("imageToVideo").addEventListener("click", () => this.handleVideoTool("imageToVideo"));
        document.getElementById("audioToVideo").addEventListener("click", () => this.handleVideoTool("audioToVideo"));
    }

    showVideoTools() {
        this.videoToolsArea.style.display = "block";
        this.hideAllOtherTools();
    }

    hideVideoTools() {
        this.videoToolsArea.style.display = "none";
    }

    async handleVideoTool(toolType) {
        const toolNames = {
            videoToAudio: "Video to Audio",
            videoToText: "Video to Text",
            videoToImage: "Video to Image",
            videoToGif: "Video to GIF",
            videoToSubtitles: "Video to Subtitles",
            videoTo3D: "Video to 3D / Animation",
            videoToScript: "Video to Script / Summary",
            videoToVideo: "Video to Video (Style / Quality)",
            videoToAudioRemix: "Video to Audio Remix",
            videoToCode: "Video to Code",
            textToVideo: "Text to Video",
            imageToVideo: "Image to Video",
            audioToVideo: "Audio to Video"
        };

        const toolName = toolNames[toolType] || toolType;
        this.addMessage(`Video tool selected: ${toolName}`, "user");

        // Call the appropriate API endpoint based on tool type
        try {
            const response = await this.callVideoToolAPI(toolType);
            if (response.success) {
                this.addMessage(`✅ ${response.message}`, "system");
                if (response.audio_url) this.addMessage(`Audio URL: ${response.audio_url}`, "system");
                if (response.transcript) this.addMessage(`Transcript: ${response.transcript}`, "system");
                if (response.image_url) this.addMessage(`Image URL: ${response.image_url}`, "system");
                if (response.gif_url) this.addMessage(`GIF URL: ${response.gif_url}`, "system");
                if (response.subtitles_url) this.addMessage(`Subtitles URL: ${response.subtitles_url}`, "system");
                if (response.model_url) this.addMessage(`3D Model URL: ${response.model_url}`, "system");
                if (response.script) this.addMessage(`Script: ${response.script}`, "system");
                if (response.summary) this.addMessage(`Summary: ${response.summary}`, "system");
                if (response.output_url) this.addMessage(`Output URL: ${response.output_url}`, "system");
                if (response.remix_url) this.addMessage(`Remix URL: ${response.remix_url}`, "system");
                if (response.code) this.addMessage(`Generated Code:\n${response.code}`, "system");
                if (response.video_url) this.addMessage(`Video URL: ${response.video_url}`, "system");
                if (response.estimated_time) this.addMessage(`Estimated time: ${response.estimated_time}`, "system");
            } else {
                this.addMessage(`❌ Error: ${response.error || 'Unknown error'}`, "system");
            }
        } catch (error) {
            this.addMessage(`❌ Error calling ${toolName}: ${error.message}`, "system");
        }

        this.hideVideoTools(); // Close popup after selection
        this.showNotification(`Selected: ${toolName}`, "success");
    }

    async callVideoToolAPI(toolType) {
        const endpoints = {
            videoToAudio: '/api/video-tools/video-to-audio',
            videoToText: '/api/video-tools/video-to-text',
            videoToImage: '/api/video-tools/video-to-image',
            videoToGif: '/api/video-tools/video-to-gif',
            videoToSubtitles: '/api/video-tools/video-to-subtitles',
            videoTo3D: '/api/video-tools/video-to-3d',
            videoToScript: '/api/video-tools/video-to-script',
            videoToVideo: '/api/video-tools/video-to-video',
            videoToAudioRemix: '/api/video-tools/video-to-audio-remix',
            videoToCode: '/api/video-tools/video-to-code',
            textToVideo: '/api/video-tools/text-to-video',
            imageToVideo: '/api/video-tools/image-to-video',
            audioToVideo: '/api/video-tools/audio-to-video'
        };

        const endpoint = endpoints[toolType];
        if (!endpoint) {
            throw new Error(`Unknown tool type: ${toolType}`);
        }

        // Get input data based on tool type
        const inputData = this.getToolInputData(toolType);

        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(inputData)
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        return await response.json();
    }

    getToolInputData(toolType) {
        // This would typically get data from user input forms
        // For now, return mock data based on tool type
        const mockData = {
            videoToAudio: { video_url: 'https://example.com/sample.mp4' },
            videoToText: { video_url: 'https://example.com/sample.mp4' },
            videoToImage: { video_url: 'https://example.com/sample.mp4', timestamp: 5 },
            videoToGif: { video_url: 'https://example.com/sample.mp4', start_time: 10, duration: 5 },
            videoToSubtitles: { video_url: 'https://example.com/sample.mp4', language: 'en' },
            videoTo3D: { video_url: 'https://example.com/sample.mp4' },
            videoToScript: { video_url: 'https://example.com/sample.mp4' },
            videoToVideo: { video_url: 'https://example.com/sample.mp4', style: 'enhance', quality: 'HD' },
            videoToAudioRemix: { video_url: 'https://example.com/sample.mp4', style: 'electronic' },
            videoToCode: { video_url: 'https://example.com/sample.mp4', language: 'python' },
            textToVideo: { text: 'Create a video about artificial intelligence', style: 'realistic', duration: 30 },
            imageToVideo: { image_url: 'https://example.com/image.jpg', duration: 10, motion: 'pan' },
            audioToVideo: { audio_url: 'https://example.com/audio.mp3', visual_style: 'waveform' }
        };

        return mockData[toolType] || {};
    }

    // Microsoft Graph API Tool Functionality
    initializeGraphAPI() {
        this.closeGraph.addEventListener("click", () => this.hideGraphAPI());
        this.connectGraphBtn.addEventListener("click", () => this.connectToGraph());

        // Service tab switching
        this.serviceTabs.forEach(tab => {
            tab.addEventListener("click", () => this.switchServiceTab(tab.dataset.service));
        });

        // Excel functionality
        this.loadExcelBtn.addEventListener("click", () => this.loadExcelData());
        this.updateCellBtn.addEventListener("click", () => this.updateExcelCell());
        this.addFormulaBtn.addEventListener("click", () => this.addExcelFormula());

        // Word functionality
        this.loadWordBtn.addEventListener("click", () => this.loadWordDocument());
        this.saveWordBtn.addEventListener("click", () => this.saveWordDocument());

        // OneDrive functionality
        this.listFilesBtn.addEventListener("click", () => this.listOneDriveFiles());
        this.uploadFileBtn.addEventListener("click", () => this.uploadFileInput.click());
        this.uploadFileInput.addEventListener("change", (e) => this.uploadToOneDrive(e));

        // Outlook functionality
        this.readEmailsBtn.addEventListener("click", () => this.readOutlookEmails());
        this.composeEmailBtn.addEventListener("click", () => this.showComposeEmail());
        this.sendEmailBtn.addEventListener("click", () => this.sendEmail());
    }

    showGraphAPI() {
        this.graphArea.style.display = "block";
        this.hideAllOtherTools();
    }

    hideGraphAPI() {
        this.graphArea.style.display = "none";
    }

    async connectToGraph() {
        this.connectGraphBtn.disabled = true;
        this.connectGraphBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Connecting...';

        try {
            // Mock connection for demo
            setTimeout(() => {
                this.authStatus.innerHTML = '<i class="fas fa-check-circle" style="color: #10a37f;"></i> Connected (Demo)';
                this.graphServices.style.display = "block";
                this.showNotification("Demo mode: Connected to mock Microsoft Graph API", "info");
                this.connectGraphBtn.disabled = false;
                this.connectGraphBtn.innerHTML = '<i class="fas fa-link"></i> Connect to Microsoft 365';
            }, 1000);
        } catch (error) {
            console.error("Graph API connection error:", error);
            this.authStatus.innerHTML = '<i class="fas fa-times-circle" style="color: #dc2626;"></i> Connection Failed';
            this.showNotification("Failed to connect to Microsoft Graph API", "error");
            this.connectGraphBtn.disabled = false;
            this.connectGraphBtn.innerHTML = '<i class="fas fa-link"></i> Connect to Microsoft 365';
        }
    }

    switchServiceTab(service) {
        // Update tab active state
        this.serviceTabs.forEach(tab => tab.classList.remove("active"));
        document.querySelector(`[data-service="${service}"]`).classList.add("active");

        // Update panel visibility
        this.servicePanels.forEach(panel => panel.classList.remove("active"));
        document.querySelector(`.service-panel[data-service="${service}"]`).classList.add("active");
    }

    async loadExcelData() {
        const filePath = this.excelFilePath.value.trim();
        if (!filePath) {
            this.showNotification("Please enter an Excel file path", "warning");
            return;
        }

        this.loadExcelBtn.disabled = true;
        this.loadExcelBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';

        try {
            // Mock Excel data for demo
            const mockData = {
                worksheets: [
                    {
                        name: 'Sheet1',
                        usedRange: {
                            address: 'Sheet1!A1:D10',
                            values: [
                                ['Name', 'Age', 'City', 'Salary'],
                                ['John Doe', 30, 'New York', 50000],
                                ['Jane Smith', 25, 'Los Angeles', 45000],
                                ['Bob Johnson', 35, 'Chicago', 55000],
                                ['Alice Brown', 28, 'Houston', 48000]
                            ]
                        }
                    }
                ]
            };

            if (mockData.worksheets && mockData.worksheets.length > 0) {
                const worksheet = mockData.worksheets[0];
                this.displayExcelData(worksheet);
                this.excelData.style.display = "block";
                this.showNotification("Excel data loaded successfully!", "success");
            } else {
                throw new Error("No worksheets found");
            }
        } catch (error) {
            console.error("Excel loading error:", error);
            this.showNotification("Failed to load Excel data", "error");
        } finally {
            this.loadExcelBtn.disabled = false;
            this.loadExcelBtn.innerHTML = '<i class="fas fa-download"></i> Load Excel';
        }
    }

    displayExcelData(worksheet) {
        // Populate worksheet selector
        this.worksheetSelect.innerHTML = `<option value="${worksheet.name}">${worksheet.name}</option>`;

        // Create table
        const table = this.excelTable;
        table.innerHTML = "";

        if (worksheet.usedRange && worksheet.usedRange.values) {
            worksheet.usedRange.values.forEach((row, rowIndex) => {
                const tr = document.createElement("tr");
                row.forEach((cell, colIndex) => {
                    const td = document.createElement("td");
                    td.textContent = cell || "";
                    td.contentEditable = true;
                    td.dataset.row = rowIndex;
                    td.dataset.col = colIndex;
                    tr.appendChild(td);
                });
                table.appendChild(tr);
            });
        }
    }

    async updateExcelCell() {
        const filePath = this.excelFilePath.value.trim();
        if (!filePath) {
            this.showNotification("Please load an Excel file first", "warning");
            return;
        }

        // For demo, just show success message
        this.showNotification("Cell update feature - coming soon in full implementation!", "info");
    }

    async addExcelFormula() {
        const filePath = this.excelFilePath.value.trim();
        if (!filePath) {
            this.showNotification("Please load an Excel file first", "warning");
            return;
        }

        // For demo, just show success message
        this.showNotification("Formula addition feature - coming soon in full implementation!", "info");
    }

    async loadWordDocument() {
        const filePath = this.wordFilePath.value.trim();
        if (!filePath) {
            this.showNotification("Please enter a Word file path", "warning");
            return;
        }

        this.loadWordBtn.disabled = true;
        this.loadWordBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';

        try {
            // Mock Word document content for demo
            const mockContent = {
                content: 'This is a sample Word document content.\n\nIt contains multiple paragraphs and formatting.\n\nMicrosoft Graph API allows reading and writing Word documents programmatically.',
                properties: {
                    title: 'Sample Document',
                    author: 'NavaBharat AI',
                    created: new Date().toISOString(),
                    modified: new Date().toISOString()
                }
            };

            this.wordEditor.value = mockContent.content || "Document content not available.";
            this.wordContent.style.display = "block";
            this.showNotification("Word document loaded successfully!", "success");
        } catch (error) {
            console.error("Word loading error:", error);
            this.showNotification("Failed to load Word document", "error");
        } finally {
            this.loadWordBtn.disabled = false;
            this.loadWordBtn.innerHTML = '<i class="fas fa-download"></i> Load Document';
        }
    }

    async saveWordDocument() {
        const filePath = this.wordFilePath.value.trim();
        const content = this.wordEditor.value;

        if (!filePath) {
            this.showNotification("Please load a document first", "warning");
            return;
        }

        this.saveWordBtn.disabled = true;
        this.saveWordBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';

        try {
            const response = await fetch(`/api/graph/word/${encodeURIComponent(filePath)}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ content })
            });

            if (response.ok) {
                this.showNotification("Document saved successfully!", "success");
            } else {
                throw new Error("Save failed");
            }
        } catch (error) {
            console.error("Word save error:", error);
            this.showNotification("Failed to save document", "error");
        } finally {
            this.saveWordBtn.disabled = false;
            this.saveWordBtn.innerHTML = '<i class="fas fa-save"></i> Save Changes';
        }
    }

    async listOneDriveFiles() {
        this.listFilesBtn.disabled = true;
        this.listFilesBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';

        try {
            // Mock OneDrive files for demo
            const mockFiles = [
                {
                    name: 'Document1.docx',
                    id: 'file1',
                    size: 24576,
                    lastModifiedDateTime: new Date().toISOString(),
                    webUrl: '#'
                },
                {
                    name: 'Spreadsheet.xlsx',
                    id: 'file2',
                    size: 51200,
                    lastModifiedDateTime: new Date().toISOString(),
                    webUrl: '#'
                },
                {
                    name: 'Presentation.pptx',
                    id: 'file3',
                    size: 102400,
                    lastModifiedDateTime: new Date().toISOString(),
                    webUrl: '#'
                }
            ];

            this.displayOneDriveFiles(mockFiles);
            this.onedriveFiles.style.display = "block";
            this.showNotification("OneDrive files loaded successfully!", "success");
        } catch (error) {
            console.error("OneDrive listing error:", error);
            this.showNotification("Failed to load OneDrive files", "error");
        } finally {
            this.listFilesBtn.disabled = false;
            this.listFilesBtn.innerHTML = '<i class="fas fa-list"></i> List Files';
        }
    }

    displayOneDriveFiles(files) {
        const filesList = this.filesList;
        filesList.innerHTML = "";

        if (files.length === 0) {
            filesList.innerHTML = '<div class="no-files">No files found in OneDrive.</div>';
            return;
        }

        files.forEach(file => {
            const fileItem = document.createElement("div");
            fileItem.className = "file-item";
            fileItem.innerHTML = `
                <div class="file-icon">
                    <i class="fas fa-file"></i>
                </div>
                <div class="file-info">
                    <div class="file-name">${file.name}</div>
                    <div class="file-meta">${(file.size / 1024).toFixed(1)} KB • ${new Date(file.lastModifiedDateTime).toLocaleDateString()}</div>
                </div>
                <div class="file-actions">
                    <button class="file-action-btn" onclick="window.open('${file.webUrl}', '_blank')">
                        <i class="fas fa-external-link-alt"></i>
                    </button>
                </div>
            `;
            filesList.appendChild(fileItem);
        });
    }

    async uploadToOneDrive(event) {
        const file = event.target.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await fetch('/api/graph/onedrive/upload', {
                method: 'POST',
                body: formData
            });

            if (response.ok) {
                const data = await response.json();
                this.showNotification(`File "${data.file_name}" uploaded successfully!`, "success");
                // Refresh file list
                this.listOneDriveFiles();
            } else {
                throw new Error("Upload failed");
            }
        } catch (error) {
            console.error("OneDrive upload error:", error);
            this.showNotification("Failed to upload file", "error");
        }

        // Clear file input
        this.uploadFileInput.value = "";
    }

    async readOutlookEmails() {
        this.readEmailsBtn.disabled = true;
        this.readEmailsBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';

        try {
            // Mock Outlook emails for demo
            const mockMessages = [
                {
                    id: 'msg1',
                    subject: 'Welcome to NavaBharat AI',
                    from: {'emailAddress': {'address': 'noreply@navabharat.ai'}},
                    receivedDateTime: new Date().toISOString(),
                    bodyPreview: 'Thank you for using NavaBharat AI. Here are some tips to get started...'
                },
                {
                    id: 'msg2',
                    subject: 'Your recent activity report',
                    from: {'emailAddress': {'address': 'reports@navabharat.ai'}},
                    receivedDateTime: new Date().toISOString(),
                    bodyPreview: 'Here is your weekly activity report for the chatbot usage...'
                }
            ];

            this.displayEmails(mockMessages);
            this.outlookContent.style.display = "block";
            this.showNotification("Emails loaded successfully!", "success");
        } catch (error) {
            console.error("Outlook emails error:", error);
            this.showNotification("Failed to load emails", "error");
        } finally {
            this.readEmailsBtn.disabled = false;
            this.readEmailsBtn.innerHTML = '<i class="fas fa-inbox"></i> Read Emails';
        }
    }

    displayEmails(emails) {
        const emailsList = this.emailsList;
        emailsList.innerHTML = "";

        if (emails.length === 0) {
            emailsList.innerHTML = '<div class="no-emails">No emails found.</div>';
            return;
        }

        emails.forEach(email => {
            const emailItem = document.createElement("div");
            emailItem.className = "email-item";
            emailItem.innerHTML = `
                <div class="email-header">
                    <div class="email-subject">${email.subject}</div>
                    <div class="email-from">${email.from.emailAddress.address}</div>
                </div>
                <div class="email-preview">${email.bodyPreview}</div>
                <div class="email-date">${new Date(email.receivedDateTime).toLocaleString()}</div>
            `;
            emailsList.appendChild(emailItem);
        });
    }

    showComposeEmail() {
        this.composeForm.style.display = "block";
        this.emailsList.style.display = "none";
    }

    async sendEmail() {
        const to = this.emailTo.value.trim();
        const subject = this.emailSubject.value.trim();
        const body = this.emailBody.value.trim();

        if (!to || !subject || !body) {
            this.showNotification("Please fill in all email fields", "warning");
            return;
        }

        this.sendEmailBtn.disabled = true;
        this.sendEmailBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';

        try {
            // Mock email sending for demo
            setTimeout(() => {
                this.showNotification("Email sent successfully!", "success");

                // Clear form and hide compose
                this.emailTo.value = "";
                this.emailSubject.value = "";
                this.emailBody.value = "";
                this.composeForm.style.display = "none";
                this.emailsList.style.display = "block";

                this.sendEmailBtn.disabled = false;
                this.sendEmailBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Send Email';
            }, 1000);
        } catch (error) {
            console.error("Email send error:", error);
            this.showNotification("Failed to send email", "error");
            this.sendEmailBtn.disabled = false;
            this.sendEmailBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Send Email';
        }
    }
}

// Initialize the chat interface when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
    const chatInterface = new ChatGPTInterface();
});

// Add CSS animation for notifications
const style = document.createElement("style");
style.textContent = `
    @keyframes fadeInOut {
        0%, 100% { opacity: 0; transform: translateY(-10px); }
        20%, 80% { opacity: 1; transform: translateY(0); }
    }
`;
document.head.appendChild(style);

// Additional API utility functions
async function fetchHello(name = 'World') {
  const response = await fetch(`http://localhost:5000/api/hello?name=${name}`);
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  const data = await response.json();
  return data.message;
}

async function createItem(item) {
  const response = await fetch('http://localhost:5000/api/items', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(item),
  });
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  const data = await response.json();
  return data;
}



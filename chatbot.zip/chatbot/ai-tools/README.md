# AI Tools Collection

This directory contains individual, standalone AI-powered applications. Each tool is a separate project with its own HTML, CSS, and JavaScript files.

## Available Tools

1. **Image Generator** - Generate images from text prompts
2. **Code Executor** - Run code in multiple programming languages
3. **Translator** - Translate text between different languages
4. **Calculator** - Advanced calculator with mathematical functions
5. **Weather App** - Get real-time weather information
6. **News Reader** - Fetch and display latest news by category
7. **Video Tools** - Multiple video processing and conversion tools
8. **Graph API** - Microsoft Office 365 integration tools
9. **File Uploader** - Handle file uploads with preview functionality
10. **Voice Recorder** - Audio recording and processing tool

## How to Use

Each tool is completely independent and can be run separately. Simply open the `index.html` file in any modern web browser.

## Project Structure

```
ai-tools/
├── image-generator/
│   ├── index.html
│   ├── styles.css
│   └── script.js
├── code-executor/
│   ├── index.html
│   ├── styles.css
│   └── script.js
├── translator/
│   ├── index.html
│   ├── styles.css
│   └── script.js
├── calculator/
│   ├── index.html
│   ├── styles.css
│   └── script.js
├── weather-app/
│   ├── index.html
│   ├── styles.css
│   └── script.js
├── news-reader/
│   ├── index.html
│   ├── styles.css
│   └── script.js
├── video-tools/
│   ├── index.html
│   ├── styles.css
│   └── script.js
├── graph-api/
│   ├── index.html
│   ├── styles.css
│   └── script.js
├── file-uploader/
│   ├── index.html
│   ├── styles.css
│   └── script.js
└── voice-recorder/
    ├── index.html
    ├── styles.css
    └── script.js
```

## Features

- **Standalone Applications**: Each tool works independently
- **Modern UI**: Clean, responsive design with dark/light themes
- **Cross-browser Compatible**: Works on all modern browsers
- **Mobile Responsive**: Optimized for mobile devices
- **API Integration**: Ready for backend API integration
- **Error Handling**: Comprehensive error handling and user feedback

## Development

Each tool follows a consistent structure:
- `index.html`: Main HTML structure
- `styles.css`: Styling and responsive design
- `script.js`: Functionality and API calls

## Contributing

To add a new tool:
1. Create a new directory under `ai-tools/`
2. Add the three core files (index.html, styles.css, script.js)
3. Update this README.md
4. Test the tool independently

## License

All tools are part of the NavaBharat AI project.

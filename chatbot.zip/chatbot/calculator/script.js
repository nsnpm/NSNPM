// AI Calculator JavaScript
class Calculator {
    constructor() {
        this.currentInput = '0';
        this.previousInput = '';
        this.operation = null;
        this.history = [];
        this.memory = 0;
        this.waitingForOperand = false;
        this.expression = '';

        this.initializeElements();
        this.bindEvents();
        this.addThemeToggle();
        this.loadHistory();
    }

    initializeElements() {
        this.expressionDisplay = document.getElementById('expressionDisplay');
        this.resultDisplay = document.getElementById('resultDisplay');
        this.historyDisplay = document.getElementById('historyDisplay');
        this.historyList = document.getElementById('historyList');
        this.convertValue = document.getElementById('convertValue');
        this.convertFrom = document.getElementById('convertFrom');
        this.convertTo = document.getElementById('convertTo');
        this.conversionResult = document.getElementById('conversionResult');
        this.convertBtn = document.getElementById('convertBtn');
        this.clearHistory = document.getElementById('clearHistory');
        this.exportHistory = document.getElementById('exportHistory');
    }

    bindEvents() {
        // Calculator buttons
        document.querySelectorAll('.btn').forEach(btn => {
            btn.addEventListener('click', () => this.handleButtonClick(btn));
        });

        // Tab switching
        document.querySelectorAll('.tab-btn').forEach(tab => {
            tab.addEventListener('click', () => this.switchTab(tab));
        });

        // Conversion
        this.convertBtn.addEventListener('click', () => this.performConversion());
        this.convertFrom.addEventListener('change', () => this.updateConversionOptions());
        this.convertValue.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.performConversion();
        });

        // History actions
        this.clearHistory.addEventListener('click', () => this.clearAllHistory());
        this.exportHistory.addEventListener('click', () => this.exportHistory());

        // Keyboard support
        document.addEventListener('keydown', (e) => this.handleKeyPress(e));
    }

    addThemeToggle() {
        const themeToggle = document.createElement('button');
        themeToggle.className = 'theme-btn';
        themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        themeToggle.title = 'Toggle theme';
        themeToggle.addEventListener('click', () => this.toggleTheme());

        const themeContainer = document.createElement('div');
        themeContainer.className = 'theme-toggle';
        themeContainer.appendChild(themeToggle);
        document.body.appendChild(themeContainer);

        // Load saved theme
        const savedTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', savedTheme);
        this.updateThemeIcon(savedTheme);
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        this.updateThemeIcon(newTheme);
    }

    updateThemeIcon(theme) {
        const themeBtn = document.querySelector('.theme-btn i');
        if (theme === 'dark') {
            themeBtn.className = 'fas fa-sun';
        } else {
            themeBtn.className = 'fas fa-moon';
        }
    }

    handleButtonClick(btn) {
        const action = btn.dataset.action;

        if (!action) return;

        switch (action) {
            case 'clear':
                this.clear();
                break;
            case 'clear-all':
                this.clearAll();
                break;
            case 'backspace':
                this.backspace();
                break;
            case 'equals':
                this.calculate();
                break;
            case 'decimal':
                this.inputDecimal();
                break;
            default:
                if (this.isNumber(action)) {
                    this.inputNumber(action);
                } else if (this.isOperator(action)) {
                    this.inputOperator(action);
                } else if (this.isFunction(action)) {
                    this.inputFunction(action);
                } else if (action.startsWith('const-')) {
                    this.inputConstant(action);
                }
                break;
        }

        this.updateDisplay();
    }

    handleKeyPress(e) {
        const key = e.key;

        if (key >= '0' && key <= '9') {
            this.inputNumber(key);
        } else if (key === '.') {
            this.inputDecimal();
        } else if (key === '+' || key === '-' || key === '*' || key === '/') {
            this.inputOperator(key === '*' ? 'multiply' : key === '/' ? 'divide' : key);
        } else if (key === 'Enter' || key === '=') {
            this.calculate();
        } else if (key === 'Escape') {
            this.clearAll();
        } else if (key === 'Backspace') {
            this.backspace();
        }

        this.updateDisplay();
    }

    isNumber(value) {
        return !isNaN(value) && value !== ' ';
    }

    isOperator(value) {
        return ['add', 'subtract', 'multiply', 'divide'].includes(value);
    }

    isFunction(value) {
        return ['sin', 'cos', 'tan', 'log', 'ln', 'sqrt', 'square', 'power', 'factorial', 'pi', 'e', 'inverse'].includes(value);
    }

    inputNumber(num) {
        if (this.waitingForOperand) {
            this.currentInput = num;
            this.waitingForOperand = false;
        } else {
            this.currentInput = this.currentInput === '0' ? num : this.currentInput + num;
        }
    }

    inputDecimal() {
        if (this.waitingForOperand) {
            this.currentInput = '0.';
            this.waitingForOperand = false;
        } else if (this.currentInput.indexOf('.') === -1) {
            this.currentInput += '.';
        }
    }

    inputOperator(nextOperator) {
        const inputValue = parseFloat(this.currentInput);

        if (this.previousInput && this.waitingForOperand) {
            this.operation = nextOperator;
            return;
        }

        if (this.previousInput == null) {
            this.previousInput = inputValue;
        } else if (this.operation) {
            const currentValue = this.previousInput || 0;
            const newValue = this.calculateResult(currentValue, inputValue, this.operation);

            this.currentInput = String(newValue);
            this.previousInput = newValue;
        }

        this.waitingForOperand = true;
        this.operation = nextOperator;
        this.expression = `${this.previousInput} ${this.getOperatorSymbol(nextOperator)} `;
    }

    inputFunction(func) {
        const inputValue = parseFloat(this.currentInput);
        let result;

        try {
            switch (func) {
                case 'sin':
                    result = Math.sin(this.toRadians(inputValue));
                    break;
                case 'cos':
                    result = Math.cos(this.toRadians(inputValue));
                    break;
                case 'tan':
                    result = Math.tan(this.toRadians(inputValue));
                    break;
                case 'log':
                    result = Math.log10(inputValue);
                    break;
                case 'ln':
                    result = Math.log(inputValue);
                    break;
                case 'sqrt':
                    result = Math.sqrt(inputValue);
                    break;
                case 'square':
                    result = Math.pow(inputValue, 2);
                    break;
                case 'power':
                    this.inputOperator('power');
                    return;
                case 'factorial':
                    result = this.factorial(inputValue);
                    break;
                case 'pi':
                    result = Math.PI;
                    break;
                case 'e':
                    result = Math.E;
                    break;
                case 'inverse':
                    result = 1 / inputValue;
                    break;
            }

            this.currentInput = String(result);
            this.waitingForOperand = true;
            this.addToHistory(`${func}(${inputValue})`, result);
        } catch (error) {
            this.showNotification('Invalid input for function', 'error');
        }
    }

    inputConstant(action) {
        // Handle constant buttons
        const constantValue = action.replace('const-', '');
        this.currentInput = constantValue;
        this.waitingForOperand = true;
    }

    calculate() {
        const inputValue = parseFloat(this.currentInput);

        if (this.previousInput && this.operation) {
            const currentValue = this.previousInput || 0;
            const newValue = this.calculateResult(currentValue, inputValue, this.operation);

            this.currentInput = String(newValue);
            this.previousInput = null;
            this.operation = null;
            this.waitingForOperand = true;

            this.addToHistory(this.expression + inputValue, newValue);
            this.expression = '';
        }
    }

    calculateResult(firstValue, secondValue, operation) {
        switch (operation) {
            case 'add':
                return firstValue + secondValue;
            case 'subtract':
                return firstValue - secondValue;
            case 'multiply':
                return firstValue * secondValue;
            case 'divide':
                return firstValue / secondValue;
            case 'power':
                return Math.pow(firstValue, secondValue);
            default:
                return secondValue;
        }
    }

    clear() {
        this.currentInput = '0';
        this.waitingForOperand = false;
    }

    clearAll() {
        this.currentInput = '0';
        this.previousInput = null;
        this.operation = null;
        this.waitingForOperand = false;
        this.expression = '';
    }

    backspace() {
        if (this.currentInput.length > 1) {
            this.currentInput = this.currentInput.slice(0, -1);
        } else {
            this.currentInput = '0';
        }
    }

    updateDisplay() {
        this.resultDisplay.textContent = this.formatNumber(this.currentInput);
        this.expressionDisplay.textContent = this.expression;
        this.historyDisplay.textContent = this.previousInput ? this.formatNumber(this.previousInput) : '';
    }

    formatNumber(num) {
        if (typeof num === 'string') {
            return num;
        }

        if (Number.isInteger(num)) {
            return num.toString();
        }

        return parseFloat(num.toFixed(10)).toString();
    }

    getOperatorSymbol(operation) {
        const symbols = {
            add: '+',
            subtract: '−',
            multiply: '×',
            divide: '÷',
            power: '^'
        };
        return symbols[operation] || operation;
    }

    toRadians(degrees) {
        return degrees * (Math.PI / 180);
    }

    factorial(n) {
        if (n < 0) return NaN;
        if (n === 0 || n === 1) return 1;
        return n * this.factorial(n - 1);
    }

    switchTab(tab) {
        const tabName = tab.dataset.tab;

        // Update tab buttons
        document.querySelectorAll('.tab-btn').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');

        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
        document.getElementById(tabName).classList.add('active');
    }

    updateConversionOptions() {
        const category = this.convertFrom.value;
        const toSelect = this.convertTo;

        // Clear existing options
        toSelect.innerHTML = '';

        const options = {
            length: [
                { value: 'meters', text: 'Meters' },
                { value: 'feet', text: 'Feet' },
                { value: 'inches', text: 'Inches' },
                { value: 'centimeters', text: 'Centimeters' },
                { value: 'kilometers', text: 'Kilometers' },
                { value: 'miles', text: 'Miles' }
            ],
            weight: [
                { value: 'kilograms', text: 'Kilograms' },
                { value: 'pounds', text: 'Pounds' },
                { value: 'grams', text: 'Grams' },
                { value: 'ounces', text: 'Ounces' }
            ],
            temperature: [
                { value: 'celsius', text: 'Celsius' },
                { value: 'fahrenheit', text: 'Fahrenheit' },
                { value: 'kelvin', text: 'Kelvin' }
            ],
            currency: [
                { value: 'usd', text: 'USD' },
                { value: 'inr', text: 'INR' },
                { value: 'eur', text: 'EUR' },
                { value: 'gbp', text: 'GBP' },
                { value: 'jpy', text: 'JPY' }
            ]
        };

        options[category].forEach(option => {
            const opt = document.createElement('option');
            opt.value = option.value;
            opt.textContent = option.text;
            toSelect.appendChild(opt);
        });
    }

    performConversion() {
        const value = parseFloat(this.convertValue.value);
        const from = this.convertFrom.value;
        const to = this.convertTo.value;

        if (isNaN(value)) {
            this.showNotification('Please enter a valid number', 'warning');
            return;
        }

        try {
            const result = this.convert(value, from, to);
            this.conversionResult.textContent = `${value} ${this.getUnitName(from, to)} = ${result.toFixed(4)} ${this.getUnitName(to, from)}`;
            this.showNotification('Conversion completed!', 'success');
        } catch (error) {
            this.showNotification('Conversion failed', 'error');
        }
    }

    convert(value, from, to) {
        // Length conversions
        if (from === 'length') {
            const meters = this.toMeters(value, to);
            return this.fromMeters(meters, to);
        }

        // Weight conversions
        if (from === 'weight') {
            const kg = this.toKilograms(value, to);
            return this.fromKilograms(kg, to);
        }

        // Temperature conversions
        if (from === 'temperature') {
            const celsius = this.toCelsius(value, to);
            return this.fromCelsius(celsius, to);
        }

        // Currency (mock conversion rates)
        if (from === 'currency') {
            return this.convertCurrency(value, to);
        }

        return value;
    }

    toMeters(value, from) {
        const conversions = {
            meters: value,
            feet: value * 0.3048,
            inches: value * 0.0254,
            centimeters: value * 0.01,
            kilometers: value * 1000,
            miles: value * 1609.344
        };
        return conversions[from] || value;
    }

    fromMeters(meters, to) {
        const conversions = {
            meters: meters,
            feet: meters / 0.3048,
            inches: meters / 0.0254,
            centimeters: meters / 0.01,
            kilometers: meters / 1000,
            miles: meters / 1609.344
        };
        return conversions[to] || meters;
    }

    toKilograms(value, from) {
        const conversions = {
            kilograms: value,
            pounds: value * 0.453592,
            grams: value * 0.001,
            ounces: value * 0.0283495
        };
        return conversions[from] || value;
    }

    fromKilograms(kg, to) {
        const conversions = {
            kilograms: kg,
            pounds: kg / 0.453592,
            grams: kg / 0.001,
            ounces: kg / 0.0283495
        };
        return conversions[to] || kg;
    }

    toCelsius(value, from) {
        const conversions = {
            celsius: value,
            fahrenheit: (value - 32) * 5/9,
            kelvin: value - 273.15
        };
        return conversions[from] || value;
    }

    fromCelsius(celsius, to) {
        const conversions = {
            celsius: celsius,
            fahrenheit: (celsius * 9/5) + 32,
            kelvin: celsius + 273.15
        };
        return conversions[to] || celsius;
    }

    convertCurrency(value, to) {
        // Mock exchange rates (in real app, fetch from API)
        const rates = {
            usd: 1,
            inr: 83.5,
            eur: 0.92,
            gbp: 0.79,
            jpy: 150.2
        };

        const usdValue = value / rates[to];
        return usdValue * rates[to];
    }

    getUnitName(category, unit) {
        const names = {
            length: {
                meters: 'm', feet: 'ft', inches: 'in', centimeters: 'cm',
                kilometers: 'km', miles: 'mi'
            },
            weight: {
                kilograms: 'kg', pounds: 'lb', grams: 'g', ounces: 'oz'
            },
            temperature: {
                celsius: '°C', fahrenheit: '°F', kelvin: 'K'
            },
            currency: {
                usd: 'USD', inr: 'INR', eur: 'EUR', gbp: 'GBP', jpy: 'JPY'
            }
        };
        return names[category]?.[unit] || unit;
    }

    addToHistory(expression, result) {
        const historyItem = {
            expression: expression,
            result: result,
            timestamp: new Date().toISOString()
        };

        this.history.unshift(historyItem);

        // Keep only last 50 items
        if (this.history.length > 50) {
            this.history = this.history.slice(0, 50);
        }

        this.saveHistory();
        this.updateHistoryDisplay();
    }

    updateHistoryDisplay() {
        if (this.history.length === 0) {
            this.historyList.innerHTML = '<div class="no-history">No calculations yet</div>';
            return;
        }

        this.historyList.innerHTML = this.history.slice(0, 20).map(item => `
            <div class="history-item">
                <span class="history-expression">${item.expression}</span>
                <span class="history-result">${this.formatNumber(item.result)}</span>
            </div>
        `).join('');
    }

    clearAllHistory() {
        this.history = [];
        this.saveHistory();
        this.updateHistoryDisplay();
        this.showNotification('History cleared', 'success');
    }

    exportHistory() {
        if (this.history.length === 0) {
            this.showNotification('No history to export', 'warning');
            return;
        }

        const csvContent = 'Expression,Result,Timestamp\n' +
            this.history.map(item =>
                `"${item.expression}","${item.result}","${item.timestamp}"`
            ).join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `calculator-history-${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
        URL.revokeObjectURL(url);

        this.showNotification('History exported!', 'success');
    }

    loadHistory() {
        const saved = localStorage.getItem('calculatorHistory');
        if (saved) {
            this.history = JSON.parse(saved);
            this.updateHistoryDisplay();
        }
    }

    saveHistory() {
        localStorage.setItem('calculatorHistory', JSON.stringify(this.history));
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 4000);
    }
}

// Initialize the calculator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const calculator = new Calculator();
});

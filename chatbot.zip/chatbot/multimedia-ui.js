// Enhanced UI Components for Multimedia AI Processing
class MultimediaUI {
    constructor(chatSystem) {
        this.chatSystem = chatSystem;
        this.processor = new MultimediaAIProcessor();
        this.activeAnalyses = new Map();
        this.init();
    }

    init() {
        this.createAdvancedFilePreview();
        this.createAnalysisModal();
        this.createProgressOverlay();
        this.enhanceFileUpload();
    }

    createAdvancedFilePreview() {
        const previewContainer = document.createElement('div');
        previewContainer.id = 'advancedFilePreview';
        previewContainer.className = 'advanced-file-preview';
        previewContainer.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 10000;
            display: none;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(5px);
        `;

        previewContainer.innerHTML = `
            <div class="preview-modal">
                <div class="preview-header">
                    <h3 id="previewTitle">File Preview</h3>
                    <button class="close-preview" id="closeAdvancedPreview">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="preview-body">
                    <div class="preview-sidebar">
                        <div class="file-info-panel">
                            <h4>File Information</h4>
                            <div id="fileInfoContent"></div>
                        </div>
                        <div class="analysis-options">
                            <h4>Analysis Options</h4>
                            <div class="option-group">
                                <label class="option-item">
                                    <input type="checkbox" id="deepAnalysis" checked>
                                    <span>Deep Analysis</span>
                                </label>
                                <label class="option-item">
                                    <input type="checkbox" id="objectDetection">
                                    <span>Object Detection</span>
                                </label>
                                <label class="option-item">
                                    <input type="checkbox" id="textExtraction" checked>
                                    <span>Text Extraction</span>
                                </label>
                                <label class="option-item">
                                    <input type="checkbox" id="colorAnalysis">
                                    <span>Color Analysis</span>
                                </label>
                            </div>
                            <button class="analyze-btn" id="startAnalysis">
                                <i class="fas fa-brain"></i>
                                Analyze with AI
                            </button>
                        </div>
                    </div>
                    <div class="preview-main">
                        <div class="preview-content" id="previewContentArea"></div>
                        <div class="analysis-results" id="analysisResults" style="display: none;">
                            <h4>Analysis Results</h4>
                            <div id="analysisContent"></div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(previewContainer);

        // Add event listeners
        document.getElementById('closeAdvancedPreview').addEventListener('click', () => {
            this.closeAdvancedPreview();
        });

        previewContainer.addEventListener('click', (e) => {
            if (e.target === previewContainer) {
                this.closeAdvancedPreview();
            }
        });

        document.getElementById('startAnalysis').addEventListener('click', () => {
            this.performAdvancedAnalysis();
        });
    }

    createAnalysisModal() {
        const modal = document.createElement('div');
        modal.id = 'analysisModal';
        modal.className = 'analysis-modal';
        modal.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 2rem;
            z-index: 10001;
            display: none;
            max-width: 500px;
            width: 90%;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        `;

        modal.innerHTML = `
            <div class="modal-header">
                <h3>AI Analysis in Progress</h3>
                <div class="progress-indicator">
                    <div class="progress-bar">
                        <div class="progress-fill" id="analysisProgress"></div>
                    </div>
                    <span class="progress-text" id="progressText">Initializing...</span>
                </div>
            </div>
            <div class="modal-body">
                <div class="analysis-steps" id="analysisSteps">
                    <div class="step" data-step="1">
                        <div class="step-icon">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <div class="step-content">
                            <h4>Reading File</h4>
                            <p>Analyzing file structure and content</p>
                        </div>
                        <div class="step-status" id="step1Status">
                            <i class="fas fa-spinner fa-spin"></i>
                        </div>
                    </div>
                    <div class="step" data-step="2">
                        <div class="step-icon">
                            <i class="fas fa-brain"></i>
                        </div>
                        <div class="step-content">
                            <h4>AI Processing</h4>
                            <p>Running advanced analysis algorithms</p>
                        </div>
                        <div class="step-status" id="step2Status">
                            <i class="fas fa-clock"></i>
                        </div>
                    </div>
                    <div class="step" data-step="3">
                        <div class="step-icon">
                            <i class="fas fa-chart-bar"></i>
                        </div>
                        <div class="step-content">
                            <h4>Generating Results</h4>
                            <p>Compiling analysis findings</p>
                        </div>
                        <div class="step-status" id="step3Status">
                            <i class="fas fa-clock"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="cancel-btn" id="cancelAnalysis">
                    <i class="fas fa-times"></i>
                    Cancel
                </button>
            </div>
        `;

        document.body.appendChild(modal);

        document.getElementById('cancelAnalysis').addEventListener('click', () => {
            this.cancelAnalysis();
        });
    }

    createProgressOverlay() {
        const overlay = document.createElement('div');
        overlay.id = 'progressOverlay';
        overlay.className = 'progress-overlay';
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            display: none;
            align-items: center;
            justify-content: center;
        `;

        overlay.innerHTML = `
            <div class="progress-container">
                <div class="progress-spinner">
                    <i class="fas fa-spinner fa-spin"></i>
                </div>
                <div class="progress-message" id="progressMessage">
                    Processing file...
                </div>
            </div>
        `;

        document.body.appendChild(overlay);
    }

    enhanceFileUpload() {
        // Add advanced file preview to existing file upload
        const existingPreview = document.getElementById('filePreview');
        if (existingPreview) {
            const advancedPreviewBtn = document.createElement('button');
            advancedPreviewBtn.className = 'advanced-preview-btn';
            advancedPreviewBtn.innerHTML = '<i class="fas fa-magic"></i> Advanced AI Analysis';
            advancedPreviewBtn.title = 'Open advanced AI analysis';

            advancedPreviewBtn.addEventListener('click', () => {
                this.openAdvancedPreview(this.chatSystem.selectedFile);
            });

            existingPreview.querySelector('.preview-header').appendChild(advancedPreviewBtn);
        }
    }

    openAdvancedPreview(file) {
        if (!file) return;

        this.currentFile = file;
        const modal = document.getElementById('advancedFilePreview');
        const title = document.getElementById('previewTitle');
        const content = document.getElementById('previewContentArea');
        const info = document.getElementById('fileInfoContent');

        // Set title
        title.textContent = `Advanced Analysis: ${file.name}`;

        // Show file preview
        this.showFilePreview(file, content);

        // Show file information
        this.showFileInfo(file, info);

        // Show modal
        modal.style.display = 'flex';
    }

    closeAdvancedPreview() {
        const modal = document.getElementById('advancedFilePreview');
        modal.style.display = 'none';
        this.currentFile = null;
    }

    showFilePreview(file, container) {
        container.innerHTML = '';

        const extension = file.name.split('.').pop().toLowerCase();
        const isImage = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(extension);
        const isVideo = ['mp4', 'avi', 'mov', 'mkv', 'webm'].includes(extension);

        if (isImage) {
            const img = document.createElement('img');
            img.src = URL.createObjectURL(file);
            img.style.cssText = `
                max-width: 100%;
                max-height: 400px;
                object-fit: contain;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            `;
            container.appendChild(img);
        } else if (isVideo) {
            const video = document.createElement('video');
            video.src = URL.createObjectURL(file);
            video.controls = true;
            video.style.cssText = `
                max-width: 100%;
                max-height: 400px;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            `;
            container.appendChild(video);
        } else {
            // Document preview
            const docPreview = document.createElement('div');
            docPreview.className = 'document-preview';
            docPreview.style.cssText = `
                width: 100%;
                height: 400px;
                background: var(--bg-tertiary);
                border: 2px dashed var(--border-color);
                border-radius: 8px;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-direction: column;
                color: var(--text-secondary);
            `;

            const icon = document.createElement('i');
            icon.className = 'fas fa-file-alt';
            icon.style.fontSize = '48px';

            const text = document.createElement('p');
            text.textContent = 'Document Preview';
            text.style.marginTop = '1rem';

            docPreview.appendChild(icon);
            docPreview.appendChild(text);
            container.appendChild(docPreview);
        }
    }

    showFileInfo(file, container) {
        const info = document.createElement('div');
        info.className = 'file-info';

        const size = this.processor.formatFileSize(file.size);
        const type = file.type || 'Unknown';
        const extension = file.name.split('.').pop().toUpperCase();

        info.innerHTML = `
            <div class="info-item">
                <strong>Name:</strong> ${file.name}
            </div>
            <div class="info-item">
                <strong>Size:</strong> ${size}
            </div>
            <div class="info-item">
                <strong>Type:</strong> ${type}
            </div>
            <div class="info-item">
                <strong>Extension:</strong> ${extension}
            </div>
            <div class="info-item">
                <strong>Modified:</strong> ${new Date(file.lastModified).toLocaleDateString()}
            </div>
        `;

        container.innerHTML = '';
        container.appendChild(info);
    }

    async performAdvancedAnalysis() {
        if (!this.currentFile) return;

        const options = {
            deepAnalysis: document.getElementById('deepAnalysis').checked,
            objectDetection: document.getElementById('objectDetection').checked,
            textExtraction: document.getElementById('textExtraction').checked,
            colorAnalysis: document.getElementById('colorAnalysis').checked
        };

        this.showAnalysisModal();
        this.updateProgress(0, 'Starting analysis...');

        try {
            // Step 1: Reading file
            this.updateStepStatus(1, 'active');
            await this.delay(1000);
            this.updateStepStatus(1, 'completed');
            this.updateProgress(25, 'File read successfully');

            // Step 2: AI Processing
            this.updateStepStatus(2, 'active');
            const analysis = await this.processor.processFile(this.currentFile, options);
            this.updateStepStatus(2, 'completed');
            this.updateProgress(75, 'AI analysis completed');

            // Step 3: Generating results
            this.updateStepStatus(3, 'active');
            await this.delay(500);
            this.updateStepStatus(3, 'completed');
            this.updateProgress(100, 'Results generated');

            // Show results
            await this.delay(500);
            this.hideAnalysisModal();
            this.showAnalysisResults(analysis);

        } catch (error) {
            this.hideAnalysisModal();
            this.showError('Analysis failed: ' + error.message);
        }
    }

    showAnalysisModal() {
        const modal = document.getElementById('analysisModal');
        modal.style.display = 'block';
    }

    hideAnalysisModal() {
        const modal = document.getElementById('analysisModal');
        modal.style.display = 'none';
    }

    updateProgress(percent, message) {
        const progressFill = document.getElementById('analysisProgress');
        const progressText = document.getElementById('progressText');

        progressFill.style.width = percent + '%';
        progressText.textContent = message;
    }

    updateStepStatus(stepNumber, status) {
        const step = document.querySelector(`[data-step="${stepNumber}"]`);
        const statusIcon = document.getElementById(`step${stepNumber}Status`);

        // Remove existing classes
        step.classList.remove('pending', 'active', 'completed', 'error');
        statusIcon.className = 'step-status';

        switch (status) {
            case 'pending':
                statusIcon.innerHTML = '<i class="fas fa-clock"></i>';
                step.classList.add('pending');
                break;
            case 'active':
                statusIcon.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
                step.classList.add('active');
                break;
            case 'completed':
                statusIcon.innerHTML = '<i class="fas fa-check"></i>';
                step.classList.add('completed');
                break;
            case 'error':
                statusIcon.innerHTML = '<i class="fas fa-times"></i>';
                step.classList.add('error');
                break;
        }
    }

    showAnalysisResults(analysis) {
        const resultsContainer = document.getElementById('analysisResults');
        const content = document.getElementById('analysisContent');

        resultsContainer.style.display = 'block';

        const resultsHTML = this.generateResultsHTML(analysis);
        content.innerHTML = resultsHTML;

        // Scroll to results
        resultsContainer.scrollIntoView({ behavior: 'smooth' });
    }

    generateResultsHTML(analysis) {
        let html = `<div class="analysis-summary">`;

        // File type specific results
        switch (analysis.type) {
            case 'image':
                html += this.generateImageResults(analysis.analysis);
                break;
            case 'document':
                html += this.generateDocumentResults(analysis.analysis);
                break;
            case 'video':
                html += this.generateVideoResults(analysis.analysis);
                break;
            default:
                html += `<p>Analysis type not supported yet.</p>`;
        }

        html += `</div>`;
        return html;
    }

    generateImageResults(results) {
        let html = `<h4>Image Analysis Results</h4>`;

        if (results.basic) {
            html += `
                <div class="result-section">
                    <h5>Basic Information</h5>
                    <ul>
                        <li><strong>Dimensions:</strong> ${results.basic.dimensions.width} x ${results.basic.dimensions.height}</li>
                        <li><strong>Size:</strong> ${results.basic.size}</li>
                        <li><strong>Aspect Ratio:</strong> ${results.basic.dimensions.aspectRatio}</li>
                    </ul>
                </div>
            `;
        }

        if (results.ai) {
            html += `
                <div class="result-section">
                    <h5>AI Analysis</h5>
                    <p>${results.ai.description}</p>
                    <div class="confidence-meter">
                        <span>Confidence: ${(results.ai.confidence * 100).toFixed(1)}%</span>
                        <div class="meter">
                            <div class="meter-fill" style="width: ${results.ai.confidence * 100}%"></div>
                        </div>
                    </div>
                </div>
            `;
        }

        if (results.text) {
            html += `
                <div class="result-section">
                    <h5>Extracted Text</h5>
                    <div class="text-content">
                        ${results.text.text}
                    </div>
                </div>
            `;
        }

        if (results.colors) {
            html += `
                <div class="result-section">
                    <h5>Color Analysis</h5>
                    <div class="color-palette">
                        ${results.colors.dominant.map(color =>
                            `<div class="color-item" style="background-color: ${color.hex}" title="${color.name} - ${color.percentage}%"></div>`
                        ).join('')}
                    </div>
                </div>
            `;
        }

        return html;
    }

    generateDocumentResults(results) {
        let html = `<h4>Document Analysis Results</h4>`;

        if (results.basic) {
            html += `
                <div class="result-section">
                    <h5>Document Information</h5>
                    <ul>
                        <li><strong>Pages:</strong> ${results.basic.pages || 'N/A'}</li>
                        <li><strong>Size:</strong> ${results.basic.size}</li>
                        <li><strong>Type:</strong> ${results.basic.type}</li>
                    </ul>
                </div>
            `;
        }

        if (results.text && results.text.text) {
            html += `
                <div class="result-section">
                    <h5>Content Preview</h5>
                    <div class="text-content">
                        ${results.text.text.substring(0, 1000)}${results.text.text.length > 1000 ? '...' : ''}
                    </div>
                </div>
            `;
        }

        if (results.summary) {
            html += `
                <div class="result-section">
                    <h5>Summary</h5>
                    <div class="summary-content">
                        ${results.summary.short}
                    </div>
                </div>
            `;
        }

        return html;
    }

    generateVideoResults(results) {
        let html = `<h4>Video Analysis Results</h4>`;

        if (results.basic) {
            html += `
                <div class="result-section">
                    <h5>Video Information</h5>
                    <ul>
                        <li><strong>Duration:</strong> ${Math.floor(results.basic.duration / 60)}:${Math.floor(results.basic.duration % 60).toString().padStart(2, '0')}</li>
                        <li><strong>Resolution:</strong> ${results.basic.dimensions.width} x ${results.basic.dimensions.height}</li>
                        <li><strong>Size:</strong> ${results.basic.size}</li>
                    </ul>
                </div>
            `;
        }

        if (results.transcription) {
            html += `
                <div class="result-section">
                    <h5>Transcription</h5>
                    <div class="text-content">
                        ${results.transcription.text}
                    </div>
                </div>
            `;
        }

        return html;
    }

    showError(message) {
        const notification = document.createElement('div');
        notification.className = 'error-notification';
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--error-color);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            z-index: 10002;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        `;

        notification.innerHTML = `
            <div style="display: flex; align-items: center; gap: 0.5rem;">
                <i class="fas fa-exclamation-triangle"></i>
                <span>${message}</span>
            </div>
        `;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 5000);
    }

    cancelAnalysis() {
        this.hideAnalysisModal();
        this.showError('Analysis cancelled by user');
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // Integration with main chat system
    integrateWithChat() {
        // Override the existing file processing
        const originalProcessFiles = this.chatSystem.processFiles.bind(this.chatSystem);
        this.chatSystem.processFiles = async (files) => {
            for (const file of files) {
                if (this.processor.validateFile(file)) {
                    this.chatSystem.selectedFile = file;
                    this.showFilePreview(file, document.getElementById('previewContent'));
                    document.getElementById('filePreview').style.display = 'block';
                    document.getElementById('fileUploadArea').style.display = 'none';
                    this.chatSystem.fileBtn.classList.remove('active');

                    // Show success message
                    this.chatSystem.showNotification(`File "${file.name}" ready for analysis!`, 'success');
                }
            }
        };

        // Enhance send message to include AI analysis
        const originalSendMessage = this.chatSystem.sendMessage.bind(this.chatSystem);
        this.chatSystem.sendMessage = async () => {
            if (this.chatSystem.selectedFile) {
                this.showProgressOverlay('Analyzing file with AI...');

                try {
                    const analysis = await this.processor.processFile(this.chatSystem.selectedFile);
                    const aiResponse = this.processor.generateFileResponse(analysis);

                    // Add user message with file
                    this.chatSystem.addMessageWithFile(
                        this.chatSystem.selectedFile,
                        `Please analyze this file: ${this.chatSystem.selectedFile.name}`,
                        'user'
                    );

                    // Add AI response
                    this.chatSystem.addMessage(aiResponse, 'assistant');

                    this.chatSystem.removeSelectedFile();
                    this.hideProgressOverlay();

                } catch (error) {
                    this.hideProgressOverlay();
                    this.chatSystem.showNotification('File analysis failed: ' + error.message, 'error');
                }
            } else {
                originalSendMessage();
            }
        };
    }

    showProgressOverlay(message) {
        const overlay = document.getElementById('progressOverlay');
        const messageEl = document.getElementById('progressMessage');
        messageEl.textContent = message;
        overlay.style.display = 'flex';
    }

    hideProgressOverlay() {
        const overlay = document.getElementById('progressOverlay');
        overlay.style.display = 'none';
    }
}

// Make it globally available
window.MultimediaUI = MultimediaUI;

// Enhanced Multilingual Support for NavaBharat AI with Complete Translations
class MultilingualSupport {
    constructor(multimediaAI) {
        this.multimediaAI = multimediaAI;
        this.currentLanguage = 'en';
        this.supportedLanguages = {
            'en': { name: 'English', flag: '🇺🇸', native: 'English' },
            'hi': { name: 'Hindi', flag: '🇮🇳', native: 'हिन्दी' },
            'te': { name: 'Telugu', flag: '🇮🇳', native: 'తెలుగు' },
            'ta': { name: 'Tamil', flag: '🇮🇳', native: 'தமிழ்' },
            'mr': { name: 'Marathi', flag: '🇮🇳', native: 'मराठी' },
            'gu': { name: 'Gujarati', flag: '🇮🇳', native: 'ગુજરાતી' },
            'pa': { name: 'Punjabi', flag: '🇮🇳', native: 'ਪੰਜਾਬੀ' },
            'bn': { name: 'Bengali', flag: '🇮🇳', native: 'বাংলা' },
            'ur': { name: 'Urdu', flag: '🇵🇰', native: 'اردو' },
            'es': { name: 'Spanish', flag: '🇪🇸', native: 'Español' },
            'fr': { name: 'French', flag: '🇫🇷', native: 'Français' },
            'de': { name: 'German', flag: '🇩🇪', native: 'Deutsch' },
            'zh': { name: 'Chinese', flag: '🇨🇳', native: '中文' },
            'ja': { name: 'Japanese', flag: '🇯🇵', native: '日本語' },
            'ko': { name: 'Korean', flag: '🇰🇷', native: '한국어' }
        };

        this.translations = this.loadCompleteTranslations();
        this.init();
    }

    init() {
        this.createLanguageSelector();
        this.updateUILanguage();
    }

    loadCompleteTranslations() {
        return {
            en: {
                // Processing messages
                processingFile: "Processing file...",
                analyzingImage: "Analyzing image...",
                extractingText: "Extracting text...",
                processingDocument: "Processing document...",
                analyzingVideo: "Analyzing video...",

                // UI Labels
                fileInformation: "File Information",
                aiAnalysis: "AI Analysis",
                extractedText: "Extracted Text",
                colorAnalysis: "Color Analysis",
                documentInformation: "Document Information",
                contentPreview: "Content Preview",
                summary: "Summary",
                keyInformation: "Key Information",
                videoInformation: "Video Information",
                transcription: "Transcription",
                sceneAnalysis: "Scene Analysis",

                // AI Response messages
                whatWouldYouLike: "What would you like to know more about?",
                regardingQuestion: "Regarding your question",
                iCanHelp: "I can help you understand the content and provide insights.",

                // Action buttons
                analyzeSpecific: "Analyze specific aspects",
                extractText: "Extract and explain any text",
                describeObjects: "Describe objects or scenes in detail",
                compareImages: "Compare with other images",
                extractInfo: "Extract specific information",
                summarizeContent: "Summarize sections or the entire document",
                answerQuestions: "Answer questions about the content",
                compareDocuments: "Compare with other documents",
                provideTranscription: "Provide detailed transcription",
                analyzeScenes: "Analyze specific scenes or timestamps",
                summarizeVideo: "Summarize the video content",
                answerVideoQuestions: "Answer questions about what's shown or said",

                // UI Elements
                newChat: "New Chat",
                aiAnalysis: "AI Analysis",
                messagePlaceholder: "Message NavaBharat AI or upload files...",
                suggestions: ["Write an email", "Explain quantum physics", "Create a recipe", "Plan a trip"],
                disclaimer: "NavaBharat AI can make mistakes. Check important info.",
                messages: "messages"
            },
            hi: {
                processingFile: "फ़ाइल प्रोसेस कर रहा हूं...",
                analyzingImage: "इमेज का विश्लेषण कर रहा हूं...",
                extractingText: "टेक्स्ट निकाल रहा हूं...",
                processingDocument: "दस्तावेज़ प्रोसेस कर रहा हूं...",
                analyzingVideo: "वीडियो का विश्लेषण कर रहा हूं...",

                fileInformation: "फ़ाइल जानकारी",
                aiAnalysis: "AI विश्लेषण",
                extractedText: "निकाला गया टेक्स्ट",
                colorAnalysis: "रंग विश्लेषण",
                documentInformation: "दस्तावेज़ जानकारी",
                contentPreview: "सामग्री पूर्वावलोकन",
                summary: "सारांश",
                keyInformation: "मुख्य जानकारी",
                videoInformation: "वीडियो जानकारी",
                transcription: "प्रतिलेखन",
                sceneAnalysis: "दृश्य विश्लेषण",

                whatWouldYouLike: "आप और क्या जानना चाहेंगे?",
                regardingQuestion: "आपके प्रश्न के संबंध में",
                iCanHelp: "मैं सामग्री को समझने और अंतर्दृष्टि प्रदान करने में आपकी मदद कर सकता हूं।",

                analyzeSpecific: "विशिष्ट पहलुओं का विश्लेषण करें",
                extractText: "कोई भी टेक्स्ट निकालें और समझाएं",
                describeObjects: "वस्तुओं या दृश्यों का विस्तार से वर्णन करें",
                compareImages: "अन्य इमेज के साथ तुलना करें",
                extractInfo: "विशिष्ट जानकारी निकालें",
                summarizeContent: "अनुभागों या संपूर्ण दस्तावेज़ का सारांश बनाएं",
                answerQuestions: "सामग्री के बारे में प्रश्नों के उत्तर दें",
                compareDocuments: "अन्य दस्तावेज़ों के साथ तुलना करें",
                provideTranscription: "विस्तृत प्रतिलेखन प्रदान करें",
                analyzeScenes: "विशिष्ट दृश्यों या टाइमस्टैम्प का विश्लेषण करें",
                summarizeVideo: "वीडियो सामग्री का सारांश बनाएं",
                answerVideoQuestions: "जो दिखाया या कहा गया है उसके बारे में प्रश्नों के उत्तर दें",

                newChat: "नया चैट",
                aiAnalysis: "AI विश्लेषण",
                messagePlaceholder: "NavaBharat AI को संदेश दें या फाइलें अपलोड करें...",
                suggestions: ["ईमेल लिखें", "क्वांटम भौतिकी समझाएं", "रेसिपी बनाएं", "यात्रा की योजना बनाएं"],
                disclaimer: "NavaBharat AI गलतियां कर सकता है। महत्वपूर्ण जानकारी की जांच करें।",
                messages: "संदेश"
            },
            te: {
                processingFile: "ఫైల్ ప్రాసెస్ చేస్తున్నాను...",
                analyzingImage: "ఇమేజ్ విశ్లేషణ చేస్తున్నాను...",
                extractingText: "టెక్స్ట్ సంగ్రహిస్తున్నాను...",
                processingDocument: "డాక్యుమెంట్ ప్రాసెస్ చేస్తున్నాను...",
                analyzingVideo: "వీడియో విశ్లేషణ చేస్తున్నాను...",

                fileInformation: "ఫైల్ సమాచారం",
                aiAnalysis: "AI విశ్లేషణ",
                extractedText: "సంగ్రహించిన టెక్స్ట్",
                colorAnalysis: "రంగు విశ్లేషణ",
                documentInformation: "డాక్యుమెంట్ సమాచారం",
                contentPreview: "కంటెంట్ ప్రివ్యూ",
                summary: "సారాంశం",
                keyInformation: "ముఖ్య సమాచారం",
                videoInformation: "వీడియో సమాచారం",
                transcription: "ట్రాన్స్క్రిప్షన్",
                sceneAnalysis: "సీన్ విశ్లేషణ",

                whatWouldYouLike: "మీరు ఇంకా ఏమి తెలుసుకోవాలనుకుంటున్నారు?",
                regardingQuestion: "మీ ప్రశ్నకు సంబంధించి",
                iCanHelp: "నేను కంటెంట్ అర్థం చేసుకోవడంలో మరియు అంతర్దృష్టులు అందించడంలో మీకు సహాయపడగలను.",

                analyzeSpecific: "నిర్దిష్ట అంశాలను విశ్లేషించండి",
                extractText: "టెక్స్ట్ సంగ్రహించండి మరియు వివరించండి",
                describeObjects: "వస్తువులు లేదా దృశ్యాలను వివరంగా వర్ణించండి",
                compareImages: "ఇతర చిత్రాలతో పోల్చండి",
                extractInfo: "నిర్దిష్ట సమాచారాన్ని సంగ్రహించండి",
                summarizeContent: "విభాగాలు లేదా మొత్తం డాక్యుమెంట్ సారాంశం",
                answerQuestions: "కంటెంట్ గురించి ప్రశ్నలకు సమాధానం ఇవ్వండి",
                compareDocuments: "ఇతర డాక్యుమెంట్లతో పోల్చండి",
                provideTranscription: "వివరణాత్మక ట్రాన్స్క్రిప్షన్ అందించండి",
                analyzeScenes: "నిర్దిష్ట దృశ్యాలు లేదా టైమ్‌స్టాంప్‌లను విశ్లేషించండి",
                summarizeVideo: "వీడియో కంటెంట్ సారాంశం",
                answerVideoQuestions: "చూపిన లేదా చెప్పిన దాని గురించి ప్రశ్నలకు సమాధానం ఇవ్వండి",

                newChat: "కొత్త చాట్",
                aiAnalysis: "AI విశ్లేషణ",
                messagePlaceholder: "NavaBharat AIకి సందేశం పంపండి లేదా ఫైల్‌లను అప్‌లోడ్ చేయండి...",
                suggestions: ["ఇమెయిల్ రాయండి", "క్వాంటమ్ భౌతిక శాస్త్రాన్ని వివరించండి", "వంటకం సృష్టించండి", "ప్రయాణాన్ని ప్రణాళిక చేయండి"],
                disclaimer: "NavaBharat AI తప్పులు చేయవచ్చు. ముఖ్యమైన సమాచారాన్ని తనిఖీ చేయండి.",
                messages: "సందేశాలు"
            },
            ta: {
                processingFile: "கோப்பைச் செயலாக்குகிறது...",
                analyzingImage: "படத்தை பகுப்பாய்வு செய்கிறது...",
                extractingText: "உரையைப் பிரித்தெடுக்கிறது...",
                processingDocument: "ஆவணத்தைச் செயலாக்குகிறது...",
                analyzingVideo: "வீடியோவை பகுப்பாய்வு செய்கிறது...",

                fileInformation: "கோப்பு தகவல்",
                aiAnalysis: "AI பகுப்பாய்வு",
                extractedText: "பிரித்தெடுக்கப்பட்ட உரை",
                colorAnalysis: "நிற பகுப்பாய்வு",
                documentInformation: "ஆவண தகவல்",
                contentPreview: "உள்ளடக்க முன்னோட்டம்",
                summary: "சுருக்கம்",
                keyInformation: "முக்கிய தகவல்",
                videoInformation: "வீடியோ தகவல்",
                transcription: "படியெடுத்தல்",
                sceneAnalysis: "காட்சி பகுப்பாய்வு",

                whatWouldYouLike: "நீங்கள் இன்னும் என்ன தெரிந்துகொள்ள விரும்புகிறீர்கள்?",
                regardingQuestion: "உங்கள் கேள்விக்கு தொடர்புடையது",
                iCanHelp: "உள்ளடக்கத்தைப் புரிந்துகொள்ளவும், நுண்ணறிவுகளை வழங்கவும் உங்களுக்கு உதவ முடியும்.",

                analyzeSpecific: "குறிப்பிட்ட அம்சங்களை பகுப்பாய்வு செய்யவும்",
                extractText: "எந்த உரையையும் பிரித்தெடுத்து விளக்கவும்",
                describeObjects: "பொருட்கள் அல்லது காட்சிகளை விரிவாக விவரிக்கவும்",
                compareImages: "பிற படங்களுடன் ஒப்பிடவும்",
                extractInfo: "குறிப்பிட்ட தகவலை பிரித்தெடுக்கவும்",
                summarizeContent: "பிரிவுகள் அல்லது முழு ஆவணத்தின் சுருக்கத்தை உருவாக்கவும்",
                answerQuestions: "உள்ளடக்கம் பற்றிய கேள்விகளுக்கு பதிலளிக்கவும்",
                compareDocuments: "பிற ஆவணங்களுடன் ஒப்பிடவும்",
                provideTranscription: "விரிவான படியெடுத்தலை வழங்கவும்",
                analyzeScenes: "குறிப்பிட்ட காட்சிகள் அல்லது நேர முத்திரைகளை பகுப்பாய்வு செய்யவும்",
                summarizeVideo: "வீடியோ உள்ளடக்கத்தின் சுருக்கத்தை உருவாக்கவும்",
                answerVideoQuestions: "காட்டப்பட்ட அல்லது சொல்லப்பட்டதைப் பற்றிய கேள்விகளுக்கு பதிலளிக்கவும்",

                newChat: "புதிய அரட்டை",
                aiAnalysis: "AI பகுப்பாய்வு",
                messagePlaceholder: "NavaBharat AI-க்கு செய்தி அனுப்பவும் அல்லது கோப்புகளை பதிவேற்றவும்...",
                suggestions: ["மின்னஞ்சல் எழுது", "குவாண்டம் இயற்பியலை விளக்கு", "சமையல் குறிப்பை உருவாக்கு", "பயணத்தை திட்டமிடு"],
                disclaimer: "NavaBharat AI தவறு செய்யலாம். முக்கியமான தகவலை சரிபார்க்கவும்.",
                messages: "செய்திகள்"
            },
            mr: {
                processingFile: "फाईल प्रोसेस करत आहे...",
                analyzingImage: "इमेजचे विश्लेषण करत आहे...",
                extractingText: "मजकूर काढत आहे...",
                processingDocument: "दस्तऐवज प्रोसेस करत आहे...",
                analyzingVideo: "व्हिडिओचे विश्लेषण करत आहे...",

                fileInformation: "फाईल माहिती",
                aiAnalysis: "AI विश्लेषण",
                extractedText: "काढलेला मजकूर",
                colorAnalysis: "रंग विश्लेषण",
                documentInformation: "दस्तऐवज माहिती",
                contentPreview: "सामग्री पूर्वावलोकन",
                summary: "सारांश",
                keyInformation: "मुख्य माहिती",
                videoInformation: "व्हिडिओ माहिती",
                transcription: "लिप्यंतरण",
                sceneAnalysis: "दृश्य विश्लेषण",

                whatWouldYouLike: "तुम्हाला आणखी काय जाणून घ्यायचे आहे?",
                regardingQuestion: "तुमच्या प्रश्नासंबंधी",
                iCanHelp: "मी सामग्री समजून घेण्यात आणि अंतर्दृष्टी प्रदान करण्यात तुम्हाला मदत करू शकतो.",

                analyzeSpecific: "विशिष्ट पैलूंचे विश्लेषण करा",
                extractText: "कोणताही मजकूर काढा आणि स्पष्ट करा",
                describeObjects: "वस्तू किंवा दृश्यांचे तपशीलवार वर्णन करा",
                compareImages: "इतर इमेजशी तुलना करा",
                extractInfo: "विशिष्ट माहिती काढा",
                summarizeContent: "विभाग किंवा संपूर्ण दस्तऐवजाचा सारांश तयार करा",
                answerQuestions: "सामग्रीबद्दलच्या प्रश्नांची उत्तरे द्या",
                compareDocuments: "इतर दस्तऐवजांशी तुलना करा",
                provideTranscription: "तपशीलवार लिप्यंतरण प्रदान करा",
                analyzeScenes: "विशिष्ट दृश्ये किंवा टाइमस्टॅम्पचे विश्लेषण करा",
                summarizeVideo: "व्हिडिओ सामग्रीचा सारांश तयार करा",
                answerVideoQuestions: "दाखवलेल्या किंवा सांगितलेल्या गोष्टींबद्दलच्या प्रश्नांची उत्तरे द्या",

                newChat: "नवीन चॅट",
                aiAnalysis: "AI विश्लेषण",
                messagePlaceholder: "NavaBharat AI ला संदेश पाठवा किंवा फायली अपलोड करा...",
                suggestions: ["ईमेल लिहा", "क्वांटम भौतिकशास्त्र समजावून सांगा", "रेसिपी तयार करा", "प्रवासाचे नियोजन करा"],
                disclaimer: "NavaBharat AI चूक करू शकतो. महत्त्वाची माहिती तपासा.",
                messages: "संदेश"
            },
            gu: {
                processingFile: "ફાઇલ પ્રોસેસ કરી રહ્યું છે...",
                analyzingImage: "ઇમેજનું વિશ્લેષણ કરી રહ્યું છે...",
                extractingText: "ટેક્સ્ટ કાઢી રહ્યું છે...",
                processingDocument: "દસ્તાવેજ પ્રોસેસ કરી રહ્યું છે...",
                analyzingVideo: "વિડિઓનું વિશ્લેષણ કરી રહ્યું છે...",

                fileInformation: "ફાઇલ માહિતી",
                aiAnalysis: "AI વિશ્લેષણ",
                extractedText: "કાઢેલ ટેક્સ્ટ",
                colorAnalysis: "રંગ વિશ્લેષણ",
                documentInformation: "દસ્તાવેજ માહિતી",
                contentPreview: "સામગ્રી પૂર્વાવલોકન",
                summary: "સારાંશ",
                keyInformation: "મુખ્ય માહિતી",
                videoInformation: "વિડિઓ માહિતી",
                transcription: "લિપ્યંતરણ",
                sceneAnalysis: "દ્રશ્ય વિશ્લેષણ",

                whatWouldYouLike: "તમે બીજું શું જાણવા માંગો છો?",
                regardingQuestion: "તમારા પ્રશ્ન અંગે",
                iCanHelp: "હું સામગ્રી સમજવામાં અને અંતર્દૃષ્ટિ પ્રદાન કરવામાં તમારી મદદ કરી શકું છું.",

                analyzeSpecific: "વિશિષ્ટ પાસાઓનું વિશ્લેષણ કરો",
                extractText: "કોઈપણ ટેક્સ્ટ કાઢો અને સમજાવો",
                describeObjects: "વસ્તુઓ અથવા દ્રશ્યોનું વિગતવાર વર્ણન કરો",
                compareImages: "અન્ય ઇમેજ સાથે સરખામણી કરો",
                extractInfo: "વિશિષ્ટ માહિતી કાઢો",
                summarizeContent: "વિભાગો અથવા સંપૂર્ણ દસ્તાવેજનો સારાંશ બનાવો",
                answerQuestions: "સામગ્રી વિશેના પ્રશ્નોના જવાબ આપો",
                compareDocuments: "અન્ય દસ્તાવેજો સાથે સરખામણી કરો",
                provideTranscription: "વિગતવાર લિપ્યંતરણ પ્રદાન કરો",
                analyzeScenes: "વિશિષ્ટ દ્રશ્યો અથવા ટાઇમસ્ટેમ્પનું વિશ્લેષણ કરો",
                summarizeVideo: "વિડિઓ સામગ્રીનો સારાંશ બનાવો",
                answerVideoQuestions: "બતાવેલા અથવા કહેવામાં આવેલા વિશેના પ્રશ્નોના જવાબ આપો",

                newChat: "નવી ચેટ",
                aiAnalysis: "AI વિશ્લેષણ",
                messagePlaceholder: "NavaBharat AIને સંદેશો મોકલો અથવા ફાઇલો અપલોડ કરો...",
                suggestions: ["ઈમેલ લખો", "ક્વોન્ટમ ભૌતિકશાસ્ત્ર સમજાવો", "રેસિપી બનાવો", "પ્રવાસનું આયોજન કરો"],
                disclaimer: "NavaBharat AI ભૂલ કરી શકે છે. મહત્વપૂર્ણ માહિતી તપાસો.",
                messages: "સંદેશા"
            },
            pa: {
                processingFile: "ਫਾਈਲ ਪ੍ਰੋਸੈਸ ਕਰ ਰਿਹਾ ਹੈ...",
                analyzingImage: "ਇਮੇਜ ਦਾ ਵਿਸ਼ਲੇਸ਼ਣ ਕਰ ਰਿਹਾ ਹੈ...",
                extractingText: "ਟੈਕਸਟ ਕੱਢ ਰਿਹਾ ਹੈ...",
                processingDocument: "ਦਸਤਾਵੇਜ਼ ਪ੍ਰੋਸੈਸ ਕਰ ਰਿਹਾ ਹੈ...",
                analyzingVideo: "ਵੀਡੀਓ ਦਾ ਵਿਸ਼ਲੇਸ਼ਣ ਕਰ ਰਿਹਾ ਹੈ...",

                fileInformation: "ਫਾਈਲ ਜਾਣਕਾਰੀ",
                aiAnalysis: "AI ਵਿਸ਼ਲੇਸ਼ਣ",
                extractedText: "ਕੱਢਿਆ ਗਿਆ ਟੈਕਸਟ",
                colorAnalysis: "ਰੰਗ ਵਿਸ਼ਲੇਸ਼ਣ",
                documentInformation: "ਦਸਤਾਵੇਜ਼ ਜਾਣਕਾਰੀ",
                contentPreview: "ਸਮੱਗਰੀ ਪੂਰਵਦਰਸ਼ਨ",
                summary: "ਸਾਰਾਂਸ਼",
                keyInformation: "ਮੁੱਖ ਜਾਣਕਾਰੀ",
                videoInformation: "ਵੀਡੀਓ ਜਾਣਕਾਰੀ",
                transcription: "ਲਿਪੀਅੰਤਰਨ",
                sceneAnalysis: "ਦ੍ਰਿਸ਼ ਵਿਸ਼ਲੇਸ਼ਣ",

                whatWouldYouLike: "ਤੁਸੀਂ ਹੋਰ ਕੀ ਜਾਣਨਾ ਚਾਹੁੰਦੇ ਹੋ?",
                regardingQuestion: "ਤੁਹਾਡੇ ਸਵਾਲ ਦੇ ਸਬੰਧ ਵਿੱਚ",
                iCanHelp: "ਮੈਂ ਸਮੱਗਰੀ ਨੂੰ ਸਮਝਣ ਅਤੇ ਅੰਤਰਦ੍ਰਿਸ਼ਟੀ ਪ੍ਰਦਾਨ ਕਰਨ ਵਿੱਚ ਤੁਹਾਡੀ ਮਦਦ ਕਰ ਸਕਦਾ ਹਾਂ।",

                analyzeSpecific: "ਵਿਸ਼ੇਸ਼ ਪਹਿਲੂਆਂ ਦਾ ਵਿਸ਼ਲੇਸ਼ਣ ਕਰੋ",
                extractText: "ਕੋਈ ਵੀ ਟੈਕਸਟ ਕੱਢੋ ਅਤੇ ਸਪਸ਼ਟ ਕਰੋ",
                describeObjects: "ਵਸਤੂਆਂ ਜਾਂ ਦ੍ਰਿਸ਼ਾਂ ਦਾ ਵਿਸਥਾਰ ਵਰਣਨ ਕਰੋ",
                compareImages: "ਹੋਰ ਇਮੇਜਾਂ ਨਾਲ ਤੁਲਨਾ ਕਰੋ",
                extractInfo: "ਵਿਸ਼ੇਸ਼ ਜਾਣਕਾਰੀ ਕੱਢੋ",
                summarizeContent: "ਭਾਗਾਂ ਜਾਂ ਪੂਰੇ ਦਸਤਾਵੇਜ਼ ਦਾ ਸਾਰਾਂਸ਼ ਬਣਾਓ",
                answerQuestions: "ਸਮੱਗਰੀ ਬਾਰੇ ਸਵਾਲਾਂ ਦੇ ਜਵਾਬ ਦਿਓ",
                compareDocuments: "ਹੋਰ ਦਸਤਾਵੇਜ਼ਾਂ ਨਾਲ ਤੁਲਨਾ ਕਰੋ",
                provideTranscription: "ਵਿਸਥਾਰ ਲਿਪੀਅੰਤਰਨ ਪ੍ਰਦਾਨ ਕਰੋ",
                analyzeScenes: "ਵਿਸ਼ੇਸ਼ ਦ੍ਰਿਸ਼ਾਂ ਜਾਂ ਟਾਈਮਸਟੈਂਪਾਂ ਦਾ ਵਿਸ਼ਲੇਸ਼ਣ ਕਰੋ",
                summarizeVideo: "ਵੀਡੀਓ ਸਮੱਗਰੀ ਦਾ ਸਾਰਾਂਸ਼ ਬਣਾਓ",
                answerVideoQuestions: "ਦਿਖਾਏ ਜਾਂ ਕਹੇ ਗਏ ਬਾਰੇ ਸਵਾਲਾਂ ਦੇ ਜਵਾਬ ਦਿਓ",

                newChat: "ਨਵੀਂ ਚੈਟ",
                aiAnalysis: "AI ਵਿਸ਼ਲੇਸ਼ਣ",
                messagePlaceholder: "NavaBharat AI ਨੂੰ ਸੰਦੇਸ਼ ਭੇਜੋ ਜਾਂ ਫਾਈਲਾਂ ਅੱਪਲੋਡ ਕਰੋ...",
                suggestions: ["ਈਮੇਲ ਲਿਖੋ", "ਕੁਆਂਟਮ ਭੌਤਿਕ ਵਿਗਿਆਨ ਸਮਝਾਓ", "ਰੈਸਿਪੀ ਬਣਾਓ", "ਸਫ਼ਰ ਦੀ ਯੋਜਨਾ ਬਣਾਓ"],
                disclaimer: "NavaBharat AI ਗਲਤੀਆਂ ਕਰ ਸਕਦਾ ਹੈ। ਮਹੱਤਵਪੂਰਨ ਜਾਣਕਾਰੀ ਦੀ ਜਾਂਚ ਕਰੋ।",
                messages: "ਸੰਦੇਸ਼"
            },
            bn: {
                processingFile: "ফাইল প্রক্রিয়াকরণ করছে...",
                analyzingImage: "ইমেজ বিশ্লেষণ করছে...",
                extractingText: "টেক্সট বের করছে...",
                processingDocument: "নথি প্রক্রিয়াকরণ করছে...",
                analyzingVideo: "ভিডিও বিশ্লেষণ করছে...",

                fileInformation: "ফাইল তথ্য",
                aiAnalysis: "AI বিশ্লেষণ",
                extractedText: "বের করা টেক্সট",
                colorAnalysis: "রঙ বিশ্লেষণ",
                documentInformation: "নথি তথ্য",
                contentPreview: "সামগ্রী পূর্বরূপ",
                summary: "সারাংশ",
                keyInformation: "মূল তথ্য",
                videoInformation: "ভিডিও তথ্য",
                transcription: "লিপ্যন্তর",
                sceneAnalysis: "দৃশ্য বিশ্লেষণ",

                whatWouldYouLike: "আপনি আর কী জানতে চান?",
                regardingQuestion: "আপনার প্রশ্নের সাথে সম্পর্কিত",
                iCanHelp: "আমি সামগ্রী বোঝার এবং অন্তর্দৃষ্টি প্রদানে আপনাকে সাহায্য করতে পারি।",

                analyzeSpecific: "নির্দিষ্ট দিকগুলি বিশ্লেষণ করুন",
                extractText: "যেকোনো টেক্সট বের করুন এবং ব্যাখ্যা করুন",
                describeObjects: "বস্তু বা দৃশ্যগুলির বিস্তারিত বর্ণনা করুন",
                compareImages: "অন্যান্য ইমেজের সাথে তুলনা করুন",
                extractInfo: "নির্দিষ্ট তথ্য বের করুন",
                summarizeContent: "বিভাগ বা সম্পূর্ণ নথির সারাংশ তৈরি করুন",
                answerQuestions: "সামগ্রী সম্পর্কে প্রশ্নের উত্তর দিন",
                compareDocuments: "অন্যান্য নথির সাথে তুলনা করুন",
                provideTranscription: "বিস্তারিত লিপ্যন্তর প্রদান করুন",
                analyzeScenes: "নির্দিষ্ট দৃশ্য বা টাইমস্ট্যাম্প বিশ্লেষণ করুন",
                summarizeVideo: "ভিডিও সামগ্রীর সারাংশ তৈরি করুন",
                answerVideoQuestions: "যা দেখানো বা বলা হয়েছে সে সম্পর্কে প্রশ্নের উত্তর দিন",

                newChat: "নতুন চ্যাট",
                aiAnalysis: "AI বিশ্লেষণ",
                messagePlaceholder: "NavaBharat AI-কে বার্তা পাঠান বা ফাইল আপলোড করুন...",
                suggestions: ["ইমেইল লিখুন", "কোয়ান্টাম পদার্থবিদ্যা ব্যাখ্যা করুন", "রেসিপি তৈরি করুন", "ভ্রমণের পরিকল্পনা করুন"],
                disclaimer: "NavaBharat AI ভুল করতে পারে। গুরুত্বপূর্ণ তথ্য যাচাই করুন।",
                messages: "বার্তা"
            },
            ur: {
                processingFile: "فائل پراسیس کر رہا ہوں...",
                analyzingImage: "امیج کا تجزیہ کر رہا ہوں...",
                extractingText: "ٹیکسٹ نکال رہا ہوں...",
                processingDocument: "دستاویز پراسیس کر رہا ہوں...",
                analyzingVideo: "ویڈیو کا تجزیہ کر رہا ہوں...",

                fileInformation: "فائل کی معلومات",
                aiAnalysis: "AI تجزیہ",
                extractedText: "نکالا گیا ٹیکسٹ",
                colorAnalysis: "رنگ کا تجزیہ",
                documentInformation: "دستاویز کی معلومات",
                contentPreview: "مواد کی پیش نظارہ",
                summary: "خلاصہ",
                keyInformation: "اہم معلومات",
                videoInformation: "ویڈیو کی معلومات",
                transcription: "نقل",
                sceneAnalysis: "منظر کا تجزیہ",

                whatWouldYouLike: "آپ اور کیا جاننا چاہیں گے؟",
                regardingQuestion: "آپ کے سوال کے حوالے سے",
                iCanHelp: "میں مواد کو سمجھنے اور بصیرت فراہم کرنے میں آپ کی مدد کر سکتا ہوں۔",

                analyzeSpecific: "مخصوص پہلوؤں کا تجزیہ کریں",
                extractText: "کوئی بھی ٹیکسٹ نکالیں اور سمجھائیں",
                describeObjects: "اشیاء یا مناظر کی تفصیلی وضاحت کریں",
                compareImages: "دوسری امیجز کے ساتھ موازنہ کریں",
                extractInfo: "مخصوص معلومات نکالیں",
                summarizeContent: "حصوں یا پورے دستاویز کا خلاصہ بنائیں",
                answerQuestions: "مواد کے بارے میں سوالات کے جواب دیں",
                compareDocuments: "دوسرے دستاویزوں کے ساتھ موازنہ کریں",
                provideTranscription: "تفصیلی نقل فراہم کریں",
                analyzeScenes: "مخصوص مناظر یا ٹائم اسٹیمپس کا تجزیہ کریں",
                summarizeVideo: "ویڈیو مواد کا خلاصہ بنائیں",
                answerVideoQuestions: "جو دکھایا یا کہا گیا ہے اس کے بارے میں سوالات کے جواب دیں",

                newChat: "نیا چیٹ",
                aiAnalysis: "AI تجزیہ",
                messagePlaceholder: "NavaBharat AI کو پیغام بھیجیں یا فائلیں اپ لوڈ کریں...",
                suggestions: ["ای میل لکھیں", "کوانٹم طبیعیات کی وضاحت کریں", "نسخہ بنائیں", "سفر کی منصوبہ بندی کریں"],
                disclaimer: "NavaBharat AI غلطیاں کر سکتا ہے۔ اہم معلومات کی جانچ کریں۔",
                messages: "پیغامات"
            },
            es: {
                processingFile: "Procesando archivo...",
                analyzingImage: "Analizando imagen...",
                extractingText: "Extrayendo texto...",
                processingDocument: "Procesando documento...",
                analyzingVideo: "Analizando video...",

                fileInformation: "Información del archivo",
                aiAnalysis: "Análisis de IA",
                extractedText: "Texto extraído",
                colorAnalysis: "Análisis de color",
                documentInformation: "Información del documento",
                contentPreview: "Vista previa del contenido",
                summary: "Resumen",
                keyInformation: "Información clave",
                videoInformation: "Información del video",
                transcription: "Transcripción",
                sceneAnalysis: "Análisis de escena",

                whatWouldYouLike: "¿Qué más te gustaría saber?",
                regardingQuestion: "Con respecto a tu pregunta",
                iCanHelp: "Puedo ayudarte a entender el contenido y proporcionar información.",

                analyzeSpecific: "Analizar aspectos específicos",
                extractText: "Extraer y explicar cualquier texto",
                describeObjects: "Describir objetos o escenas en detalle",
                compareImages: "Comparar con otras imágenes",
                extractInfo: "Extraer información específica",
                summarizeContent: "Resumir secciones o todo el documento",
                answerQuestions: "Responder preguntas sobre el contenido",
                compareDocuments: "Comparar con otros documentos",
                provideTranscription: "Proporcionar transcripción detallada",
                analyzeScenes: "Analizar escenas o marcas de tiempo específicas",
                summarizeVideo: "Resumir el contenido del video",
                answerVideoQuestions: "Responder preguntas sobre lo mostrado o dicho",

                newChat: "Nuevo chat",
                aiAnalysis: "Análisis de IA",
                messagePlaceholder: "Envía un mensaje a NavaBharat AI o sube archivos...",
                suggestions: ["Escribir un correo electrónico", "Explicar física cuántica", "Crear una receta", "Planificar un viaje"],
                disclaimer: "NavaBharat AI puede cometer errores. Verifica la información importante.",
                messages: "mensajes"
            },
            fr: {
                processingFile: "Traitement du fichier...",
                analyzingImage: "Analyse de l'image...",
                extractingText: "Extraction du texte...",
                processingDocument: "Traitement du document...",
                analyzingVideo: "Analyse de la vidéo...",

                fileInformation: "Informations sur le fichier",
                aiAnalysis: "Analyse IA",
                extractedText: "Texte extrait",
                colorAnalysis: "Analyse des couleurs",
                documentInformation: "Informations sur le document",
                contentPreview: "Aperçu du contenu",
                summary: "Résumé",
                keyInformation: "Informations clés",
                videoInformation: "Informations sur la vidéo",
                transcription: "Transcription",
                sceneAnalysis: "Analyse de scène",

                whatWouldYouLike: "Qu'aimeriez-vous savoir d'autre ?",
                regardingQuestion: "Concernant votre question",
                iCanHelp: "Je peux vous aider à comprendre le contenu et fournir des informations.",

                analyzeSpecific: "Analyser des aspects spécifiques",
                extractText: "Extraire et expliquer tout texte",
                describeObjects: "Décrire des objets ou des scènes en détail",
                compareImages: "Comparer avec d'autres images",
                extractInfo: "Extraire des informations spécifiques",
                summarizeContent: "Résumer des sections ou l'ensemble du document",
                answerQuestions: "Répondre aux questions sur le contenu",
                compareDocuments: "Comparer avec d'autres documents",
                provideTranscription: "Fournir une transcription détaillée",
                analyzeScenes: "Analyser des scènes ou des horodatages spécifiques",
                summarizeVideo: "Résumer le contenu de la vidéo",
                answerVideoQuestions: "Répondre aux questions sur ce qui est montré ou dit",

                newChat: "Nouvelle discussion",
                aiAnalysis: "Analyse IA",
                messagePlaceholder: "Envoyez un message à NavaBharat AI ou téléchargez des fichiers...",
                suggestions: ["Écrire un e-mail", "Expliquer la physique quantique", "Créer une recette", "Planifier un voyage"],
                disclaimer: "NavaBharat AI peut faire des erreurs. Vérifiez les informations importantes.",
                messages: "messages"
            },
            de: {
                processingFile: "Datei wird verarbeitet...",
                analyzingImage: "Bild wird analysiert...",
                extractingText: "Text wird extrahiert...",
                processingDocument: "Dokument wird verarbeitet...",
                analyzingVideo: "Video wird analysiert...",

                fileInformation: "Datei-Informationen",
                aiAnalysis: "KI-Analyse",
                extractedText: "Extrahierter Text",
                colorAnalysis: "Farb-Analyse",
                documentInformation: "Dokument-Informationen",
                contentPreview: "Inhaltsvorschau",
                summary: "Zusammenfassung",
                keyInformation: "Wichtige Informationen",
                videoInformation: "Video-Informationen",
                transcription: "Transkription",
                sceneAnalysis: "Szenen-Analyse",

                whatWouldYouLike: "Was möchten Sie noch wissen?",
                regardingQuestion: "Bezüglich Ihrer Frage",
                iCanHelp: "Ich kann Ihnen helfen, den Inhalt zu verstehen und Einblicke zu geben.",

                analyzeSpecific: "Spezifische Aspekte analysieren",
                extractText: "Jeglichen Text extrahieren und erklären",
                describeObjects: "Objekte oder Szenen detailliert beschreiben",
                compareImages: "Mit anderen Bildern vergleichen",
                extractInfo: "Spezifische Informationen extrahieren",
                summarizeContent: "Abschnitte oder das gesamte Dokument zusammenfassen",
                answerQuestions: "Fragen zum Inhalt beantworten",
                compareDocuments: "Mit anderen Dokumenten vergleichen",
                provideTranscription: "Detaillierte Transkription bereitstellen",
                analyzeScenes: "Spezifische Szenen oder Zeitstempel analysieren",
                summarizeVideo: "Video-Inhalt zusammenfassen",
                answerVideoQuestions: "Fragen zu dem, was gezeigt oder gesagt wird, beantworten",

                newChat: "Neuer Chat",
                aiAnalysis: "KI-Analyse",
                messagePlaceholder: "Nachricht an NavaBharat AI senden oder Dateien hochladen...",
                suggestions: ["E-Mail schreiben", "Quantenphysik erklären", "Rezept erstellen", "Reise planen"],
                disclaimer: "NavaBharat AI kann Fehler machen. Überprüfen Sie wichtige Informationen.",
                messages: "Nachrichten"
            },
            zh: {
                processingFile: "正在处理文件...",
                analyzingImage: "正在分析图像...",
                extractingText: "正在提取文本...",
                processingDocument: "正在处理文档...",
                analyzingVideo: "正在分析视频...",

                fileInformation: "文件信息",
                aiAnalysis: "AI 分析",
                extractedText: "提取的文本",
                colorAnalysis: "颜色分析",
                documentInformation: "文档信息",
                contentPreview: "内容预览",
                summary: "摘要",
                keyInformation: "关键信息",
                videoInformation: "视频信息",
                transcription: "转录",
                sceneAnalysis: "场景分析",

                whatWouldYouLike: "您还想了解什么？",
                regardingQuestion: "关于您的问题",
                iCanHelp: "我可以帮助您理解内容并提供见解。",

                analyzeSpecific: "分析特定方面",
                extractText: "提取并解释任何文本",
                describeObjects: "详细描述对象或场景",
                compareImages: "与其他图像比较",
                extractInfo: "提取特定信息",
                summarizeContent: "总结部分或整个文档",
                answerQuestions: "回答有关内容的问题",
                compareDocuments: "与其他文档比较",
                provideTranscription: "提供详细转录",
                analyzeScenes: "分析特定场景或时间戳",
                summarizeVideo: "总结视频内容",
                answerVideoQuestions: "回答关于显示或所说内容的问题",

                newChat: "新聊天",
                aiAnalysis: "AI 分析",
                messagePlaceholder: "向 NavaBharat AI 发送消息或上传文件...",
                suggestions: ["写电子邮件", "解释量子物理", "创建食谱", "规划旅行"],
                disclaimer: "NavaBharat AI 可能会出错。请检查重要信息。",
                messages: "消息"
            },
            ja: {
                processingFile: "ファイルを処理中...",
                analyzingImage: "画像を分析中...",
                extractingText: "テキストを抽出中...",
                processingDocument: "ドキュメントを処理中...",
                analyzingVideo: "ビデオを分析中...",

                fileInformation: "ファイル情報",
                aiAnalysis: "AI 分析",
                extractedText: "抽出されたテキスト",
                colorAnalysis: "色分析",
                documentInformation: "ドキュメント情報",
                contentPreview: "コンテンツプレビュー",
                summary: "要約",
                keyInformation: "主要情報",
                videoInformation: "ビデオ情報",
                transcription: "文字起こし",
                sceneAnalysis: "シーン分析",

                whatWouldYouLike: "他に何を知りたいですか？",
                regardingQuestion: "ご質問について",
                iCanHelp: "内容を理解し、洞察を提供するお手伝いができます。",

                analyzeSpecific: "特定の側面を分析する",
                extractText: "テキストを抽出して説明する",
                describeObjects: "オブジェクトやシーンを詳細に記述する",
                compareImages: "他の画像と比較する",
                extractInfo: "特定の情報を抽出する",
                summarizeContent: "セクションまたはドキュメント全体を要約する",
                answerQuestions: "内容に関する質問に答える",
                compareDocuments: "他のドキュメントと比較する",
                provideTranscription: "詳細な文字起こしを提供する",
                analyzeScenes: "特定のシーンやタイムスタンプを分析する",
                summarizeVideo: "ビデオ内容を要約する",
                answerVideoQuestions: "表示または言及された内容についての質問に答える",

                newChat: "新しいチャット",
                aiAnalysis: "AI 分析",
                messagePlaceholder: "NavaBharat AI にメッセージを送信するか、ファイルをアップロードしてください...",
                suggestions: ["メールを書く", "量子物理を説明する", "レシピを作成する", "旅行を計画する"],
                disclaimer: "NavaBharat AI は間違いを犯す可能性があります。重要な情報を確認してください。",
                messages: "メッセージ"
            },
            ko: {
                processingFile: "파일 처리 중...",
                analyzingImage: "이미지 분석 중...",
                extractingText: "텍스트 추출 중...",
                processingDocument: "문서 처리 중...",
                analyzingVideo: "비디오 분석 중...",

                fileInformation: "파일 정보",
                aiAnalysis: "AI 분석",
                extractedText: "추출된 텍스트",
                colorAnalysis: "색상 분석",
                documentInformation: "문서 정보",
                contentPreview: "콘텐츠 미리보기",
                summary: "요약",
                keyInformation: "주요 정보",
                videoInformation: "비디오 정보",
                transcription: "녹취록",
                sceneAnalysis: "장면 분석",

                whatWouldYouLike: "더 알고 싶은 것이 있으신가요?",
                regardingQuestion: "귀하의 질문과 관련하여",
                iCanHelp: "콘텐츠를 이해하고 통찰력을 제공하는 데 도움을 드릴 수 있습니다.",

                analyzeSpecific: "특정 측면 분석",
                extractText: "텍스트 추출 및 설명",
                describeObjects: "개체 또는 장면을 자세히 설명",
                compareImages: "다른 이미지와 비교",
                extractInfo: "특정 정보 추출",
                summarizeContent: "섹션 또는 전체 문서 요약",
                answerQuestions: "콘텐츠에 대한 질문 답변",
                compareDocuments: "다른 문서와 비교",
                provideTranscription: "상세한 녹취록 제공",
                analyzeScenes: "특정 장면 또는 타임스탬프 분석",
                summarizeVideo: "비디오 콘텐츠 요약",
                answerVideoQuestions: "표시되거나 언급된 내용에 대한 질문 답변",

                newChat: "새 채팅",
                aiAnalysis: "AI 분석",
                messagePlaceholder: "NavaBharat AI에 메시지를 보내거나 파일을 업로드하세요...",
                suggestions: ["이메일 쓰기", "양자 물리학 설명", "레시피 만들기", "여행 계획"],
                disclaimer: "NavaBharat AI는 실수를 할 수 있습니다. 중요한 정보를 확인하세요.",
                messages: "메시지"
            }
        };
    }

    createLanguageSelector() {
        // Language selector implementation
        const selector = document.createElement('select');
        selector.id = 'language-selector';

        Object.entries(this.supportedLanguages).forEach(([code, lang]) => {
            const option = document.createElement('option');
            option.value = code;
            option.textContent = `${lang.flag} ${lang.name}`;
            if (code === this.currentLanguage) {
                option.selected = true;
            }
            selector.appendChild(option);
        });

        selector.addEventListener('change', (e) => {
            this.currentLanguage = e.target.value;
            this.updateUILanguage();
        });

        // Insert into DOM (adjust selector as needed)
        const header = document.querySelector('.header') || document.body;
        header.insertBefore(selector, header.firstChild);
    }

    updateUILanguage() {
        const translations = this.translations[this.currentLanguage];

        // Update all elements with data-translate attribute
        document.querySelectorAll('[data-translate]').forEach(element => {
            const key = element.getAttribute('data-translate');
            if (translations[key]) {
                element.textContent = translations[key];
            }
        });

        // Update placeholders
        document.querySelectorAll('[data-translate-placeholder]').forEach(element => {
            const key = element.getAttribute('data-translate-placeholder');
            if (translations[key]) {
                element.placeholder = translations[key];
            }
        });

        // Update suggestions
        document.querySelectorAll('.suggestion-item').forEach((element, index) => {
            if (translations.suggestions && translations.suggestions[index]) {
                element.textContent = translations.suggestions[index];
            }
        });
    }

    getText(key) {
        return this.translations[this.currentLanguage][key] || key;
    }

    setLanguage(languageCode) {
        if (this.supportedLanguages[languageCode]) {
            this.currentLanguage = languageCode;
            this.updateUILanguage();
            return true;
        }
        return false;
    }

    getCurrentLanguage() {
        return this.currentLanguage;
    }

    getSupportedLanguages() {
        return this.supportedLanguages;
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = MultilingualSupport;
}
